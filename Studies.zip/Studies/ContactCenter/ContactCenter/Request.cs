using System.ComponentModel;

public class Request
{
    public string ID {get;}

    public int ResolutionTime {get;}

    public Category Category {get;}

    public Request(string id, int resolutionTime, Category requestCategory)
    {
        this.ID = id;
        this.ResolutionTime = resolutionTime;
        this.Category = requestCategory;
    }
}

public enum Category
{
    Order,
    Pay,
    Prime,
    Kindle,
    Fresh
}