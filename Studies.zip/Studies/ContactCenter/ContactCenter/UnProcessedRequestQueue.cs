public class UnProcessedRequestQueue
{
    private List<Request> unProcessedRequests = new List<Request>();

    public void Save(Request request)
    {
        this.unProcessedRequests.Add(request);    
    } 

    public Request[] GetAll()
    {
        return this.unProcessedRequests.ToArray();
    }

    public int GetNumberOfUnProcessedRequests()
    {
        return this.unProcessedRequests.Count;
    }
}