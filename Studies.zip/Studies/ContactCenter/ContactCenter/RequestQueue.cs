public class RequestQueue
{
    private List<Request> requests;

    private int index = 0;

    public RequestQueue(Request[] requests)
    {
        this.requests = new List<Request>(requests);
    }

    public virtual bool TryGetNext(out Request request)
    {
        request = null;
        if (this.index >= this.requests.Count)
            return false;

        request = this.requests[this.index];
        index++;
        return true;
    }

}