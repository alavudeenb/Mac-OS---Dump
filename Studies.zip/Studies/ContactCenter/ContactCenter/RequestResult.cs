public class RequestResult
{
    public string RequestId {get;}

    public int WatitingTime {get;}
    

    public RequestResult(string requestId, int waitingTime)
    {
        this.RequestId = requestId;
        this.WatitingTime = waitingTime;
    }
}