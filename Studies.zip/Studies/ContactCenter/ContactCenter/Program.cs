﻿Console.WriteLine("Hello, World!");
Request[] requests = new Request[5];
requests[0] = new Request("1", 3, Category.Order);
requests[1] = new Request("2", 7, Category.Pay);
requests[2] = new Request("3", 4, Category.Prime);
requests[3] = new Request("4", 6, Category.Pay);
requests[4] = new Request("5", 2, Category.Fresh);

Associate[] associates = new Associate[3];
associates[0] = new Associate("A1", new[] { Skill.Order, Skill.Pay});
associates[1] = new Associate("A2", new[] {Skill.Fresh});
associates[2] = new Associate("A3", new[] {Skill.Pay});

var contactCenter = new ContactCenter(requests, associates);
var waitingTimeOfAllRequests = contactCenter.FindWaitingTimeOfAllRequest(out var unProcessedRequestCount);

foreach(var requestWaitTime in waitingTimeOfAllRequests)
    Console.WriteLine($"Request:{requestWaitTime.RequestId} WaitTime:{requestWaitTime.WatitingTime}");


bool exit = false;
while(unProcessedRequestCount > 0 && !exit)
{
    Console.WriteLine($"Number of unprocessed requests: {unProcessedRequestCount}");
    Console.WriteLine("Press 1 for unprocessed requests, 2 for adding Associates, 3 for adding requests, 4 exit");
    var selection = Convert.ToInt32(Console.ReadLine());
    switch(selection)
    {
        case 1:
         contactCenter.RetryUnprocessedRequests(out unProcessedRequestCount);
         break;
        case 2:
          Console.WriteLine("This functionality not available. Coming soon");
          break;
        case 3: 
            Console.WriteLine("This functionality not available. Coming soon");
            break;
        case 4:
            Console.WriteLine("Thank you for contacting us");
            exit = true;
            break;
    }
}