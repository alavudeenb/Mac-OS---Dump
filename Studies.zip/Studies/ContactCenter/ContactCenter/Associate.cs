public class Associate
{
    public string ID {get;}

    public Skill[] Skills {get;}

    private readonly HashSet<Skill> haveSkills;

    public Associate(string id, Skill[] skills)
    {
        this.ID = id;
        this.Skills = skills;
        this.haveSkills =  new HashSet<Skill>(skills);
    }

    public bool CanHandle(Skill skill)
    {
        return this.haveSkills.Contains(skill);
    }
}

public enum Skill
{
    Order,
    Pay,
    Prime,
    Kindle,
    Fresh
}