using System.ComponentModel.DataAnnotations;
using System.Linq.Expressions;
using Microsoft.VisualBasic;

public class AssociateTracker
{
    private Dictionary<Skill, List<Associate>> associateBySkill = new Dictionary<Skill, List<Associate>>();

    private Dictionary<Associate, AssociateState> associateStateByAssociate = new Dictionary<Associate, AssociateState>();

    public AssociateTracker(Associate[] associates)
    {
        InitializeAssociateBySkill(associates);
        IntializeAssociateStateByAssociate(associates);
    }

    private void InitializeAssociateBySkill(Associate[] associates)
    {
        foreach (var associate in associates)
        {
            foreach (var skill in associate.Skills)
            {
                if (!this.associateBySkill.TryGetValue(skill, out var listOfAssociates))
                    this.associateBySkill[skill] = new List<Associate>();

                this.associateBySkill[skill].Add(associate);
            }
        }
    }

    private void IntializeAssociateStateByAssociate(Associate[] associates)
    {
        foreach (var associate in associates)
        {
            this.associateStateByAssociate.Add(associate, new AssociateState(associate));
        }
    }

    public bool TryFindAvailableAssociateBySkill(Skill skill, out AssociateState availableAssocaiteState)
    {
        availableAssocaiteState = null;
        if (!this.associateBySkill.TryGetValue(skill, out var matchingAssociatesBySkill))
            return false;

        foreach (var associate in matchingAssociatesBySkill)
        {
            if (this.associateStateByAssociate.TryGetValue(associate, out var currentAssociateState))
            {
                if (availableAssocaiteState == null || currentAssociateState.AvailableAt < availableAssocaiteState.AvailableAt)
                {
                    availableAssocaiteState = currentAssociateState;
                }
            }
        }
        return true;

    }
}

