using System.Runtime.CompilerServices;

public class ContactCenter
{
    RequestQueue requestQueue;

    UnProcessedRequestQueue unProcessedRequestQueue;

    AssociateTracker associateTracker;

    public ContactCenter(Request[] requests, Associate[] associates)
    {
        this.requestQueue = new RequestQueue(requests);
        this.associateTracker = new AssociateTracker(associates);
        this.unProcessedRequestQueue = new UnProcessedRequestQueue();
    }

    public List<RequestResult> FindWaitingTimeOfAllRequest(out int unProcessedRequestCount)
    {
        unProcessedRequestCount = 0;
        var output = new List<RequestResult>();
        Request currentRequest;
        while (this.requestQueue.TryGetNext(out currentRequest))
        {
            Skill currentRequestSkill = Get(currentRequest.Category);

            AssociateState matchingAssociateState;
            if (this.associateTracker.TryFindAvailableAssociateBySkill(currentRequestSkill, out matchingAssociateState))
            {
                output.Add(new RequestResult(currentRequest.ID, matchingAssociateState.AvailableAt));
                matchingAssociateState.AssignRequest(currentRequest);
            }
            else
            {
                this.unProcessedRequestQueue.Save(currentRequest);
            }
        }
        unProcessedRequestCount = this.unProcessedRequestQueue.GetNumberOfUnProcessedRequests();
        return output;
    }


    public List<RequestResult> RetryUnprocessedRequests(out int unProcessedRequestCount)
    {
        this.requestQueue = new RequestQueue(this.unProcessedRequestQueue.GetAll());
        this.unProcessedRequestQueue = new UnProcessedRequestQueue();
        return this.FindWaitingTimeOfAllRequest(out unProcessedRequestCount);
    }

    private Skill Get(Category category)
    {
        return category switch
        {
            Category.Order => Skill.Order,
            Category.Pay => Skill.Pay,
            Category.Prime => Skill.Prime,
            Category.Kindle => Skill.Kindle,
            Category.Fresh => Skill.Fresh,
            _ => throw new ArgumentOutOfRangeException(
                nameof(category), category, null)
        };
    }
}