public class AssociateState
{
    public Associate associate { get; }

    public int AvailableAt { get; private set; }

    public AssociateState(Associate associate)
    {
        this.associate = associate;
        this.AvailableAt = 0;
    }

    public void AssignRequest(Request request)
    {
        this.AvailableAt = this.AvailableAt + request.ResolutionTime;
    }

}