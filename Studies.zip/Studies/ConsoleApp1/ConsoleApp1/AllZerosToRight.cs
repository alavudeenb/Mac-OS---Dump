public class AllZerosToRight
{
    public void Execute(int[] inputArray)
    {
        var leftPointer = 0;
        for(int rightPointer = 0; rightPointer < inputArray.Length; rightPointer++)
        {
            if(inputArray[rightPointer] != 0)
            {
                var temp = inputArray[leftPointer];
                inputArray[leftPointer] = inputArray[rightPointer];
                inputArray[rightPointer] = temp;
                leftPointer++;
            }
        }
    }
}