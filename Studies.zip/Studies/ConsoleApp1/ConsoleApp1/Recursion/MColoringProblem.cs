using System.Reflection.Emit;

public class MColoring
{
    Dictionary<int, int> colorsTracker = new Dictionary<int, int>();

    List<(int vertex, List<int> neighbours)> input = new List<(int vertex, List<int> neighbours)>();
    public int Find(List<(int vertex, List<int> neighbours)> input, int mColors)
    {
        this.input = input;
        return FindRecursively(0, mColors) ? 1 : 0;
    }

    private bool FindRecursively(int index, int mColors)
    {
        if (index == this.input.Count) return true;

        for (int color = 1; color <= mColors; color++)
        {
            if (CanThisColorBeApplied(index, color))
            {
                this.colorsTracker.Add(this.input[index].vertex, color);
                return this.FindRecursively(index + 1, mColors);
            }
        }

        return false;
    }

    private bool CanThisColorBeApplied(int index, int currentColor)
    {
        var neighbours = this.input[index].neighbours;

        for (int ind = 0; ind < neighbours.Count; ind++)
        {
            var neighbourColor = 0;
            if (this.colorsTracker.TryGetValue(neighbours[ind], out neighbourColor) && neighbourColor == currentColor)
                return false;
        }
        return true;
    }
}