internal class PrintAllPermutationsOfStringOrArray_Recursion2 // O(n* n!)
    {
        public void PrintAll(int[] input)
        {
            PrintRecursivelyWITHOUTCarryingMap(input, 0);
        }

        private void PrintRecursivelyWITHOUTCarryingMap(int[] input, int index)
        {
            if (index >= input.Length)
            {
                for (int init = 0; init < input.Length; init++)
                {
                    Console.Write($"{input[init]} ");
                }
                Console.WriteLine();
                return;
            }

            for (int init = index; init < input.Length; init++)
            {
                Swap(input, init, index);

                PrintRecursivelyWITHOUTCarryingMap(input, index + 1);

                Swap(input, init, index);
            }
        }

        private void Swap(int[] input, int indexA, int indexB)
        {
            var temp = input[indexA];
            input[indexA] = input[indexB];
            input[indexB] = temp;
        }
    }