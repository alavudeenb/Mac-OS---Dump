using Microsoft.VisualBasic;

public class NQueen
{
    int[,] inputMatrix;

    int[] leftRow;
    
    int[] leftUpperDiagnoal;

    int[] leftLowerDiagnoal;

    int numberOfRowsAndColumns;

    public int[,] Find(int numberOfRowsAndColumns)
    {
        this.inputMatrix = new int[numberOfRowsAndColumns, numberOfRowsAndColumns];
        this.leftRow = new int[numberOfRowsAndColumns];
        this.leftUpperDiagnoal = new int[2* numberOfRowsAndColumns-1];
        this.leftLowerDiagnoal = new int[2 * numberOfRowsAndColumns - 1];
        this.numberOfRowsAndColumns = numberOfRowsAndColumns;

        return this.FindRecursively(0) ? this.inputMatrix : null;
    }

    private bool FindRecursively(int column)
    {
        if (column >= this.inputMatrix.GetLength(1))
            return true;

        for (int row = 0; row < this.inputMatrix.GetLength(0); row++)
        {
            if (CanIFill(row, column))
            {
                this.inputMatrix[row, column] = 1;
                this.leftRow[row] = 1;
                this.leftUpperDiagnoal[(this.numberOfRowsAndColumns -1) + (column-row)] = 1;
                this.leftLowerDiagnoal[row+column] = 1;
                var found = this.FindRecursively(column + 1);
                if(found) return true;
                this.inputMatrix[row, column] = 0;
                this.leftRow[row] = 0;
                this.leftUpperDiagnoal[(this.numberOfRowsAndColumns -1) + (column-row)] = 0;
                this.leftLowerDiagnoal[row+column] = 0;
            }
        }

        return false;
    }

    private bool CanIFill(int row, int column)
    {
        if(this.leftRow[row] == 1) return false;
        if(this.leftLowerDiagnoal[row+column] == 1) return false;
        if(this.leftUpperDiagnoal[(this.numberOfRowsAndColumns-1)+(column-row)] == 1) return false;
        /*var tempRow = row;
        var tempColumn = column;

        while(tempRow-1 >=0 && tempColumn-1>=0)
        {
            tempRow--;
            tempColumn--;
            if(this.inputMatrix[tempRow, tempColumn] == 1) return false;
        }

        tempRow = row;
        tempColumn = column;
        while(tempColumn-1 >=0)
        {
            tempColumn--;
            if(this.inputMatrix[tempRow, tempColumn] == 1) return false;
        }

        tempRow = row;
        tempColumn = column;
        while(tempRow +1 < this.inputMatrix.GetLength(0) && tempColumn - 1>=0)
        {
            tempRow++;
            tempColumn--;
            if(this.inputMatrix[tempRow, tempColumn] == 1) return false;
        }*/

        return true;
    }
}