using System.Text;

public class KthPermutation
{
    public int Find(int n, int k)
    {
        StringBuilder number = new StringBuilder();
        StringBuilder output = new StringBuilder();

        for (int ind = 1; ind <= n; ind++)
        {
            number.Append(ind);
        }

        k = k - 1;
        this.FindRecursively(number, n, k, output);
        return Convert.ToInt32(output.ToString());
    }

    public int FindRecursively(StringBuilder inputNumbers, int inputNumberLength, int k, StringBuilder output) // o(n) * O(n) = O(n2)
    {
        if (inputNumberLength == 0)
            return 0;

        var numberOfPermutationsAfterTakingFirstNumber = 1;
        for (int ind = inputNumberLength - 1; ind > 0; ind--)
            numberOfPermutationsAfterTakingFirstNumber = numberOfPermutationsAfterTakingFirstNumber * ind;

        var KthPermutationfirstNumberIndex = numberOfPermutationsAfterTakingFirstNumber == 0 ? 0 : k / numberOfPermutationsAfterTakingFirstNumber;
        var KthPermutation = numberOfPermutationsAfterTakingFirstNumber == 0 ? 0 : k % numberOfPermutationsAfterTakingFirstNumber;

        output.Append(inputNumbers[KthPermutationfirstNumberIndex]); // O(1)
        inputNumbers.Remove(KthPermutationfirstNumberIndex, 1); // O(n)


        return this.FindRecursively(inputNumbers, inputNumbers.Length, KthPermutation, output);

    }
}