/*using Microsoft.VisualBasic;

public class LRUCache : ICache
{
    LinkedList<string> lruCache = new LinkedList<string>();
    Dictionary<string, LinkedListNode<string>> dictionary = new Dictionary<string, LinkedListNode<string>>();

    LinkedListNode<string> head;
    LinkedListNode<string> tail;

    public bool Write(string key, string value)
    {
        try
        {
            LinkedListNode<string> currentNode;
            if (this.dictionary.TryGetValue(key, out currentNode))
            {
                currentNode.Value = value;
                this.lruCache.AddFirst(currentNode);
            }
            else
            {
                currentNode = new LinkedListNode<string>(value);
                if (this.head == null && this.tail == null)
                {
                    lruCache.AddFirst(currentNode);
                    this.head = currentNode;
                    this.tail = currentNode;
                }
                else
                {
                    lruCache.AddBefore(this.head, currentNode);
                    this.head = currentNode;
                }
                this.dictionary.Add(key, currentNode);
            }

            return true;
        }
        catch (Exception ex)
        {
            //log
            // throw user friendly error message
            throw ex;
        }
    }

    public string Read(string key)
    {
        LinkedListNode<string> value = null;
        if (this.dictionary.TryGetValue(key, out value) == false)
        {
            throw new KeyNotFoundException("Given key not found");
        }
        this.lruCache.AddFirst(value);
        return value.Value;
    }
}

public class ThreadSafeLRUCache : ICache
{
    DoublyLinkedList doublyLinkedList = new DoublyLinkedList();

    Dictionary<string, Node> dictionary = new Dictionary<string, Node>();

    public bool Write(string key, string value)
    {
        try
        {
            Node node;
            if (this.dictionary.TryGetValue(key, out node) == false)
            {
                Node currentNode = new Node(key) { Value = value };
                this.doublyLinkedList.AddNode(currentNode);
                this.dictionary.Add(key, currentNode);
            }
            x
            else
            {
                node.Value = value;
                this.doublyLinkedList.AddInTheBegining(node);
            }
            return true;
        }
        catch (Exception ex)
        {
            throw new InvalidOperationException(ex.Message);
        }
    }

    public string Read(string key)
    {
        Node node;

        if (dictionary.TryGetValue(key, out node))
        {
            this.doublyLinkedList.AddInTheBegining(node);
            return node.Value;
        }
        throw new KeyNotFoundException();
    }
}

public class DoublyLinkedList
{
    private Node head;

    private Node tail;

    public Node Head { get; }

    public Node Tail { get; }

    public void AddNode(Node node)
    {
        if (this.head == null && this.tail == null)
        {
            this.head = node;
            this.tail = node;
        }
        else
        {
            this.head.Previous = node;
            node.Next = this.head;
            this.head = node;
        }
    }

    public void AddInTheBegining(Node node)
    {
        var previousNode = node.Previous;
        var nextNode = node.Next;
        previousNode.Next = nextNode;
        nextNode.Previous = previousNode;

        node.Next = this.head;
        this.head.Previous = node;
    }

}

public class Node
{

    ReaderWriterLockSlim readerWriterLockSlim = new ReaderWriterLockSlim();

    private string value;

    public Node Next { get; set; }

    public Node Previous { get; set; }

    public string Key { get; private set; }

    public Node(string key)
    {
        this.Key = key;
    }

    public string Value
    {
        get
        {
            try
            {
                readerWriterLockSlim.EnterReadLock();

                return this.value;
            }
            finally
            {
                readerWriterLockSlim.ExitReadLock();
            }
        }
        set
        {
            try
            {
                readerWriterLockSlim.EnterWriteLock();
                this.value = value;
            }
            finally
            {
                readerWriterLockSlim.ExitWriteLock();
            }
        }
    }

}

public interface ICache
{
    bool Write(string key, string value);

    string Read(string key);
}


*/