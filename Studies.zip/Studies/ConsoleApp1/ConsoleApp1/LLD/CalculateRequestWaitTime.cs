class CalculateRequestWaitTime
{
    private CustomerRequest[] customerRequests;

    private ContactCenterAssociate[] contactCenterAssociates;

    private Dictionary<RequestCategory, List<ContactCenterAssociate>> associateBySkill = new Dictionary<RequestCategory, List<ContactCenterAssociate>>();
    private Dictionary<RequestCategory, PriorityQueue<(ContactCenterAssociate, int), int>> requestByCategoryMinHeap = new Dictionary<RequestCategory, PriorityQueue<(ContactCenterAssociate, int), int>>();

    public CalculateRequestWaitTime(CustomerRequest[] customerRequests, ContactCenterAssociate[] contactCenterAssociates)
    {
        if (customerRequests == null || contactCenterAssociates == null)
            throw new ArgumentNullException("CustomerRequests or ContactCenterAssociates can not be null");

        this.customerRequests = customerRequests;
        this.contactCenterAssociates = contactCenterAssociates;
        this.Initialize();
    }

    private void Initialize()
    {
        foreach (var associate in this.contactCenterAssociates)
        {
            foreach (var skill in associate.Skills)
            {
                if (!this.requestByCategoryMinHeap.TryGetValue(skill, out _))
                    requestByCategoryMinHeap[skill] = new PriorityQueue<(ContactCenterAssociate, int), int>();

                if (!this.associateBySkill.TryGetValue(skill, out _))
                    this.associateBySkill[skill] = new List<ContactCenterAssociate>();

                this.associateBySkill[skill].Add(associate);
            }
        }
    }

    public Response[] Find()
    {
        List<Response> output = new List<Response>();

        foreach (var request in this.customerRequests)
        {
            ContactCenterAssociate matchedAssociate;
            int waitingTime = 0;
            PriorityQueue<(ContactCenterAssociate, int), int> minHeap;
            if (this.requestByCategoryMinHeap.TryGetValue(request.category, out minHeap) && minHeap != null && minHeap.Count == 0)
            {
                 waitingTime = 0 + request.ResolutionTime;
                output.Add(new Response(request.Name, waitingTime));
                 matchedAssociate = this.associateBySkill[request.category].First();
            }
            else
            {
                (ContactCenterAssociate contactCenterAssociate, int resolutionTime) nextAvailableAssociate = minHeap.Dequeue();
                 matchedAssociate = nextAvailableAssociate.contactCenterAssociate;
                var previousRequestResolutionTime = nextAvailableAssociate.resolutionTime;
                 waitingTime = request.ResolutionTime + previousRequestResolutionTime;
                output.Add(new Response(request.Name, waitingTime));
            }

                foreach (var matchedAssociateSkill in matchedAssociate.Skills)
                {
                    this.requestByCategoryMinHeap[matchedAssociateSkill].Enqueue((matchedAssociate, waitingTime), waitingTime);
                }
        }


        return output.ToArray();
    }

}

public class Response
{
    public string requestName { get; private set; }

    public int waitingTime { get; private set; }

    public Response(string requestName, int waitingTime)
    {
        this.requestName = requestName;
        this.waitingTime = waitingTime;
    }
}

public class CustomerRequest
{
    public string Name { get; set; }

    public int ResolutionTime { get; set; }

    public RequestCategory category { get; set; }
}


public enum RequestCategory
{
    Order,
    Pay,
    Prime,
    Kindle,
    Fresh
}

public class ContactCenterAssociate
{
    public string Name { get; private set; }

    public RequestCategory[] Skills { get; private set; }

    public ContactCenterAssociate(string name, RequestCategory[] skills)
    {
        this.Name = name;
        this.Skills = skills;
    }
}