using System;
using System.Collections.Generic;

/// <summary>
/// Represents a request waiting to be handled by an associate.
/// </summary>
public sealed class Request
{
    public int Id { get; }
    public int CustomerId { get; }
    public Category Category { get; }
    public DateTime ArrivalTime { get; }

    public RequestStatus Status { get; private set; }

    public Associate? AssignedAssociate { get; private set; }

    public Request(
        int id,
        int customerId,
        Category category,
        DateTime arrivalTime)
    {
        Id = id;
        CustomerId = customerId;
        Category = category;
        ArrivalTime = arrivalTime;
        Status = RequestStatus.Pending;
    }

    internal void AssignTo(Associate associate)
    {
        if (Status != RequestStatus.Pending)
            throw new InvalidOperationException(
                $"Request {Id} is not pending.");

        Status = RequestStatus.Processing;
        AssignedAssociate = associate;
    }

    internal void Complete()
    {
        if (Status != RequestStatus.Processing)
            throw new InvalidOperationException(
                $"Request {Id} is not being processed.");

        Status = RequestStatus.Completed;
    }
}

public enum RequestStatus
{
    Pending,
    Processing,
    Completed
}

public enum Category
{
    Payment,
    Order
}
