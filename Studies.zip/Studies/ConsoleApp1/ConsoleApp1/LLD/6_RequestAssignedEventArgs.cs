public sealed class RequestAssignedEventArgs : EventArgs
{
    public Request Request { get; }
    public Associate Associate { get; }

    public RequestAssignedEventArgs(
        Request request,
        Associate associate)
    {
        Request = request;
        Associate = associate;
    }
}