public sealed class ContactCenter
{
    private readonly object sync = new();

    private readonly RequestQueue requestQueue = new();

    //private readonly Dictionary<int, Request> requests = new();

    private readonly Dictionary<int, Associate> associates = new();

    public event EventHandler<RequestAssignedEventArgs>? RequestAssigned;

    /// <summary>
    /// Customer creates a request.
    /// </summary>
    public void CreateRequest(Request request)
    {
        RequestAssignedEventArgs? assignment = null;

        lock (sync)
        {
           // requests.Add(request.Id, request);

            requestQueue.Enqueue(request);

            // Try to assign this request to an already
            // available eligible associate.
            assignment = TryAssignWaitingRequest();
        }

        // IMPORTANT:
        // Do not invoke external callbacks/events while
        // holding the lock.
        if (assignment != null)
        {
            RequestAssigned?.Invoke(this, assignment);
        }
    }

    /// <summary>
    /// Registers an associate with the contact centre.
    /// </summary>
    public void RegisterAssociate(Associate associate)
    {
        RequestAssignedEventArgs? assignment = null;

        lock (sync)
        {
            if (associates.ContainsKey(associate.Id))
                throw new InvalidOperationException(
                    $"Associate {associate.Id} already exists.");

            associates.Add(associate.Id, associate);

            associate.MakeAvailable();

            // A newly available associate may immediately
            // receive the oldest eligible request.
            assignment = TryAssignWaitingRequest(associate);
        }

        if (assignment != null)
        {
            RequestAssigned?.Invoke(this, assignment);
        }
    }

    /// <summary>
    /// Associate becomes available and asks for work.
    /// </summary>
    public void MakeAssociateAvailable(Associate associate)
    {
        RequestAssignedEventArgs? assignment = null;

        lock (sync)
        {
            if (!associates.ContainsKey(associate.Id))
                throw new InvalidOperationException(
                    "Associate is not registered.");

            associate.MakeAvailable();

            assignment = TryAssignWaitingRequest(associate);
        }

        if (assignment != null)
        {
            RequestAssigned?.Invoke(this, assignment);
        }
    }

    /// <summary>
    /// Associate completed the request.
    /// </summary>
    public void CompleteRequest(
        Associate associate,
        Request request)
    {
        RequestAssignedEventArgs? assignment = null;

        lock (sync)
        {
            if (request.AssignedAssociate != associate)
                throw new InvalidOperationException(
                    "Request is not assigned to this associate.");

            request.Complete();

            associate.CompleteCurrentRequest();

            // Immediately try to give this associate
            // the next oldest eligible request.
            assignment = TryAssignWaitingRequest(associate);
        }

        if (assignment != null)
        {
            RequestAssigned?.Invoke(this, assignment);
        }
    }

    /// <summary>
    /// Finds an available associate and assigns the oldest
    /// eligible waiting request.
    /// </summary>
    private RequestAssignedEventArgs? TryAssignWaitingRequest()
    {
        foreach (var associate in associates.Values)
        {
            if (associate.Status != AssociateStatus.Available)
                continue;

            var assignment = TryAssignWaitingRequest(associate);

            if (assignment != null)
                return assignment;
        }

        return null;
    }

    /// <summary>
    /// Finds the oldest waiting request among all categories
    /// that this associate can handle.
    /// </summary>
    private RequestAssignedEventArgs? TryAssignWaitingRequest(Associate associate)
    {
        Request? oldestRequest = null;

        foreach (var skill in associate.Skills)
        {
            var candidate = requestQueue.Peek(skill);

            if (candidate == null)
                continue;

            if (oldestRequest == null ||
                candidate.ArrivalTime < oldestRequest.ArrivalTime)
            {
                oldestRequest = candidate;
            }
        }

        if (oldestRequest == null)
            return null;

        // Remove the request from its queue.
        var request =
            requestQueue.Dequeue(oldestRequest.Category);

        // Atomically change both sides of the relationship.
        request.AssignTo(associate);

        associate.Assign(request);

        return new RequestAssignedEventArgs(
            request,
            associate);
    }
}