using System.Collections.Concurrent;
using System.Net.Cache;


/*

Domain:
-------
    ContactCenter
    Request
    Customer
    Associate
    RequestCategory

Entities:
---------
Request
-ID
-CustomerID
-RequestCategory
-ArrivedTime
-Status

RequestStaus
-Pending
-Processing
-Completed

Customer
-ID
-Name

Associate
-ID
-Name
-Skills
-Stauts

AssociateStatus
-Available
-Unavailable
-Busy

Category
-Payment
-Order

ContactCenter
-All Requests
-All Associates

Operations:
------------
-CreateRequest()
-RegisterAssociate()
-AssignAssociateToRequest()
-CompletedRequest()
-UnRegisterAssociate()

BusinessRules:
---------------
-Request will be queued 
-Associate will be assigned to one of the eligible oldest request based on the Skills that he have
-Only one request can be processed by an Associate

*/


/*
public class Customer
{
    public int ID { get; set; }
    public string Name { get; set; }
}

public class Request
{

    public int ID { get; set; }
    public int CustomerID { get; set; }
    public DateTime ArrivalTime { get; set; }
    public RequestStatus Status { get; set; }
    public Category Category { get; set; }
}

public enum RequestStatus
{
    Pending,
    Processing,
    Completed
}

public enum Category
{
    Payment,
    Order
}

public class Associate
{

    public int ID { get; set; }
    public string Name { get; set; }
    public AssociateStatus Status { get; set; }

    public List<Category> Skills { get; set; }


    public void DoJob(Request request)
    {
        //Store it in his local
        //acknowledges immediately 
    }
}

public enum AssociateStatus
{
    Available,
    Unavailable,
    Busy
}

public class ContactCenter
{
    Dictionary<Category, PriorityQueue<Request, DateTime>> requests = new Dictionary<Category, PriorityQueue<Request, DateTime>>();

    Dictionary<Category, List<Associate>> associates = new Dictionary<Category, List<Associate>>();

    private static Lazy<ContactCenter> contactCenter = new Lazy<ContactCenter>(() => new ContactCenter());

    private ContactCenter() { }

    public static ContactCenter Instance
    {
        get
        {
            return contactCenter.Value;
        }
    }

    public void CreateRequest(Request request)
    {
        PriorityQueue<Request, DateTime> minHeap;
        this.requests.TryGetValue(request.Category, out minHeap);
        minHeap.Enqueue(request, request.ArrivalTime);
    }

    private void AssignAssociatesToRequest(Associate associate)
    {
        var oldestTask = DateTime.Today.AddDays(1);
        PriorityQueue<Request, DateTime> oldestRequest = null;

        foreach (var skill in associate.Skills)
        {
            PriorityQueue<Request, DateTime> output;
            this.requests.TryGetValue(skill, out output);

            if (oldestRequest != null && output.Peek().ArrivalTime < oldestRequest.Peek().ArrivalTime)
            {
                oldestTask = output.Peek().ArrivalTime;
                oldestRequest = output;
            }
            else
            {
                oldestTask = output.Peek().ArrivalTime;
                oldestRequest = output;
            }
        }
        associate.Status = AssociateStatus.Busy;
        associate.DoJob(oldestRequest.Dequeue());

        //Log request will be processed later as all associates are busy
    }

    public void RegisterAssociate(Associate associate)
    {
        associate.Status = AssociateStatus.Available;
        foreach (var skill in associate.Skills)
        {
            List<Associate> listOfAssociates;
            this.associates.TryGetValue(skill, out listOfAssociates);
            listOfAssociates.Add(associate);
        }
    }

    public void UnRegisterAssociate(Associate associate)
    {
        foreach (var skill in associate.Skills)
        {
            List<Associate> listOfAssociates;
            this.associates.TryGetValue(skill, out listOfAssociates);
            listOfAssociates.Remove(associate);
        }
    }

    public void CompletedRequest(Associate associate, Request request)
    {
        request.Status = RequestStatus.Completed;
        associate.Status = AssociateStatus.Available;
        this.AssignAssociatesToRequest(associate);
    }
}*/