/// <summary>
/// Maintains waiting requests grouped by category.
/// PriorityQueue returns the request with the smallest ArrivalTime.
/// </summary>
public sealed class RequestQueue
{
    private readonly Dictionary<
        Category,
        PriorityQueue<Request, DateTime>> queues = new();

    public RequestQueue()
    {
        foreach (Category category in Enum.GetValues<Category>())
        {
            queues[category] =
                new PriorityQueue<Request, DateTime>();
        }
    }

    public void Enqueue(Request request)
    {
        queues[request.Category]
            .Enqueue(request, request.ArrivalTime);
    }

    public Request? Peek(Category category)
    {
        var queue = queues[category];

        if (queue.Count == 0)
            return null;

        return queue.Peek();
    }

    public Request Dequeue(Category category)
    {
        var queue = queues[category];

        if (queue.Count == 0)
            throw new InvalidOperationException(
                $"No pending requests for {category}.");

        return queue.Dequeue();
    }
}