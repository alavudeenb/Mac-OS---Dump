/// <summary>
/// Represents a contact centre associate.
/// </summary>
public sealed class Associate
{
    private readonly HashSet<Category> skills;

    public int Id { get; }
    public string Name { get; }

    public AssociateStatus Status { get; private set; }

    public IReadOnlyCollection<Category> Skills => skills;

    public Request? CurrentRequest { get; private set; }

    public Associate(
        int id,
        string name,
        IEnumerable<Category> skills)
    {
        Id = id;
        Name = name;

        this.skills = new HashSet<Category>(skills);

        Status = AssociateStatus.Unavailable;
    }

    public bool CanHandle(Category category)
    {
        return skills.Contains(category);
    }

    internal void MakeAvailable()
    {
        if (CurrentRequest != null)
            throw new InvalidOperationException(
                "Associate still has an active request.");

        Status = AssociateStatus.Available;
    }

    internal void Assign(Request request)
    {
        if (Status != AssociateStatus.Available)
            throw new InvalidOperationException(
                $"Associate {Id} is not available.");

        if (!CanHandle(request.Category))
            throw new InvalidOperationException(
                $"Associate {Id} cannot handle {request.Category}.");

        CurrentRequest = request;
        Status = AssociateStatus.Busy;
    }

    internal void CompleteCurrentRequest()
    {
        if (CurrentRequest == null)
            throw new InvalidOperationException(
                "Associate does not have an active request.");

        CurrentRequest = null;
        Status = AssociateStatus.Available;
    }
}



public enum AssociateStatus
{
    Available,
    Busy,
    Unavailable
}