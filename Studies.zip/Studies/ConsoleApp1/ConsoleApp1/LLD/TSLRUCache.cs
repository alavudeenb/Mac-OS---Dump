
/*WriteOrUpdate
    - Check if key exists
        - Yes
            - Update Linked list node with new value
            - Move Linked list node before head and mark it as head
        - No
            - Check Cache Limit is reached
                - Yes
                    - store last node/tail node in a temp variable
                    - mark last node.previous node as tail node 
                    - previous nodes->next as null and also temp -> previousnode as null
                    - Remove the same node from dictionary
                - No
                    - Create Node with Key and Value. The reason for key is when removing Least recently used node from linked list the same should be removed from dict
                    - Add new node before head and mark it as head

//Read
    - Check if key eixsts
        - Yes
            - Move linked list node before head and mark it as head
            - return the value
        - No
            - Throw exception






*/

using System.Runtime.InteropServices;

public class ThreadSafeLRUCache : IInMemoryCache
{

    int cacheLimit;

    Dictionary<string, Node> dictionary = new Dictionary<string, Node>();

    DoublyLinkedList doublyLinkedList = new DoublyLinkedList();

    object _sync = new object();

    public ThreadSafeLRUCache(int cacheLimit)
    {
        this.cacheLimit = cacheLimit;
    }

    public bool WriteOrUpdate(string key, string value)
    {
        lock (_sync)
        {
            Node currentNode;
            if (this.dictionary.TryGetValue(key, out currentNode))
            {
                currentNode.Value = value;
                doublyLinkedList.AddInTheBegining(currentNode);
            }
            else
            {
                if (this.dictionary.Count == cacheLimit)
                {
                    var evictedNode = this.doublyLinkedList.Evict();
                    this.dictionary.Remove(evictedNode.Key);
                }
                currentNode = new Node() { Key = key, Value = value };
                this.doublyLinkedList.Add(currentNode);
                this.dictionary.Add(key, currentNode);
            }

            return true;
        }
    }

    public string Read(string key)
    {
        lock (_sync)
        {
            Node currentNode;
            if (this.dictionary.TryGetValue(key, out currentNode))
            {
                this.doublyLinkedList.AddInTheBegining(currentNode);
                return currentNode.Value;
            }
            throw new KeyNotFoundException($"Given key {key} not found");
        }
    }
}


public interface IInMemoryCache
{
    bool WriteOrUpdate(string key, string vlaue);

    string Read(string key);
}

public class DoublyLinkedList
{
    Node head;

    Node tail;

    public Node Head
    {
        get
        {
            return this.head;
        }
    }

    public Node Tail
    {
        get
        {
            return this.tail;
        }
    }

    public void Add(Node node)
    {
        if (this.head == null && this.tail == null)
        {
            this.head = node;
            this.tail = node;
        }
        else
        {
            this.head.Previous = node;
            node.Next = this.head;
            this.head = node;
        }
    }

    public void AddInTheBegining(Node node)
    {
        if (this.head == node) return;

        if (this.tail == node) this.tail = node.Previous;

        var previosuNode = node.Previous;
        var nextNode = node.Next;

        if (previosuNode != null)
            previosuNode.Next = nextNode;

        if (nextNode != null)
            nextNode.Previous = previosuNode;

        this.head.Previous = node;
        node.Previous = null;
        node.Next = this.head;

        this.head = node;
    }

    public Node Evict()
    {
        var temp = this.tail;
        this.tail = this.tail.Previous;
        if (this.tail != null)
            this.tail.Next = null;
        temp.Previous = null;
        temp.Next = null;

        return temp;
    }
}


public class Node
{
    public string Key { get; set; }

    public string Value { get; set; }

    public Node Previous { get; set; }

    public Node Next { get; set; }
}