public class MinimumNumberOfPlatform
{
    public int Find(int[] arrivalTimes, int[] depatureTimes) // O(2n) = O(n)
    {
        var platformsCount = 0;

        Array.Sort(arrivalTimes); // O(n logn)
        Array.Sort(depatureTimes); // O(n logn)

        var arrivalTimesPointer = 0;
        var depatureTimesPointer =0;

        var currentPlatformCount = 0;
        while(arrivalTimesPointer < arrivalTimes.Length) // O(n)
        {
            if(arrivalTimes[arrivalTimesPointer] < depatureTimes[depatureTimesPointer])
            {
                currentPlatformCount++;
                arrivalTimesPointer++;
            }
            else
            {
                currentPlatformCount--;
                depatureTimesPointer++;
            }
            platformsCount = Math.Max(platformsCount, currentPlatformCount);
        }
        return platformsCount;
    }
}