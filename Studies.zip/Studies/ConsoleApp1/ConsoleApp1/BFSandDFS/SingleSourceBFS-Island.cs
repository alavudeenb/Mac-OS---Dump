using System.ComponentModel.DataAnnotations.Schema;

public class SingleSourceBFS_Island
{
    public int FindNumberOfIslands(int[,] areaInput)
    {
        var numberOfIslands = 0;

        var visitedArray = new bool[areaInput.GetLength(0), areaInput.GetLength(1)];

        for(int row = 0; row < areaInput.GetLength(0); row++) // O(n*m)
        {
            for(int column=0; column < areaInput.GetLength(1); column++)
            {
                if(areaInput[row, column] == 1 && !visitedArray[row,column])
                {
                    numberOfIslands++;
                    visitedArray[row, column] = true;
                    VisitAllLandsThroughBFS(row, column, areaInput, visitedArray);
                }
            }
        }
        return numberOfIslands;
    }

    private void VisitAllLandsThroughBFS(int row, int column, int[,] areaInput, bool[,] visitedArray)
    {
        var queue = new Queue<(int row, int column)>();
        queue.Enqueue((row, column));

        while(queue.Count>0)
        {
            var currentCell = queue.Dequeue();
            //var directions = new[,] { { -1, -1 }, { -1, 0 }, { -1, 1 }, { 0, -1 }, { 0, 1 }, { 1, -1 }, { 1, 0 }, { 1, 1 } };

            var directions = new[,] { { -1, 0 }, { 0, -1 }, { 0, 1 }, { 1, 0 } };

            for(int ind = 0; ind<directions.GetLength(0); ind++)
            {
                var currentRow = directions[ind,0]+ currentCell.row;
                var currentColumn = directions[ind, 1] + currentCell.column;

                if(currentRow >= 0 && 
                   currentRow < areaInput.GetLength(0) && 
                   currentColumn >= 0 && 
                   currentColumn < areaInput.GetLength(1) && 
                   areaInput[currentRow, currentColumn] == 1 &&
                   !visitedArray[currentRow, currentColumn])
                {
                    visitedArray[currentRow, currentColumn] = true;
                    queue.Enqueue((currentRow, currentColumn));
                }
            }
        }
    }
}