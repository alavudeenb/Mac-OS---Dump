public class DFS_Island
{
    public int FindNumberOfIslands(int[,] areaInput)
    {
        var numberOfIslands=0;
        var visisted = new bool[areaInput.GetLength(0), areaInput.GetLength(1)];

        for(int row = 0; row < areaInput.GetLength(0); row++) //O(n*m)
        {
            for(int column = 0; column < areaInput.GetLength(1); column++)
            {
                if(areaInput[row, column] == 1 && !visisted[row, column])
                {
                    numberOfIslands++;
                    visisted[row, column] = true;
                    DFS(row, column, areaInput, visisted);
                }
            }
        }
        return numberOfIslands;
    }

    private void DFS(int row, int column, int[,] areaInput, bool[,] visited)
    {
        var directions = new[,] { { -1, 0 }, { 0, -1 }, { 0, 1 }, { 1, 0 } };

        for(int ind = 0; ind < directions.GetLength(0); ind++)
        {
            var currentRow = directions[ind,0]+row;
            var currentColumn = directions[ind,1]+column;
            if (currentRow >= 0 && 
                currentRow < areaInput.GetLength(0) && 
                currentColumn >= 0 && 
                currentColumn < areaInput.GetLength(1) &&
                areaInput[currentRow, currentColumn] == 1&&
                !visited[currentRow, currentColumn])
            {
                visited[currentRow, currentColumn] = true;
                DFS(currentRow, currentColumn, areaInput, visited);
            }
        }
    }
}