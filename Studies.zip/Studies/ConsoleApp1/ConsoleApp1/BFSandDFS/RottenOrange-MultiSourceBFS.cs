public class RottenOrrange_MultiSourceBFS
{
    public int FindTimeTakenToRottenAllOranges(int[,] girdOfOranges)
    {
        var timeTaken = 0;
        var visited = new bool[girdOfOranges.GetLength(0), girdOfOranges.GetLength(1)];

        var inputArray = new int[girdOfOranges.GetLength(0), girdOfOranges.GetLength(1)];

        var queue = new Queue<(int row, int column)>();
        for (int row = 0; row < girdOfOranges.GetLength(0); row++)
        {
            for (int column = 0; column < girdOfOranges.GetLength(1); column++)
            {
                inputArray[row, column] = girdOfOranges[row, column];
                if (inputArray[row, column] == 2 && !visited[row, column])
                {
                    queue.Enqueue((row, column));
                    visited[row, column] = true;
                }
            }
        }
        timeTaken =MultiSoruceBFS(queue, inputArray, visited);
        return timeTaken;

    }

    private int MultiSoruceBFS(Queue<(int row, int column)> queue, int[,] inputArray, bool[,] visited)
    {
        var timeTaken = 0;

        while (queue.Count > 0)
        {
            var size = queue.Count;
var boolDone = false;
            for (int qInd = 0; qInd < size; qInd++)
            {
                var currentCell = queue.Dequeue();
                var directions = new[,] { { -1, 0 }, { 0, -1 }, { 0, 1 }, { 1, 0 } };

                for (int ind = 0; ind < directions.GetLength(0); ind++)
                {
                    var currentRow = directions[ind, 0] + currentCell.row;
                    var currentColumn = directions[ind, 1] + currentCell.column;
                    if (currentRow >= 0 &&
                        currentRow < inputArray.GetLength(0) &&
                        currentColumn >= 0 &&
                        currentColumn < inputArray.GetLength(1) &&
                        inputArray[currentRow, currentColumn] == 1 &&
                        !visited[currentRow, currentColumn])
                    {
                        queue.Enqueue((currentRow, currentColumn));
                        visited[currentRow, currentColumn] = true;
                        boolDone = true;
                    }
                }
            }
            if (boolDone)
                timeTaken++;
        }
        return timeTaken;
    }
}