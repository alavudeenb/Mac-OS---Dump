using Microsoft.VisualBasic;

public class PairsLessThanTarget
{
    public int Find(int[] inputArray, int target) // O(nlog n) + O(n)
    {
        var count = 0;
        var leftPointer = 0;
        var rightPointer = inputArray.Length-1;

        Array.Sort(inputArray);

        while (leftPointer < rightPointer)
        {
            if(inputArray[leftPointer] + inputArray[rightPointer] >= target)
            {
                rightPointer--;
            }
            else
            {
                count = count + (rightPointer - leftPointer);
                leftPointer++;
            }
        }
        return count;
    }
}