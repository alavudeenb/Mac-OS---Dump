public class LinkedListCyclic
{
    public bool Find(SingleyLinkedList input)
    {
        bool IsCyclic = false;

        var slowPointer = input;
        var fastPointer = input;

        while(slowPointer != null && fastPointer != null && fastPointer.Next != null)
        {
            slowPointer =slowPointer.Next;
            fastPointer = fastPointer.Next.Next;

            if(slowPointer == fastPointer)
                return true;
        }

        return IsCyclic;
    }
}