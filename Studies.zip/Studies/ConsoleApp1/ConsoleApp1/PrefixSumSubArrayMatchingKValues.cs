public class PrefixSumSubArrayMatchingKValues
{
    public List<int[]> Find(int[] inputArray, int k) // O(2n) = O(n)
    {
        var output= new List<int[]>();
        var prefixSumArray = new int[inputArray.Length];
        var indexTrackingDictionary = new Dictionary<int, int>();
        indexTrackingDictionary.Add(0, -1);

        prefixSumArray[0] = inputArray[0];
        indexTrackingDictionary.Add(inputArray[0], 0);
        for (int ind = 1; ind<inputArray.Length; ind++) // O(n)
        {
            prefixSumArray[ind] = prefixSumArray[ind-1]+inputArray[ind];
            indexTrackingDictionary.Add(prefixSumArray[ind], ind);
        }

        for(int ind = 0; ind < prefixSumArray.Length; ind++) // O(n)
        {
            var currentSum = prefixSumArray[ind];
            var currentSum_k = currentSum-k;
            int index = 0;

            if(indexTrackingDictionary.TryGetValue(currentSum_k, out index))
            {
                var tempOutput = new List<int>();
                for(int foundInd = index+1; foundInd <= ind; foundInd++)
                {
                    tempOutput.Add(inputArray[foundInd]);
                }
                output.Add(tempOutput.ToArray());
            }
        }
        return output;


    }
}