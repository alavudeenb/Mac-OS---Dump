﻿using System.Collections.Concurrent;
using System.Reflection.Metadata;
using System.Runtime.CompilerServices;
using Microsoft.VisualBasic;

Console.WriteLine("Hello, World!");

/*
int inputValue = 70;
Console.WriteLine(inputValue);

string companyName = "Microsoft";
Console.WriteLine(companyName);

var inputArray = new[] {10,20,30,40,50};
for(int ind = 0; ind< inputArray.Length; ind++)
{
    Console.WriteLine(inputArray[ind]);
}

var list = new List<string>();
list.Add("Microsoft");
list.Add("Google");
list.Add("Amazon");
foreach(var item in list)
{
    Console.WriteLine(item);
}

var stack = new Stack<string>();
stack.Push("Three");
stack.Push("Two");
stack.Push("One");

while(stack.Count > 0)
{
    Console.WriteLine(stack.Pop());
}

var queue = new Queue<string>();
queue.Enqueue("one");
queue.Enqueue("Two");
queue.Enqueue("Three");

while(queue.Count > 0)
{
    Console.WriteLine(queue.Dequeue());
}

var hashSet = new HashSet<string>();
hashSet.Add("Microsoft");
hashSet.Add("Google");
hashSet.Add("Apple");

Console.WriteLine($"Apple present in the hashSet:{hashSet.Contains("Apple")}");

var minHeap = new PriorityQueue<string, int>();
minHeap.Enqueue("Microsoft", 1);
minHeap.Enqueue("Google", 2);
minHeap.Enqueue("Amazon", 3);

while(minHeap.Count > 0)
{
    Console.WriteLine(minHeap.Dequeue());
}


var maxHeap = new PriorityQueue<string, int>(Comparer<int>.Create((x,y) => y.CompareTo(x)));
maxHeap.Enqueue("Microsoft", 1);
maxHeap.Enqueue("Google", 2);
maxHeap.Enqueue("Amazon", 3);

while(maxHeap.Count> 0)
{
    Console.WriteLine(maxHeap.Dequeue());
}
*/

/*var maxSumSubArray = new MaxSumSubArray().Find(new[] {1, -3, 4, -1, 2, 1, -5, 4}); // output: 6 i.e [4, -1, 2, 1]
Console.WriteLine($"MaxSum: {maxSumSubArray}");


var lengthOfLongestUniqueSubArray = new LengthOfLongestUniqueSubArray().Find(new[] {'a', 'b', 'c', 'b', 'd', 'a', 'e', 'f', 'g', 'b', 'c', 'b', 'b'}); // output: 7  { 'c', 'b', 'd', 'a', 'e', 'f', 'g' }
Console.WriteLine($"Length of longest unique subarray:{lengthOfLongestUniqueSubArray}");

var maxWaterTrap = new MaxWaterTrap().Find(new[] {1, 8, 6, 2, 5, 4, 8, 3, 7}); // output: 49
Console.WriteLine($"Max water trap: {maxWaterTrap}");

var numberOfPairs = new PairsLessThanTarget().Find(new[] { -6, 2, 5, -2, -7, -1, 3 }, target: -2); // output: 10
Console.WriteLine($"Total number of pairs less than target: {numberOfPairs}");

var numberOfPairsWithInTheRange = new FindPairsInRange().FindNumberOfPairs(new[] {5, 1, 2, 4, 3}, startRange:5, endRange:8);//(new[] { 0, 1, 7, 4, 4, 5 }, startRange: 3, endRange: 6); // output 6
Console.WriteLine($"Number of pairs:{numberOfPairsWithInTheRange}");


var maxFrequencyOfFrequentElement = new MaxFrequencyOfFrequentElement().Find(new[] { 1, 4, 8, 13 }, numberOfOperations: 5); // output: 2
Console.WriteLine($"Max frequency of frequent element: {maxFrequencyOfFrequentElement}");


var listOfExactMatchingPairs = new ExactMatch().Find(inputArray: new[] { 1, 3, 7, 5, 2, 9 }, target: 9); // 7,2
for (int ind = 0; ind < listOfExactMatchingPairs.Count; ind++)
    Console.WriteLine($"Pairs firstvalue:{listOfExactMatchingPairs[ind].Item1} secondvalue:{listOfExactMatchingPairs[ind].Item2}");


var inputArray = new[] {1, 0, 7, 12, 0, 0}; // output 1,7,12,0,0,0
new AllZerosToRight().Execute(inputArray);
for(int ind = 0; ind<inputArray.Length; ind++)
    Console.Write($"{inputArray[ind]} ");
Console.WriteLine();


var inputCharactersArray = new[] { 'a', 'a', 'a', 'b', 'b', 'b', 'c', 'c' }; // output: 2 
var minimumNumberOfDeletion = new MinimumCharacterDeletionToMakeCharacterUnique().Get(inputCharactersArray);
Console.WriteLine($"Minimum number of deletion:{minimumNumberOfDeletion}");

var intervals = new[]
{
    new[] { 1, 3 },
    new[] { 2, 4 },
    new[] { 6, 8 },
    new[] { 9, 10 }
};
var mergedIntervals = new MergeOverlappingIntervals().Get(intervals); // {{1,4},{6,8},{9,10}}
foreach(var item in mergedIntervals)
    Console.WriteLine($"Merged Intervals - StartTime: {item.startTime} EndTime: {item.endTime}");



var stringsWithCommonCharacters = new[] { "flower", "flow", "flicker" }; // output: fl
var commonString = new CommonStringAcrossArray().Find(stringsWithCommonCharacters);
Console.WriteLine($"Common string is: {commonString}");


var inputArrayForPrefixSum = new[] {1, 2, 3, -2, 4}; // output: {2, 3} {3, -2, 4}
var k = 5;
var subArrayMatchingKValues = new PrefixSumSubArrayMatchingKValues().Find(inputArrayForPrefixSum, k);
foreach(var arrayItem in subArrayMatchingKValues)
    foreach(var elements in arrayItem)
        Console.WriteLine($"SubArray matching K values: {elements}");


var arrivalTimes = new[] {900, 940, 950, 1100, 1500, 1800}; // output: 3
var depatureTimes = new[] { 910, 1200, 1120, 1130, 1900, 2000 };
var minimumNumberOfPlatform = new MinimumNumberOfPlatform().Find(arrivalTimes, depatureTimes);
Console.WriteLine($"Minimum number of platforms: {minimumNumberOfPlatform}");


var inputArrayOfElements1 = new[] { 2, 1, 5, 6, 2, 3 }; // output: {5, 5, 6, -1, 3, -1}
var nextGreaterElements = new NextGreaterElement().Get(inputArrayOfElements1);
for(int ind = 0; ind< nextGreaterElements.Length; ind++)
    Console.WriteLine($"Next Greater Element: input:{inputArrayOfElements1[ind]} next greater element: {nextGreaterElements[ind]}");


var singleyLinkedList = new SingleyLinkedList() { Data = 1 }; // output: 5 -> 4 -> 3 -> 2 -> 1
singleyLinkedList.Next = new SingleyLinkedList() { Data = 2, Next = new SingleyLinkedList(){Data = 3, Next = new SingleyLinkedList(){Data = 4, Next = new SingleyLinkedList(){Data = 5}}}};
var pointer = new ReverseLinkedList().Get(singleyLinkedList);
while(pointer!= null)
{
    Console.WriteLine($"SingleyLinkedList: {pointer.Data}");
    pointer = pointer.Next;
}


var singleyLinkedList1 = new SingleyLinkedList() { Data = 1 }; // output: 3
singleyLinkedList1.Next = new SingleyLinkedList() { Data = 2, Next = new SingleyLinkedList(){Data = 3, Next = new SingleyLinkedList(){Data = 4, Next = new SingleyLinkedList(){Data = 5}}}};
var middleNode = new MiddleNodeInTheLinkedList().Find(singleyLinkedList1);
Console.WriteLine($"MiddleNode is: {middleNode.Data}");


var singleyLinkedList2 = new SingleyLinkedList() {Data = 1};
singleyLinkedList2.Next = new SingleyLinkedList() { Data = 2, Next = new SingleyLinkedList() { Data = 3, Next = new SingleyLinkedList() { Data = 4, Next = singleyLinkedList2 } } };
var IsCyclic = new LinkedListCyclic().Find(singleyLinkedList2);
Console.WriteLine($"Linked list is cyclic: {IsCyclic}");


var areaInput = new int[,] { { 1, 1, 0, 0, 0 }, { 1, 1, 0, 0, 0 }, { 0, 0, 1, 0, 0 }, { 0, 0, 0, 1, 1 } };
var numberOfIslands = new SingleSourceBFS_Island().FindNumberOfIslands(areaInput);
Console.WriteLine($"Number of islands:{numberOfIslands}");


var numberOfIslands_dfs = new DFS_Island().FindNumberOfIslands(areaInput);
Console.WriteLine($"DFS Number of islands:{numberOfIslands}");


var inputArray = new[,] { { 2, 1, 1 }, { 1, 1, 0 }, { 0, 1, 1 } };
var result = new RottenOrrange_MultiSourceBFS().FindTimeTakenToRottenAllOranges(inputArray);
Console.WriteLine(result);*/

//new Playground1.FlashSale().SimulateFlashSale();


/* ICache cache = new LRUCache();
var vegKey = "Vegetables";

cache.Write(vegKey, "BottleGuard");
Console.WriteLine($"Vegetables:{cache.Read(vegKey)}");

var fruitsKey = "Fruits";
cache.Write(fruitsKey, "Banana");
Console.WriteLine($"Fruits: {cache.Read(fruitsKey)}"); 

var concurrentDictionary = new ConcurrentDictionary<string, string>();
concurrentDictionary.TryAdd("Key1", "Value1");
concurrentDictionary.GetOrAdd("Key2", "Value2");
concurrentDictionary.AddOrUpdate("Key3", "Value3", (key, oldValue) => { return "OldValue"; });
concurrentDictionary.TryRemove("Key1", out _);

string result;
concurrentDictionary.TryGetValue("Key2", out result);
Console.WriteLine($"Key:Key2 Value:{result}");


var flashSaleConcurrentDictionary = new ConcurrentDictionary<string, Lazy<Task<string>>>();
var flashSaleResult = flashSaleConcurrentDictionary.GetOrAdd("Key1", (key) => new Lazy<Task<string>>(() => GetValue(key)));
Console.WriteLine($"Result: {flashSaleResult.Value.Result}");


async Task<string> GetValue(string key)
{
    await Task.Delay(1000);
    return "Read from DB";
}*/


/*var threadSafeLRUCache = new ThreadSafeLRUCache();
threadSafeLRUCache.Write("Key1", "value1");
threadSafeLRUCache.Write("Key2", "value2");
threadSafeLRUCache.Write("Key3", "value3");

Console.WriteLine(threadSafeLRUCache.Read("Key1"));*/


/*var KthPermutation = new KthPermutation().Find(n:4, k:17); // output: 3412
Console.WriteLine(KthPermutation);*/

/*var input = new List<(int node, List<int>)>();
input.Add((1, new List<int>() { 2, 3, 4 }));
input.Add((2, new List<int>() { 1, 3, 5 }));
input.Add((3, new List<int>() { 1, 2, 4 }));
input.Add((4, new List<int>() { 1, 3 }));
input.Add((5, new List<int>() { }));

var possibleToColorAllVertxes =new MColoring().Find(input, mColors: 3); // output yes (1) 1 -> 1, 2 -> 2, 3 -> 3, 4 -> 2, 5 -> 1

//var possibleToColorAllVertxes = new MColoring().Find(input, mColors: 2); // output no (0) 
Console.WriteLine($"Is it possible to color all vertexs: {possibleToColorAllVertxes}");*/

/*var resultMatrix = new NQueen().Find(4);

for(int row = 0; row < resultMatrix.GetLength(0); row++)
{
    for(int column = 0; column < resultMatrix.GetLength(1); column++)
    {
        Console.WriteLine($"Row:{row} Column:{column} Value:{resultMatrix[row, column]}");
    }
}*/


var input = new[] { 1, 2, 3 };
new PrintAllPermutationsOfStringOrArray_Recursion2().PrintAll(input);