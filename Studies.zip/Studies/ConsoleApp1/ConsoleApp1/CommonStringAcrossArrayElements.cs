public class CommonStringAcrossArray
{
    public string Find(string[] inputStrings) // O(n*m)
    {
        var output = new List<char>();
        for(int charInd=0; charInd < inputStrings[0].Length; charInd++ ) // n is the length of first string
        {
            for(int inputStringArrayInd = 1; inputStringArrayInd < inputStrings.Length; inputStringArrayInd++) // m strings in the string array
            {
                //Since charInd is 0 based index, -1 should be present in inputStrings[inputStringArrayInd].Length - 1 to make it 0 based index
                if (inputStrings[inputStringArrayInd].Length - 1 < charInd || inputStrings[0][charInd] != inputStrings[inputStringArrayInd][charInd])
                {
                    return new string(output.ToArray());
                }
            }
            output.Add(inputStrings[0][charInd]);
        }
        return new string(output.ToArray());
    }
}