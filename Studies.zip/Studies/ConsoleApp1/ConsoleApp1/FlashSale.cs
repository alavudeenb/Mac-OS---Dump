using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Playground1
{
    internal class FlashSale
    {
        string key = "userabc";

        Dictionary<string, string> cache = new Dictionary<string, string>();
        ConcurrentDictionary<string, Lazy<Task<string>>> inFlight = new ConcurrentDictionary<string, Lazy<Task<string>>>();

        public void SimulateFlashSale()
        {
            Parallel.For(0, 9, (input) =>
            {
                var result = GetCacheValue(key);
                
            });
        }

        string GetCacheValue(string key)
        {
            string cacheValue = string.Empty;

            if (cache.TryGetValue(key, out cacheValue))
                return cacheValue;

            var result = inFlight.GetOrAdd(key, (key) =>
            {
                var obj = new Lazy<Task<string>>(() => GetValue(key));
                Console.WriteLine($"HashCode: {obj.GetHashCode()}");
                return obj;
            });

            try
            {
                return result.Value.Result;
            }
            finally
            {
                Console.WriteLine($"Finally HashCode: {result.GetHashCode()}");
                inFlight.TryRemove(new KeyValuePair<string, Lazy<Task<string>>>(key, result));
            }
        }

        async Task<string> GetValue(string key)
        {
            var keyValue = await GetDBValue(key);
            cache[key] = keyValue; //Storing value in cache
            return keyValue;
        }

        async Task<string> GetDBValue(string key)
        {
            Console.WriteLine($"Before Logging: {DateTime.UtcNow.ToString("yyyy-MM-dd HH:mm:ss.fff")}");
            await Task.Delay(1000); //Load from db
            Console.WriteLine($"After Logging: {DateTime.UtcNow.ToString("yyyy-MM-dd HH:mm:ss.fff")}");

            return DateTime.UtcNow.ToString("yyyy-MM-dd HH:mm:ss.fff");
        }
    }
}