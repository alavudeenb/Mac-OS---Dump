public class ReverseLinkedList
{
    public SingleyLinkedList Get(SingleyLinkedList input)
    {
        var head = input;
        var leftPointer = head;
        var rigthPointer = head.Next;

        while(leftPointer != null && rigthPointer != null) // O(n)
        {
            if(head == leftPointer)
                leftPointer.Next = null;

            var temp = rigthPointer;
            rigthPointer = rigthPointer.Next;
            temp.Next = leftPointer;
            leftPointer = temp;
        }
        return leftPointer;
    }
}


public class SingleyLinkedList
{
    public SingleyLinkedList Next { get; set; }
    public int Data { get; set; }
}