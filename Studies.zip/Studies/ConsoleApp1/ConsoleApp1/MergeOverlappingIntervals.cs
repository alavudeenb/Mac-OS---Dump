public class MergeOverlappingIntervals
{
    public List<(int startTime, int endTime)> Get(int[][] inputIntervals) // O(n logn)
    {
        var output = new List<(int startTime, int endTime)>();
        var stack = new Stack<(int startTime, int endTime)>();

        Array.Sort(inputIntervals, (a,b) =>  //O(n log n)
        {
            var result = a[0].CompareTo(b[0]);

            if(result != 0)
             return a[1].CompareTo(b[1]);

            return result;
        });

        stack.Push((inputIntervals[0][0], inputIntervals[0][1]));

        for (int ind = 1; ind < inputIntervals.GetLength(0); ind++) // O(n)
        {
            var previousElement = stack.Peek();
            var currentElement = (startTime:inputIntervals[ind][0], endTime:inputIntervals[ind][1]);

            if(currentElement.startTime < previousElement.endTime)
            {
                if(currentElement.endTime > previousElement.endTime)
                {
                    previousElement = stack.Pop();
                   stack.Push((previousElement.startTime, currentElement.endTime));
                }
            }
            else
            {
                stack.Push(currentElement);
            }
        }

        while(stack.Count > 0) // O(n)
        {
            output.Add(stack.Pop());
        }

        return output;
    }
}