public class MaxFrequencyOfFrequentElement
{
    public int Find(int[] inputArray, int numberOfOperations) // O(2n)
    {
        var max=0;
        var leftPointer = 0;
        var total = 0;

        for(int rightPointer = 0; rightPointer < inputArray.Length; rightPointer++)
        {
            total = total + inputArray[rightPointer];

            while (leftPointer < rightPointer && inputArray[rightPointer] * ((rightPointer - leftPointer) + 1) > total + numberOfOperations)
            {
                total = total - inputArray[leftPointer];
                leftPointer++;
            }

            max = Math.Max(max, (rightPointer - leftPointer) + 1);
        }

        return max ;
    }
}