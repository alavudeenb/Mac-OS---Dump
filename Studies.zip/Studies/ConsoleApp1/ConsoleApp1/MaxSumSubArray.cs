public class MaxSumSubArray
{
    public int Find(int[] inputArray) // O(n)
    {
        var maxSum=0;
        var localSum = 0;
        for(int ind = 0; ind < inputArray.Length; ind++)
        {
            if(localSum+inputArray[ind] > inputArray[ind])
            {
                localSum = localSum+inputArray[ind];
            }
            else
            {
                localSum = inputArray[ind];
            }
            
            maxSum = Math.Max(maxSum, localSum);
        }

        return maxSum;
    }
}