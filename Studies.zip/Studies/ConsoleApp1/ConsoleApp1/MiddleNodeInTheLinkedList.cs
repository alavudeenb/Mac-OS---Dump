public class MiddleNodeInTheLinkedList
{
    public SingleyLinkedList Find(SingleyLinkedList input) // O(n)
    {
        var slowPointer = input;
        var fastPointer = input;

        while (slowPointer != null && fastPointer != null && fastPointer.Next != null)
        {
            slowPointer = slowPointer.Next;
            fastPointer = fastPointer.Next.Next;
        }
        return slowPointer;
    }
}