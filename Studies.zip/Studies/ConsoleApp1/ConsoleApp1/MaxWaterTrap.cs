public class MaxWaterTrap
{
    public int Find(int[] waterLevels) // O(n)
    {
        var maxWaterTrap = 0;
        var leftPointer = 0;
        var rightPointer = waterLevels.Length-1;

        while(leftPointer < rightPointer)
        {
            var width = rightPointer - leftPointer;
            var heigth = Math.Min(waterLevels[leftPointer], waterLevels[rightPointer]);

            maxWaterTrap = Math.Max(maxWaterTrap, width * heigth);

            if(waterLevels[leftPointer] > waterLevels[rightPointer])
            {
                rightPointer--;
            }
            else
            {
                leftPointer++;
            }
        }

        return maxWaterTrap;
    }
}