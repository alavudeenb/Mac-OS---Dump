public class LengthOfLongestUniqueSubArray
{
    public int Find(char[] input) //O(n)
    {
        var maxLength = 0;
        var leftPointer = 0;
        var hashSet = new HashSet<char>();

        for (int rightPointer = 0; rightPointer < input.Length; rightPointer++)
        {
            while (hashSet.Contains(input[rightPointer]))
            {
                hashSet.Remove(input[leftPointer]);
                leftPointer++;
            }
            hashSet.Add(input[rightPointer]);

            maxLength = Math.Max(maxLength, rightPointer - leftPointer);
        }
        return maxLength + 1;
    }
}