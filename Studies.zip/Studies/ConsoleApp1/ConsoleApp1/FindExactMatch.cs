public class ExactMatch
{
    public List<(int,int)> Find(int[] inputArray, int target) // O(n)
    {
        var output = new List<(int, int)>();
        var hashSet = new HashSet<int>();

        for(int ind = 0; ind < inputArray.Length; ind++)
        {
            if(hashSet.Contains(target-inputArray[ind]))
            {
                output.Add((target-inputArray[ind], inputArray[ind]));
            }
            hashSet.Add(inputArray[ind]);
        }
        return output;
    }
}