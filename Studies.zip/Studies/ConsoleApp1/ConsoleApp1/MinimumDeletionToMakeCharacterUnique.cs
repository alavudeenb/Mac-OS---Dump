public class MinimumCharacterDeletionToMakeCharacterUnique
{
    public int Get(char[] inputCharactersArray) // O(3n) => O(n)
    {
        var minimumDeletion = 0;
        var frequencyByCharacterDictionary = new Dictionary<char, int>();
        var maxHeap = new PriorityQueue<int, int>(Comparer<int>.Create((x,y) => y.CompareTo(x)));

        for(int ind = 0; ind < inputCharactersArray.Length; ind++) // O(n)
        {
            if(frequencyByCharacterDictionary.ContainsKey(inputCharactersArray[ind]))
               frequencyByCharacterDictionary[inputCharactersArray[ind]] = frequencyByCharacterDictionary[inputCharactersArray[ind]]+1;
            else
                frequencyByCharacterDictionary[inputCharactersArray[ind]] = 1;
        }

        foreach (var item in frequencyByCharacterDictionary) // O(n)
            maxHeap.Enqueue(item.Value, item.Value);

        var previousFrequency = Int32.MaxValue;
        while(maxHeap.Count > 0) // O(n)
        {
            var currentFrequency = maxHeap.Dequeue();

            if(currentFrequency == previousFrequency)
            {
                var newFrequency = Math.Max(0, previousFrequency-1);
                minimumDeletion = minimumDeletion + currentFrequency - newFrequency;
                currentFrequency = newFrequency;
            }
            previousFrequency = currentFrequency;
        }

        return minimumDeletion;
    }
}