using System.Runtime.CompilerServices;

public class FindPairsInRange
{
    public int FindNumberOfPairs(int[] inputArray, int startRange, int endRange) // O(nlogn) + O(n) + O(n)
    {
        Array.Sort(inputArray);
        var upperBound = FindPairsLessThanTarget(inputArray, endRange+1);
        var lowerBound = FindPairsLessThanTarget(inputArray, startRange);

        return upperBound - lowerBound;
    }

    private int FindPairsLessThanTarget(int[] inputArray, int target)
    {
        var count = 0;
        var leftPointer = 0;
        var rightPointer = inputArray.Length - 1;

        while(leftPointer < rightPointer)
        {
            if(inputArray[leftPointer]+inputArray[rightPointer] >= target)
            {
                rightPointer--;
            }
            else
            {
                count = count + (rightPointer - leftPointer);
                leftPointer++;
            }
        }

        return count;
    }
}