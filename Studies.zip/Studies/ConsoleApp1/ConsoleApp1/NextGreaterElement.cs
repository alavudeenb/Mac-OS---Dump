public class NextGreaterElement
{
    public int[] Get(int[] inputArrayOfElements) // O(2n) = O(n)
    {
        var stack = new Stack<int>();
        int[] output = new int[inputArrayOfElements.Length];

        for (int ind = inputArrayOfElements.Length - 1; ind >= 0; ind--) // O(n)
        {
            while(stack.Count > 0 && stack.Peek() <= inputArrayOfElements[ind]) // O(n)
            {
                stack.Pop();
            }

            if(stack.Count>0 && stack.Peek() > inputArrayOfElements[ind])
                output[ind] = stack.Peek();
            else
                output[ind] = -1;

            stack.Push(inputArrayOfElements[ind]);
        }
        
        return output;
    }
}