// See https://aka.ms/new-console-template for more information
Console.WriteLine("Hello, World!");

string inputString = "123";
var result = FindWays(inputString, 0);

Console.WriteLine(result);


static int FindWays(string input, int index)
{
    int ways = 0;
    
    if (index >= input.Length)
        return 1;

    if (input[index] != '0')
        ways = FindWays(input, index + 1);

    if ((index + 1 < input.Length) &&
        ((input[index] == '1' && input[index + 1] <= '9') ||
         (input[index] == '2' && input[index + 1] <= '6')))
        ways = ways + FindWays(input, index + 2);

    return ways;
}
