/*Find given linked list is having cycle

Problem:
Given a singly linked list find is there any cycle

Solution:
Create fastPointer and slowPointer. fast pointer will be in 3rd position when slow pointer in 1rd postion i.e fast pointer = currentNode.Next.Next. where as slowpointer = currentNode.
loop until fastPointer is not null or slowPointer is not null or fastPointer.Next is not null
if fastPointer is equal to slowPointer (which means slowPointer overtook fastPointer)*/

public static class LinkedList
{
    public static bool IsCyclic(SinglyLinkedListNode linkedListNode)
    {
        bool isCyclic = false;

        var slowPointer = linkedListNode;
        var fastPointer = linkedListNode;

        while (slowPointer != null && fastPointer != null && fastPointer.Next != null)
        {
            slowPointer = slowPointer.Next;
            fastPointer = fastPointer.Next.Next;

            if (slowPointer == fastPointer)
            {
                isCyclic = true;
                break;
            }
        }

        return isCyclic;
    }
}

public class SinglyLinkedListNode
{
    public SinglyLinkedListNode Next { get; set; }

    public int Value { get; set; }
}



/*var input = new SinglyLinkedListNode();
input.Value = 1;
var secondNode = new SinglyLinkedListNode() { Value = 2 };
input.Next = secondNode;
var thirdNode = new SinglyLinkedListNode() { Value = 3 };
secondNode.Next = thirdNode;
var fourthNode = new SinglyLinkedListNode() { Value = 4 };
thirdNode.Next = fourthNode;
var fifthNode = new SinglyLinkedListNode() { Value = 5 };
fourthNode.Next = fifthNode;
fifthNode.Next = thirdNode;
var result = LinkedList.IsCyclic(input);
Console.WriteLine($"The linkedlist is cyclic or not: {result}");*/
