/*Given a singly linked list, reverse it

Problem:
Reverse the linked list

Solution:
Keep left, right pointer to track current and next liked list. Always check right pointer is not null. 

7 -> 4 -> 9 -> 3

left = 7
right = 4
7 <- 4 -> 9 -> 3
left = 4
right = 9

left = 4
right = 9
7 <- 4 <- 9 -> 3
left = 9
right = 3*/

public static class ReverseLinkedList
{
    public static SinglyLinkedListNode Reverse(SinglyLinkedListNode head)
    {
        SinglyLinkedListNode left = head;
        SinglyLinkedListNode right = head.Next;

        while (right != null)
        {
            if (left == head)
                left.Next = null;
          
            SinglyLinkedListNode temp = right;
            right = right.Next;
            temp.Next = left;
            left = temp;
        }

        return left;
    }
}




/*var input = new SinglyLinkedListNode();
input.Value = 1;
var secondNode = new SinglyLinkedListNode() { Value = 2 };
input.Next = secondNode;
var thirdNode = new SinglyLinkedListNode() { Value = 3 };
secondNode.Next = thirdNode;
var fourthNode = new SinglyLinkedListNode() { Value = 4 };
thirdNode.Next = fourthNode;
var fifthNode = new SinglyLinkedListNode() { Value = 5 };
fourthNode.Next = fifthNode;
var sixthNode = new SinglyLinkedListNode() { Value = 6 };
fifthNode.Next = sixthNode;
var result = ReverseLinkedList.Reverse(input);

while (result != null)
{
    Console.WriteLine(result.Value);
    result = result.Next;
}
*/