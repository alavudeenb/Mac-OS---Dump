/*Find middle node in the linked list

Problem:
Find middle node in a singly linked list in one iteration

Solution:
Let's have fast and slow pointers. fast pointer will be in 3rd position when slow pointer in 1rd postion i.e fast pointer = currentNode.Next.Next. where as slowpointer = currentNode.
loop until fastPointer is not null or fastPointer.Next is not null or fastPointer.Next.Next is not null.
*/
  public static class MiddleNodeInLinkedList
  {
      public static int FindMiddleNode(SinglyLinkedListNode linkedListNode)
      {
          bool isCyclic = false;

          var slowPointer = linkedListNode;
          var fastPointer = linkedListNode;

          while (slowPointer != null && fastPointer != null && fastPointer.Next != null)
          {
              slowPointer = slowPointer.Next;
              fastPointer = fastPointer.Next.Next;
          }

          return slowPointer != null ? slowPointer.Value : -1;
      }
  }



/*var input = new SinglyLinkedListNode();
input.Value = 1;
var secondNode = new SinglyLinkedListNode() { Value = 2 };
input.Next = secondNode;
var thirdNode = new SinglyLinkedListNode() { Value = 3 };
secondNode.Next = thirdNode;
var fourthNode = new SinglyLinkedListNode() { Value = 4 };
thirdNode.Next = fourthNode;
var fifthNode = new SinglyLinkedListNode() { Value = 5 };
fourthNode.Next = fifthNode;
//var sixthNode = new SinglyLinkedListNode() { Value = 6 };
//fifthNode.Next = sixthNode;
var result = MiddleNodeInLinkedList.FindMiddleNode(input);
Console.WriteLine(result);*/
