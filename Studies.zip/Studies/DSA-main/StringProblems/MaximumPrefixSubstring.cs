/*Given an array of strings, Find prefix substring that are matching across other strings

Problem:
Find prefix substring that are matching across other strings

Solution:
The time complexity of the algorithm in O(n). how ? The first for loop is to loop all characters of first string only. The second nested for loop is the loop all other "string"
but inside second for loop, the character position of first for loop is getting validated with same character position of all other string. To avoid outofbound exception,
(in case any one of the string from second string onwards is shorter than first thing), the length of the string will also get validated.

if there is a mismatch or length is shorter, return substring by taking from 0th index to ith (first for loop) index.*/

    public static class MaximumPrefixSubstring
    {
        public static string Get(string[] input)
        {
            string result = string.Empty;
            var length = 0;
            for (int i = 0; i < input[0].Length; i++)
            {
                for (int j = 1; j < input.Length; j++)
                {
                    if (i >= input[j].Length || input[0][i] != input[j][i])
                        return input[0].Substring(0, i);
                }
            }

            return result;
        }
    }

/*var input = new[] { "flower", "flow", "flicker" };
var result = MaximumPrefixSubstring.Get(input); 

Console.WriteLine(result);*/

