

// See https://aka.ms/new-console-template for more information
//Console.WriteLine("Hello, World!");

public class WordLadder
{

    public static void Find()
    {
        string[] input = new[] { "hot", "dot", "dog", "lot", "log", "cog" };
        string startWord = "hit";
        string endWord = "cog";

        var queue = new Queue<(string word, int level, List<string> sequenceWords)>();

        var hashSet = new HashSet<string>(input);
        var endWordFound = false;
        (string word, int level, List<string> sequenceWords) currentWord = (string.Empty, 0, new List<string>());

        queue.Enqueue((startWord, 0, new List<string>(new[] { startWord })));
        while (queue.Count > 0 && endWordFound == false)
        {
            currentWord = queue.Dequeue();

            if (currentWord.word == endWord)
            {
                endWordFound = true;
                break;
            }

            for (var init = 0; init < currentWord.word.Length; init++)
            {
                for (var alphabetsInit = Convert.ToInt32('a'); alphabetsInit <= Convert.ToInt32('z'); alphabetsInit++)
                {
                    var characterArray = currentWord.word.ToCharArray();
                    characterArray[init] = (char)alphabetsInit;
                    var transformedWord = new string(characterArray);

                    if (hashSet.Contains(transformedWord))
                    {
                        var sequenceWords = new List<string>(currentWord.sequenceWords);
                        sequenceWords.Add(transformedWord);
                        queue.Enqueue((transformedWord, currentWord.level + 1, sequenceWords));
                        hashSet.Remove(transformedWord);
                    }
                }
            }
        }

        if (endWordFound)
        {
            Console.WriteLine($"Found {currentWord.word} {currentWord.level} {string.Join("->", currentWord.sequenceWords)}");
        }
        else
        {
            Console.WriteLine("Not found");
        }

    }
}