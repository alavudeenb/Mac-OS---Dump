
//var input = new[] { 1, 12, -5, -6, 50, 3 };
//var slidingWindow = 4;
//var result = FixedSlidingWindow.GetAverageOfMaxSubArray(input, slidingWindow);
//Console.WriteLine(result);


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TwoPointers_Problems
{
    public static class FixedSlidingWindow
    {
        public static double GetAverageOfMaxSubArray(int[] input, int slidingWindow)
        {
            int sumOfMaxSubArray = 0;
            int previousSlidingWindowSum = 0;
            int leftIndex = 0;
            int rightIndex = slidingWindow;

            for (int counter = 0; counter < slidingWindow; counter++)
            {
                sumOfMaxSubArray = sumOfMaxSubArray + input[counter];
            }

            previousSlidingWindowSum = sumOfMaxSubArray;

            while (rightIndex < input.Length)
            {
                int tempSumOfMaxSubArray = (previousSlidingWindowSum - input[leftIndex]) + input[rightIndex];

                sumOfMaxSubArray = Math.Max(sumOfMaxSubArray, tempSumOfMaxSubArray);
                previousSlidingWindowSum = tempSumOfMaxSubArray;
                leftIndex = leftIndex + 1;
                rightIndex = rightIndex + 1;
            }

            return (double)sumOfMaxSubArray / slidingWindow;
        }
    }
}
