
//var input = new[] { 'a', 'b', 'c', 'b', 'd', 'a', 'e', 'f', 'g', 'b', 'c', 'b', 'b' };
//var result = DynamicSlidingWindow.GetLengthOfLongestUniqueSubstring(input);
//Console.WriteLine(result.Length);
//foreach (var item in result)
//    Console.Write(item);


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TwoPointers_Problems
{
    public static class DynamicSlidingWindow
    {
        public static char[] GetLengthOfLongestUniqueSubstring(char[] input)
        {
            int longestSubstringsLength = 0;
            var substrings = new List<char>();

            int leftPointer = 0;
            int rightPointer = 0;

            var tempHashSet = new HashSet<char>();

            while (rightPointer < input.Length)
            {
                if (tempHashSet.Add(input[rightPointer]))
                {
                    var lengthOfCharacters = rightPointer - leftPointer;
                    longestSubstringsLength = Math.Max(longestSubstringsLength, lengthOfCharacters);
                    rightPointer = rightPointer + 1;
                }
                else
                {
                    if (substrings.Count < tempHashSet.Count)
                    {
                        var tempSubStringArray = new char[tempHashSet.Count];
                        var lengthOfCharacters = rightPointer - leftPointer;
                        System.Array.Copy(input, leftPointer, tempSubStringArray, 0, lengthOfCharacters);
                        substrings = new List<char>(tempSubStringArray);
                    }
                    while (tempHashSet.Contains(input[rightPointer]))
                    {
                        tempHashSet.Remove(input[leftPointer]);
                        leftPointer = leftPointer + 1;
                    }
                }
            }

            //for (int _counter = 0; _counter < input.Length; _counter++)
            //{
            //    if (false == tempCharSubStrings.Add(input[_counter]))
            //    {
            //        if (substrings != null && substrings.Length < tempCharSubStrings.Count)
            //        {
            //            substrings = tempCharSubStrings.ToArray();
            //            tempCharSubStrings = new HashSet<char>();
            //        }
            //    }
            //}

            return substrings.ToArray();
        }
    }
}
