
//var graph = new Dictionary<int, List<(int neighbour, int weight)>>();
//graph.Add(1, new List<(int neighbour, int weight)>());
//graph.Add(2, new List<(int neighbour, int weight)>());
//graph.Add(3, new List<(int neighbour, int weight)>());
//graph.Add(4, new List<(int neighbour, int weight)>());
//graph.Add(5, new List<(int neighbour, int weight)>());
//graph.Add(6, new List<(int neighbour, int weight)>());
//graph.Add(7, new List<(int neighbour, int weight)>());

//var vertex1NeighboursAndWeight = graph[1];
//vertex1NeighboursAndWeight.Add((6, 10));
//vertex1NeighboursAndWeight.Add((2, 28));

//var vertex2NeighboursAndWeight = graph[2];
//vertex2NeighboursAndWeight.Add((1, 28));
//vertex2NeighboursAndWeight.Add((7, 14));
//vertex2NeighboursAndWeight.Add((3, 16));

//var vertex3NeighboursAndWeight = graph[3];
//vertex3NeighboursAndWeight.Add((2, 16));
//vertex3NeighboursAndWeight.Add((4, 12));

//var vertex4NeighboursAndWeight = graph[4];
//vertex4NeighboursAndWeight.Add((3, 12));
//vertex4NeighboursAndWeight.Add((7, 18)); // Comment this line for checking non cyclic scenario
//vertex4NeighboursAndWeight.Add((5, 22));

//var vertex5NeighboursAndWeight = graph[5];
//vertex5NeighboursAndWeight.Add((6, 25));  // Comment this line for checking non cyclic scenario
//vertex5NeighboursAndWeight.Add((7, 24)); // Comment this line for checking non cyclic scenario
//vertex5NeighboursAndWeight.Add((4, 22));

//var vertex6NeighboursAndWeight = graph[6];
//vertex6NeighboursAndWeight.Add((1, 10));
//vertex6NeighboursAndWeight.Add((5, 25)); // Comment this line for checking non cyclic scenario

//var vertex7NeighboursAndWeight = graph[7];
//vertex7NeighboursAndWeight.Add((2, 14));
//vertex7NeighboursAndWeight.Add((4, 18)); // Comment this line for checking non cyclic scenario
//vertex7NeighboursAndWeight.Add((5, 24)); // Comment this line for checking non cyclic scenario

//var result = DetectCycleInaGraph.IsTrue(graph);
//Console.WriteLine(result);
//Console.ReadLine();


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GreedyProblems
{
    public static class DetectCycleInaGraph
    {
        public static bool IsTrue(Dictionary<int, List<(int neighbour, int weight)>> graph)
        {
            var cycleTracker = new Dictionary<int, int>();
            var cycleFound = false;
            var minHeap = new PriorityQueue<(int u, int v), int>();
            var uniqueUV = new Dictionary<string, string>();

            foreach (var item in graph)
            {
                cycleTracker[item.Key] = -1;
            }

            foreach (var vertices in graph)
            {
                foreach (var edges in vertices.Value)
                {
                    var u = 0;
                    var v = 0;

                    if (edges.neighbour > vertices.Key)
                    {
                        u = vertices.Key;
                        v = edges.neighbour;
                    }
                    else
                    {
                        u = edges.neighbour;
                        v = vertices.Key;
                    }

                    (int u, int v) ucommav = (u, v);
                    string key = $"{ucommav.u},{ucommav.v}";
                    if (uniqueUV.ContainsKey(key) == false)
                    {
                        minHeap.Enqueue(ucommav, edges.weight);
                        uniqueUV.Add(key, key);
                    }
                    else if (uniqueUV.ContainsKey(key) == true && uniqueUV[key] != key)
                    {
                        minHeap.Enqueue(ucommav, edges.weight);
                        uniqueUV[key] = key;
                    }
                }
            }

            while (minHeap.Count > 0)
            {
                var ucommav = minHeap.Dequeue();

                var u = ucommav.u;
                var v = ucommav.v;

                var uParent = FindParent(u, cycleTracker);
                var vParent = FindParent(v, cycleTracker);

                if (uParent == vParent)
                {
                    cycleFound = true;
                    break;
                }

                if (cycleTracker[uParent] < 0 && cycleTracker[vParent] < 0) //Negative number in the dictionary indicates itself parent
                {
                    var uParentweightedUnion = (cycleTracker[uParent] * -1); //Making it positive number to check u or v is having more child vertices
                    var vParentweightedUnion = (cycleTracker[vParent] * -1); //Making it positive number to check u or v is having more child vertices

                    if (uParentweightedUnion >= vParentweightedUnion)
                    {
                        cycleTracker[uParent] = ((uParentweightedUnion + vParentweightedUnion) * -1);
                        cycleTracker[vParent] = uParent;
                    }
                    else
                    {
                        cycleTracker[vParent] = ((vParentweightedUnion + uParentweightedUnion) * -1);
                        cycleTracker[uParent] = vParent;
                    }
                }
            }

            return cycleFound;
        }

        private static int FindParent(int vertex, Dictionary<int, int> cycleTracker)
        {
            var vertexValue = cycleTracker[vertex];
            var _vertex = vertex;

            while (vertexValue > 0)
            {
                _vertex = vertexValue;
                vertexValue = cycleTracker[vertexValue];
            }

            return _vertex;
        }
    }


}
