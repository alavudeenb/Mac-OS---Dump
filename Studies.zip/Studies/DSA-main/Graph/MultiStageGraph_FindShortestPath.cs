

//var input = new List<KeyValuePair<int, List<(int neighbour, int weight)>>>();
//var firstVertex = new KeyValuePair<int, List<(int neighbour, int weight)>>(1, new List<(int neighbour, int weight)>() { (2, 9), (3, 7), (4, 3), (5, 2) });
//input.Add(firstVertex);

//var secondVertex = new KeyValuePair<int, List<(int neighbour, int weight)>>(2, new List<(int neighbour, int weight)>() { (6, 4), (7, 2), (8, 1) });
//input.Add(secondVertex);

//var thirdVertex = new KeyValuePair<int, List<(int neighbour, int weight)>>(3, new List<(int neighbour, int weight)>() { (6, 2), (7, 7) });
//input.Add(thirdVertex);

//var fourthVertex = new KeyValuePair<int, List<(int neighbour, int weight)>>(4, new List<(int neighbour, int weight)>() { (8, 11) });
//input.Add(fourthVertex);

//var fifthVertex = new KeyValuePair<int, List<(int neighbour, int weight)>>(5, new List<(int neighbour, int weight)>() { (7, 11), (8, 8) });
//input.Add(fifthVertex);

//var sixthVertex = new KeyValuePair<int, List<(int neighbour, int weight)>>(6, new List<(int neighbour, int weight)>() { (9, 6), (10, 5) });
//input.Add(sixthVertex);

//var seventhVertex = new KeyValuePair<int, List<(int neighbour, int weight)>>(7, new List<(int neighbour, int weight)>() { (9, 4), (10, 3) });
//input.Add(seventhVertex);

//var eighthVertex = new KeyValuePair<int, List<(int neighbour, int weight)>>(8, new List<(int neighbour, int weight)>() { (10, 5), (11, 6) });
//input.Add(eighthVertex);

//var ninethVertex = new KeyValuePair<int, List<(int neighbour, int weight)>>(9, new List<(int neighbour, int weight)>() { (12, 4) });
//input.Add(ninethVertex);

//var tenthVertex = new KeyValuePair<int, List<(int neighbour, int weight)>>(10, new List<(int neighbour, int weight)>() { (12, 2) });
//input.Add(tenthVertex);

//var eleventhVertex = new KeyValuePair<int, List<(int neighbour, int weight)>>(11, new List<(int neighbour, int weight)>() { (12, 5) });
//input.Add(eleventhVertex);

//var twelethVertex = new KeyValuePair<int, List<(int neighbour, int weight)>>(12, null);
//input.Add(twelethVertex);

//var output = MultiStageGraph_FindShortestPath.Get(input, 1, 12);
//for (int counter = 0; counter < output.Length; counter++)
//{
//    Console.Write($"{output[counter]} -> ");
//}


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GreedyProblems
{
    public static class MultiStageGraph_FindShortestPath
    {
        public static int[] Get(List<KeyValuePair<int, List<(int neighbour, int weight)>>> input, int startingVertex, int endingVertex)
        {
            Dictionary<int, int> costOfVertices = new Dictionary<int, int>();
            Dictionary<int, int> shortestDistanceVertices = new Dictionary<int, int>();
            var shortestPath = new List<int>();

            for (int counter = input.Count - 1; counter >= 0; counter--)
            {
                var vertex = input[counter];
                var vertexValue = vertex.Key;
                var edges = vertex.Value;
                if (edges == null || edges.Count == 0) // This will be true for the last vertex so that we can set cost of last vertices (to zero 0) and shortestDistanceVertext
                                                       // to itself
                {
                    costOfVertices.Add(vertexValue, 0);
                    shortestDistanceVertices.Add(vertexValue, vertexValue);
                }
                else
                {
                    int shortestDistanceVertex = 0;
                    var costOfVertex = FindMinimumCostAndShortestPathOfTheVertext(vertexValue, edges, costOfVertices, ref shortestDistanceVertex);
                    costOfVertices.Add(vertexValue, costOfVertex);
                    shortestDistanceVertices.Add(vertexValue, shortestDistanceVertex);
                }
            }

            shortestPath.Add(startingVertex);
            int currentVertex = startingVertex;

            while (currentVertex != endingVertex)
            {
                currentVertex = shortestDistanceVertices[currentVertex];
                shortestPath.Add(currentVertex);
            }

            return shortestPath.ToArray();
        }

        public static int FindMinimumCostAndShortestPathOfTheVertext(int vertex, List<(int neighbour, int weight)> edges, Dictionary<int, int> costOfVertices, ref int shortestDistanceVertex)
        {
            int minimumCost = Int32.MaxValue;
            shortestDistanceVertex = 0;

            foreach (var item in edges)
            {
                var nextStageVertexCost = costOfVertices[item.neighbour];
                var totalCost = item.weight + nextStageVertexCost;

                if (minimumCost > totalCost)
                {
                    minimumCost = totalCost;
                    shortestDistanceVertex = item.neighbour;
                }
            }

            return minimumCost;
        }
    }
}
