/*ContiguousSubarray
-------------------

Problem:
Find contiguous subarray from binary array with equal number of 0's and 1's

Solution:
Given Input: [ 0, 0, 0, 1, 0, 1, 1, 0, 0, 1, 0 ]

Output: 1, 0, 1, 1, 0, 0, 1, 0

The idea here is transform binary array's 0's into -1, now the array would be [ -1, -1, -1, 1, -1, 1, 1, -1, -1, 1, -1]. 
From now on the problem statement would be finding longest subarray whose sum is equal to sum of 1's and sum of 0's. 
In other words, find longest subarray whose sum is equal to 0 (zero).*/


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TwoPointers_Problems
{
    public static class MaximumContiguousSubarrayInBinaryArray
    {
        public static int Find(int[] input, ref int[] _subArray)
        {
            var output = new List<int[]>();
            var transformedInput = new int[input.Length];
            var maxLength = 0;
            var dictionaryOfPreviousFoundPrefixSums = new Dictionary<int, int>();
            dictionaryOfPreviousFoundPrefixSums.Add(0, -1);  // to handle subarrays starting at index 0

            for (int counter = 0; counter < input.Length; counter++)
            {
                transformedInput[counter] = input[counter] == 0 ? -1 : 1;
            }

            var prefixSumArray = new int[input.Length];
            prefixSumArray[0] = transformedInput[0];
            dictionaryOfPreviousFoundPrefixSums.Add(prefixSumArray[0], 0);
            var k = 0;

            for (int counter = 1; counter < input.Length; counter++)
            {
                prefixSumArray[counter] = prefixSumArray[counter - 1] + transformedInput[counter];

                if (dictionaryOfPreviousFoundPrefixSums.ContainsKey(prefixSumArray[counter]) == false) // we want to capture only the very first occurent to find max subarray
                {
                    dictionaryOfPreviousFoundPrefixSums.Add(prefixSumArray[counter], counter);
                }
            }

            for (int pCounter = 0; pCounter < prefixSumArray.Length; pCounter++)
            {
                var currentSum = prefixSumArray[pCounter];
                currentSum = currentSum - k;

                if (dictionaryOfPreviousFoundPrefixSums.ContainsKey(currentSum))
                {
                    var index = dictionaryOfPreviousFoundPrefixSums[currentSum];

                    if (maxLength < pCounter - index)
                    {
                        maxLength = Math.Max(maxLength, pCounter - index);

                        var tempOutput = new List<int>();
                        for (int subArrayCounter = index + 1; subArrayCounter <= pCounter; subArrayCounter++)
                        {
                            tempOutput.Add(input[subArrayCounter]);
                        }
                        output.Add(tempOutput.ToArray());
                    }
                }
            }

            foreach (var item in output)
            {
                if (item.Length == maxLength)
                    _subArray = item;

            }

            return maxLength;
        }

        //public static int Find(int[] input)
        //{
        //    //var result = new List<int>();

        //    var zeros = 0;
        //    var ones = 0;
        //    var maxSubarrayLength = 0;

        //    var seenDictionary = new Dictionary<int, int>();

        //    for (int counter = 0; counter < input.Length; counter++)
        //    {
        //        if (input[counter] == 0)
        //        {
        //            zeros = zeros + 1;
        //        }
        //        else
        //        {
        //            ones = ones + 1;
        //        }

        //        var current = ones - zeros;

        //        if (seenDictionary.ContainsKey(current) == false)
        //            seenDictionary.Add(current, counter);

        //        if (ones == zeros)
        //        {
        //            maxSubarrayLength = ones + zeros;
        //        }
        //        else
        //        {
        //            var previousOccurenceIndex = seenDictionary[current];
        //            var currentSubArrayLength = counter - previousOccurenceIndex;
        //            maxSubarrayLength = Math.Max(maxSubarrayLength, currentSubArrayLength);
        //        }
        //    }


        //    return maxSubarrayLength;
        //}
    }


    public static class Solution
    {
        public static int FindMaxLength(int[] nums)
        {
            int sum = 0, maxLen = 0;
            Dictionary<int, int> seen = new Dictionary<int, int> { { 0, -1 } };

            for (int i = 0; i < nums.Length; i++)
            {
                sum = sum + (nums[i] == 1 ? 1 : -1);

                if (seen.ContainsKey(sum))
                {
                    maxLen = Math.Max(maxLen, i - seen[sum]);
                }
                else
                {
                    seen[sum] = i;
                }
            }

            return maxLen;
        }
    }
}




/*var input = new[] { 0, 0, 0, 1, 0, 1, 1, 0, 0, 1, 0 }; //new[] { 1, 1, 1, 0, 0, 0, 1, 0 }; 
var subArray = new int[10];
var result = FindMaximumContiguousSubarrayInBinaryArray.Find(input, ref subArray);//Solution.FindMaxLength(input);
Console.WriteLine(result);

foreach (var item in subArray)
{
    Console.WriteLine(item);
}*/
