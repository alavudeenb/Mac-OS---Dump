/*SubarraysMatchingKvalue
------------------------
Problem: Find subarray mathing K value
Input: [ 1, 2, 3, -2, 4]
K: 5

Output: [2, 3] and [3, -2, 4]

Solution:
The idea is based on the prefix sum solution. So let's talk about prefix sum then we will come back to subarraysmathingkvalue problem.

Let's say we have an input array A = [3, 4, 2, 1, 6] and the ask is to find the sum of subarray from i to j where i = 1 , j=3.
The naive solution would be loop through input array A from i to j and add all the elements appearing. The challenge with this approach is for every requested i and j we need to loop through input array A and add them all.

The better solution woule be let's create a prefix sum array from input array A. How to create prefix sum array, let's discuss
A = [ 1, 2, 3, -2, 4]
P=[] //Prefix sum array
P[0] = A[0]
P[1] = A[1] + P[0]
P[2] = A[2] + P[1]
.
.
.
P[n] = A[n]+p[n-1]

Now if we want to find sum (let's say k) of subarray from i to j then K = P[j] - p[i-1] how ?

A = [ 1, 2, 3, -2, 4]
P = [1, 3, 6, 4, 8]

i=1
j=3
K = P[j] - P[i-1]
K = P[3] - P[0]
K = -2 - 2
K = -4

Now we know how the prefix sum array is working. we have not for looped from i to j instead we simply took jth index value from Prefix sum array and i-1th index value from Prefix sum array. let's get back to our original problem. The problem is

Problem: Find subarray mathing K value
Input: [ 1, 2, 3, -2, 4]
K: 5

As we know the formula to find K from prefix sum array
K = P[j] - P[i-1];
5 = P[j] - P[i-1];
Now we need to find i and j index value by having K value from prefix sum array. if P[j] - P[i-1] is substracted value is matching with K then that is the subarray which has sum of value as same as K. what does it mean ? 

K = P[j] - P[i-1]
P[i-1] = P[j] - K

if we keep track of P[i-1] value and ith index in key-value pair (Dictionary) then when we substract P[j] with k the result may or may not present in the key-value pair (Dictionary). if the result present then the result along with the index should considered. The index added with +1 is the starting position of the sub array and the current jth index is the ending position of the subarray.

NOTE: since we are considering i-1 we should store 0th item and it's index (0) in the key-value pair(Dictionary), before executing the algorithm.

*/

using System;
using System.Collections.Generic;
using System.Diagnostics.Metrics;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace TwoPointers_Problems
{
    public static class SubarraysMatchingKvalue
    {
        public static List<int[]> GetArrays(int[] input, int k)
        {
            var output = new List<int[]>();
            var prefixsumArray = new int[input.Length];
            var dictionaryOfPreviousFoundPrefixSums = new Dictionary<int, int>();
            dictionaryOfPreviousFoundPrefixSums.Add(0, -1); // to handle subarrays starting at index 0

            prefixsumArray[0] = input[0];
            dictionaryOfPreviousFoundPrefixSums.Add(prefixsumArray[0], 0);
            for (int counter = 1; counter < input.Length; counter++)
            {
                prefixsumArray[counter] = input[counter] + prefixsumArray[counter - 1];

                dictionaryOfPreviousFoundPrefixSums.Add(prefixsumArray[counter], counter);
            }

            for (int pcounter = 0; pcounter < prefixsumArray.Length; pcounter++)
            {
                var currentSum = prefixsumArray[pcounter];
                var currentSum_k = currentSum - k;

                if (dictionaryOfPreviousFoundPrefixSums.ContainsKey(currentSum_k))
                {
                    var index = dictionaryOfPreviousFoundPrefixSums[currentSum_k];

                    var tempOutput = new List<int>();
                    for (int subArrayCounter = index + 1; subArrayCounter <= pcounter; subArrayCounter++)
                    {
                        tempOutput.Add(input[subArrayCounter]);
                    }
                    output.Add(tempOutput.ToArray());
                }
            }

            return output;
        }
    }

    public class SubArrays
    {
        public SubArrays(int _currentIndex)
        {
            this.Index = _currentIndex;
        }
        public int Index { get; private set; }

        public List<int[]> Arrays = new List<int[]>();
    }
}



//var input = new[] { 1, 2, 3, -2, 4 };
//var k = 5;
//var result = SubarraysMatchingKvalue.GetArrays(input, k);
//Console.WriteLine($"Number of subarries matching K: {result.Count}");
//foreach (var item in result)
//{
//    foreach (var eachElements in item)
//    {
//        Console.Write(eachElements);
//    }
//    Console.WriteLine();
//}
