﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Recursion
{
    internal class SubsetSum1 // O(2^n)
    {
        public List<int> output = new List<int>();
        public int[] Find(int[] input)
        {
            FindRecursively(input, 0, 0);
            var result = output.ToArray(); // Time Complexity is 2^n.
                                           // The reason is, for n elements, getting all combination would take 2^n time complexity.
                                           // Sorting 2^n elements would take 2^n log 2^n
            Array.Sort(result); // Including soring, Time complexity is O(2^n log 2^n)

            return result;
        }

        private void FindRecursively(int[] input, int index, int sum)
        {
            if (index == input.Length)
            {
                output.Add(sum);
                return;
            }

            sum = sum + input[index];
            FindRecursively(input, index + 1, sum);

            sum = sum - input[index];
            FindRecursively(input, index + 1, sum);
        }
    }
}
