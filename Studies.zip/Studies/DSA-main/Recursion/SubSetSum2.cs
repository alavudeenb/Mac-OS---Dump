﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Recursion
{
    internal class SubSetSum2 // O(n*2^n)
    {
        List<int> output = new List<int>();
        int i = 0;
        public void PrintAll(int[] input)
        {
            Array.Sort(input);
            PrintRecursively(input, 0, output);
        }

        void PrintRecursively(int[] input, int index, List<int> output)
        {
            for (int init = 0; init < output.Count; init++)
            {
                if (init == 0) Console.WriteLine($"count: {++i}");
                Console.Write($"{output[init]} ");
            }
            Console.WriteLine();

            if (index >= input.Length)
                return;

            int lastValue = 0;

            for (int init = index; init < input.Length; init++)
            {
                if (lastValue != input[init])
                {
                    lastValue = input[init];
                    output.Add(input[init]);
                    PrintRecursively(input, init + 1, output);
                    output.Remove(input[init]);
                }
            }
        }
    }
}
