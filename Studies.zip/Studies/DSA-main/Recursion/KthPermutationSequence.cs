﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Recursion
{
    internal class KthPermutationSequence
    {
        int count = 0;

        public string Find(int n, int k)
        {
            StringBuilder input = new StringBuilder();

            for (int init = 1; init <= n; init++)
            {
                input.Append(init);
            }

            k = k - 1; //Since 0 (zero) based index is used for stroing all permutations and accessing input
            var result = FindWithoutFullRecursionAndBacktracking(input, n, k, new StringBuilder());
            return result.ToString();

            //return FindRecursively(input, 0, k);
        }

        private StringBuilder FindWithoutFullRecursionAndBacktracking(StringBuilder input, int n, int k, StringBuilder output) // O(n2)
        {
            if (n == 0)
                return output;

            var numberOfPermutationsStartingWithEachFirstElementFromN = (n - 1)!;
            var FindKthElementsElement = numberOfPermutationsStartingWithEachFirstElementFromN == 0 ? 0 : k / numberOfPermutationsStartingWithEachFirstElementFromN;
            var kthElementPositionPresentWithInParticularFirstElementGroup = numberOfPermutationsStartingWithEachFirstElementFromN == 0 ? 0 : k % numberOfPermutationsStartingWithEachFirstElementFromN;

            output.Append(input[FindKthElementsElement]);

            input = input.Remove(FindKthElementsElement, 1); // O(n)

            return FindWithoutFullRecursionAndBacktracking(input, 
                                                           input.Length, 
                                                           kthElementPositionPresentWithInParticularFirstElementGroup, 
                                                           output); // O(n)
        }


        private string FindRecursively(StringBuilder input, int index, int k) // O(2^n)
        {
            if (index >= input.Length)
            {
                count++;
                if (count == k)
                    return input.ToString();
                else
                    return string.Empty;
            }

            for (int init = index; init < input.Length; init++)
            {
                var tempValue = input[index];
                input[index] = input[init];
                input[init] = tempValue;

                var result = FindRecursively(input, index + 1, k);

                if (result != string.Empty)
                    return result;

                tempValue = input[index];
                input[index] = input[init];
                input[init] = tempValue;
            }

            return string.Empty;
        }
    }
}
