﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Recursion
{
    internal class Subsequence // O(n*2^n)
    {
        public void PrintAll(int[] input)
        {
            PrintByRecursion(0, new List<int>(), input);
        }

        private void PrintByRecursion(int index, List<int> output, int[] input)
        {
            if (index == input.Length)
            {
                for (int init = 0; init < output.Count; init++)
                {
                    Console.Write(output[init]);
                }
                Console.WriteLine();
                return;
            }

            output.Add(input[index]);
            PrintByRecursion(index + 1, output, input);

            output.Remove(input[index]);
            PrintByRecursion(index + 1, output, input);
        }
    }
}
