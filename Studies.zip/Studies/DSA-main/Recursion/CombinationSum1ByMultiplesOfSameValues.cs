﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Recursion
{
    internal class CombinationSum1ByMultiplesOfSameValues // Worst case = O(2^T/minvalue) or O(2^T) 
    {                                                     // T is the target and minvalue is the minimum value in the input
        public void Print(int[] input, int target)
        {
            PrintRecursive(input, 0, target, new List<int>());
        }

        private void PrintRecursive(int[] input, int index, int target, List<int> output)
        {
            if (index == input.Length)
            {
                if (target == 0)
                {
                    for (int init = 0; init < output.Count; init++)
                    {
                        Console.Write(output[init]);
                    }
                    Console.WriteLine();
                }
                return;
            }

            if (input[index] <= target)
            {
                output.Add(input[index]);
                var remainingTarget = target - input[index];
                PrintRecursive(input, index, remainingTarget, output);
                output.Remove(input[index]);
            }

            PrintRecursive(input, index + 1, target, output);
        }

    }
}
