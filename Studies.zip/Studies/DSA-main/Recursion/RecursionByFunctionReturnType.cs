﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Recursion
{
    internal class RecursionByFunctionReturnType // O(n)
    {
        public bool IsPalindrome(string input)
        {
            return PalindromeByFunctionalCall(0, input.Length, input);
        }

        bool PalindromeByFunctionalCall(int index, int n, string input)
        {
            if (index >= n / 2) return true;

            if (input[index] != input[n - 1 - index]) return false;

            return PalindromeByFunctionalCall(index + 1, n, input);
        }
    }
}
