﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Recursion
{
    internal class FibonacciByFunctionRecursion
    {
        public int Get(int n)
        {
            //return FindFibonacciByParameter(0, 1, n);
            return FindFibonacciByFunctionRecursion(n);
        }

        private int FindFibonacciByParameter(int firstValue, int secondValue, int n) // O(n)
        {
            if (n == 1) return secondValue;

            return FindFibonacciByParameter(secondValue, firstValue + secondValue, n - 1);
        }

        private int FindFibonacciByFunctionRecursion(int n) // O(2^n)
        {
            /* if (n <= 0) return 0;
             if (n == 1) return 1; */

            if (n <= 1) return n; // Which mean anything above (greater than) 1 will reach below line

            return FindFibonacciByFunctionRecursion(n - 1) + FindFibonacciByFunctionRecursion(n - 2);
        }
    }
}
