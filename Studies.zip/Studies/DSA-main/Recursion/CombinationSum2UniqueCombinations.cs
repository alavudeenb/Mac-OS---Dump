﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Recursion
{
    internal class CombinationSum2UniqueCombinations 
    {
        List<List<int>> answer = new List<List<int>>();

        HashSet<string> duplicateEntryCheckerForTraditionalMethod = new HashSet<string>();
        public List<List<int>> Find(int[] input, int target)
        {
            Array.Sort(input);
            //FindRecursively(input, 0, target, new List<int>());
            FindRecursivelyUsingTraditionalMethod(input, 0, target, new List<int>());
            return answer;
        }

        private void FindRecursively(int[] input, int index, int target, List<int> ds) // Worst case = O(2^n) => with copying O(2^n * k) where K is the average subset length
        {
            if (target == 0)
            {
                var tempList = new List<int>();
                for (int init = 0; init < ds.Count; init++)
                {
                    tempList.Add(ds[init]);
                }
                answer.Add(tempList);
            }
            if (index >= input.Length)
            {
                return;
            }

            int lastValue = 0;

            for (int init = index; init < input.Length; init++) // Take or Don't Take
            {
                if (lastValue != input[init] && input[init] <= target)
                {
                    lastValue = input[init];
                    ds.Add(input[init]);
                    FindRecursively(input, init + 1, target - input[init], ds);
                    ds.Remove(input[init]);
                }
            }
        }

        private void FindRecursivelyUsingTraditionalMethod(int[] input, int index, int target, List<int> ds) // Worst case = O(2^n) => with copying O(2^n * k) where K is the average subset length
        {
            if (index == input.Length)
            {
                if (target == 0)
                {
                    StringBuilder key = new StringBuilder();
                    var tempList = new List<int>();
                    for (int init = 0; init < ds.Count; init++)
                    {
                        tempList.Add(ds[init]);
                        key.Append(ds[init]);
                    }
                    if (duplicateEntryCheckerForTraditionalMethod.Contains(key.ToString()) == false) // If this condition doesn't exist then multiple combination having same value would repeat because we are doing take/don't take
                    {
                        answer.Add(tempList);
                        duplicateEntryCheckerForTraditionalMethod.Add(key.ToString());
                    }
                }
                return;
            }

            if (input[index] <= target)
            {
                ds.Add(input[index]);
                FindRecursivelyUsingTraditionalMethod(input, index + 1, target - input[index], ds);
                ds.Remove(input[index]);
            }

            FindRecursivelyUsingTraditionalMethod(input, index + 1, target, ds);

        }

    }
}
