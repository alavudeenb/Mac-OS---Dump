﻿using Recursion;

// See https://aka.ms/new-console-template for more information
Console.WriteLine("Hello, World!");


//var input = new[] { 3, 1, 2 }; // output 312 3 31 32 1 12 2
//new Subsequence().PrintAll(input);


//var input = new[] { 3, 1, 2, 4, 1 }; // output 11 2
//var targetSum = 2;
//new SubsequenceWithSum().PrintAll(input, targetSum);


//var input = new[] { 1, 2, 4, 5, 3 }; // output 3 5 4 2 1
//new RecursionByParameter().Reverse(input);
//Console.WriteLine("After Swap");
//for (int init = 0; init < input.Length; init++)
//{
//    Console.WriteLine(input[init]);
//}


//var input = "madras";// "madam"; // output false 
//var result = new RecursionByFunctionReturnType().IsPalindrome(input);
//Console.WriteLine($"Is Palindrome {result}");


//var input = 4; // output 3 
//var result = new FibonacciByFunctionRecursion().Get(input);
//Console.WriteLine(result);


//var input = new[] { 2, 3, 6, 7 }; // output 223 7
//new CombinationSum1ByMultiplesOfSameValues().Print(input, target: 7);



//var input = new[] { 1, 1, 1, 2, 2 };
//var target = 4;
//var result = new CombinationSum2UniqueCombinations().Find(input, target);
//for (int init = 0; init < result.Count; init++)
//{
//    for (int innerInit = 0; innerInit < result[init].Count; innerInit++)
//    {
//        Console.Write(result[init][innerInit]);
//    }
//    Console.WriteLine();
//}


//var input = new[] { 3, 1, 2 };
//var result = new SubsetSum1().Find(input);

//for (int init = 0; init < result.Length; init++)
//{
//    Console.Write($"{result[init]} ");
//}


//var input = new[] { 1, 2, 3 };// new[] { 1, 2, 2, 2, 3, 3 };
//new SubSetSum2().PrintAll(input);


//var input = new[] { 1, 2, 3 };
//new PrintAllPermutationsOfStringOrArray_Recursion1().PrintAll(input);


var input = new[] { 1, 2, 3 };
new PrintAllPermutationsOfStringOrArray_Recursion2().PrintAll(input);


//new NQueen().Find(4);


//var input = new[,] { { 5, 3, 0, 6, 7, 8, 9, 0, 2 },
//                     { 6, 7, 2, 1, 9, 5, 3, 4, 8 },
//                     { 0, 9, 8, 3, 4, 2, 5, 6, 7 },
//                     { 8, 5, 9, 7, 6, 1, 4, 2, 3 },
//                     { 4, 2, 6, 8, 5, 3, 7, 9, 1 },
//                     { 7, 1, 3, 9, 0, 4, 8, 5, 6 },
//                     { 9, 6, 0, 5, 3, 7, 2, 8, 4 },
//                     { 2, 8, 7, 4, 1, 9, 6, 3, 5 },
//                     { 3, 4, 5, 2, 8, 6, 1, 7, 9 } };
//new SudoKo().Fill(input);


/*var input = new List<(int node, List<int>)>();
input.Add((1, new List<int>() { 2, 3, 4 }));
input.Add((2, new List<int>() { 1, 3, 5 }));
input.Add((3, new List<int>() { 1, 2, 4 }));
input.Add((4, new List<int>() { 1, 3 }));
input.Add((5, new List<int>() { }));

//new MColoringProblem().Find(input, mColors: 3); // output yes (1) 1 -> 1, 2 -> 2, 3 -> 3, 4 -> 2, 5 -> 1

new MColoringProblem().Find(input, mColors: 2); // output no (0) */


//var input = "aabb";
//var result = new PalindromePartitioning().Get(input);
//foreach (var item in result)
//{
//    Console.WriteLine(item);
//}



//var input = new[,] { { 1, 0, 0, 0 },
//                     { 1, 1, 0, 0 },
//                     { 1, 1, 0, 0 },
//                     { 0, 1, 1, 1 } };
//var result = new RatNMaze().FindPath(input); // output DDRDRR DRDDRR
//Array.Sort(result);
//for (int init = 0; init < result.Length; init++)
//{
//    Console.WriteLine(result[init]);
//}



//var result = new KthPermutationSequence().Find(4, 9);
//Console.WriteLine(result); // 2341



/*var input = "babgbag";
new PrintAllSubsequences().Do(input);*/