﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Recursion
{
    internal class PrintAllPermutationsOfStringOrArray_Recursion1 // O(n* n!)
    {
        public void PrintAll(int[] input)
        {
            PrintRecursively(input, new List<int>(), new HashSet<int>());
        }

        private void PrintRecursively(int[] input, List<int> output, HashSet<int> map)
        {
            if (output.Count == input.Length)
            {
                for (int init = 0; init < output.Count; init++)
                {
                    Console.Write($"{output[init]} ");
                }
                Console.WriteLine();
                return;
            }

            for (int init = 0; init < input.Length; init++)
            {
                if (map.Contains(init) == false)
                {
                    map.Add(init);
                    output.Add(input[init]);
                    PrintRecursively(input, output, map);
                    map.Remove(init);
                    output.Remove(input[init]);
                }
            }
        }
    }
}
