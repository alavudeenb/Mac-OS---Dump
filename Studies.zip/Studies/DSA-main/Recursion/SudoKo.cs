﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Recursion
{
    internal class SudoKo // O(9^k) where k = number of empty cells.
    {
        public void Fill(int[,] input)
        {
            FillRecursivelyWithSingleLoopForCanIFillWithInitValue(input);

            //FillRecursively(input);

            for (int row = 0; row < input.GetLength(0); row++)
            {
                for (int column = 0; column < input.GetLength(1); column++)
                {
                    Console.Write($"({row},{column}){input[row, column]} ");
                }
                Console.WriteLine();
            }
        }

        private bool FillRecursivelyWithSingleLoopForCanIFillWithInitValue(int[,] input)
        {
            var rowLength = input.GetLength(0);
            var columnLength = input.GetLength(1);

            for (int row = 0; row < rowLength; row++)
            {
                for (int column = 0; column < columnLength; column++)
                {
                    if (input[row, column] == 0)
                    {
                        for (int init = 1; init <= 9; init++)
                        {
                            if (CanIFillWithInitValueSingleForLoop(init, row, column, input))
                            {
                                input[row, column] = init;
                                var result = FillRecursivelyWithSingleLoopForCanIFillWithInitValue(input);

                                if (result == true)
                                    return true;

                                input[row, column] = 0;
                            }
                        }
                        return false;
                    }
                }
            }


            return true;
        }

        private bool CanIFillWithInitValueSingleForLoop(int value, int row, int column, int[,] input)
        {
            for (int init = 0; init < 9; init++)
            {
                if (input[init, column] == value)
                    return false;

                if (input[row, init] == value)
                    return false;

                int rowIndex = (row / 3) * 3 + init / 3;
                int columnIndex = (column / 3) * 3 + init % 3;

                if (input[rowIndex, columnIndex] == value)
                    return false;
            }

            return true;
        }

        private bool FillRecursively(int[,] input)
        {
            int rowLength = input.GetLength(0);
            int columnLength = input.GetLength(1);


            for (int row = 0; row < rowLength; row++)
            {
                for (int column = 0; column < columnLength; column++)
                {
                    if (input[row, column] == 0)
                    {
                        for (int init = 1; init <= 9; init++)
                        {
                            if (CanIFillWithInitValue(init, row, column, input))
                            {
                                input[row, column] = init;
                                var result = FillRecursively(input);

                                if (result)
                                    return true;

                                input[row, column] = 0;
                            }
                        }

                        return false; // if unable to fill 1 to 9 in the given cell then return false so that .
                    }
                }
            }
            return true;
        }

        private bool CanIFillWithInitValue(int value, int row, int column, int[,] input)
        {
            int columnIndex = 0;
            int rowIndex = row;
            while (columnIndex < input.GetLength(1)) // Horizontal row
            {

                if (input[rowIndex, columnIndex] == value)
                    return false;
                columnIndex++;
            }


            columnIndex = column;
            rowIndex = 0;
            while (rowIndex < input.GetLength(0)) // Vertical column
            {
                if (input[rowIndex, columnIndex] == value)
                    return false;
                rowIndex++;
            }

            rowIndex = (row / 3) * 3; // If you think every mini matrix as row, column then Finding starting row will be,
                                      // row divide by 3 will give the mini matrix row index, then multiply it with 3 will give starting row index
            columnIndex = (column / 3) * 3; // if you think every mini matrix as row, column then finding starting column will be,
                                            // column divide by 3 will give the mini matrix column index, then multiply it with 3 will give starting column index

            for (int _row = rowIndex; _row < rowIndex + 3; _row++) // Mini matrix starting row till next 3 rows
            {
                for (int _column = columnIndex; _column < columnIndex + 3; _column++) // mini matrix starting column till next 3 columns
                {
                    if (input[_row, _column] == value)
                        return false;
                }
            }

            return true;
        }
    }
}
