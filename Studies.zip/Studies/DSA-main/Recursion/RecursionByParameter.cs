﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Recursion
{
    internal class RecursionByParameter // O(n)
    {
        public int[] Reverse(int[] input)
        {
            ReverseRecursively(0, input.Length, input);
            return input;
        }

        void ReverseRecursively(int index, int n, int[] input)
        {
            if (index >= n / 2) return;

            Swap(index, n - 1 - index, input);

            ReverseRecursively(index + 1, n, input);
        }

        void Swap(int leftIndex, int rightIndex, int[] input)
        {
            int tempValue = input[leftIndex];
            input[leftIndex] = input[rightIndex];
            input[rightIndex] = tempValue;
        }
    }
}
