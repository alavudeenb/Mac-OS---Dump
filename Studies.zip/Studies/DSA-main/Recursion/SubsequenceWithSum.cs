﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Recursion
{
    internal class SubsequenceWithSum // O(n*2^n)
    {
        public void PrintAll(int[] input, int targetSum)
        {
            PrintAllWithSum(0, 0, targetSum, new List<int>(), input);
        }

        private void PrintAllWithSum(int index, int sum, int targetSum, List<int> output, int[] input)
        {
            if (index == input.Length)
            {
                if (sum == targetSum)
                {
                    for (int init = 0; init < output.Count; init++)
                    {
                        Console.Write(output[init]);
                    }
                    Console.WriteLine();
                }
                return;
            }

            sum = sum + input[index];
            output.Add(input[index]);
            PrintAllWithSum(index + 1, sum, targetSum, output, input);
            sum = sum - input[index];
            output.Remove(input[index]);


            PrintAllWithSum(index + 1, sum, targetSum, output, input);
        }
    }
}
