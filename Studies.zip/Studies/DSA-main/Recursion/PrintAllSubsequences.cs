﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Recursion
{
    internal class PrintAllSubsequences
    {
        public void Do(string str)
        {
            this.DoRecursively(str.Length - 1, str, new List<char>());
        }

        private void DoRecursively(int index, string str, List<char> output)
        {
            if (index == 0)
            {
                foreach (var item in output)
                    Console.Write(item);

                Console.WriteLine();
                return;
            }

            output.Add(str[index]);
            DoRecursively(index + 1, str, output);
            output.RemoveAt(output.Count - 1);

            DoRecursively(index + 1, str, output);

        }
    }
}
