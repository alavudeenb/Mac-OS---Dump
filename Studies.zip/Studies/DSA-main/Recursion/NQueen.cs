﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Recursion
{
    internal class NQueen // O(m*n^m)                        O(n!) -- Globally only one queen can be placed in a row. like n*(n-1)*(n-2)*.....1
    {
        List<int[,]> output = new List<int[,]>();

        int[] leftRow;
        int[] leftUpperDiagnoal;
        int[] leftLowerDiagnoal;
        public void Find(int n) 
        {
            int[,] input = new int[n, n];

            leftRow = new int[n];
            leftUpperDiagnoal = new int[2 * n - 1];
            leftLowerDiagnoal = new int[2 * n - 1];
            FindRecursivelyWithoutRecrusvieFillMethodCall(0, input, n); //This method stores left upper diagnoal, left row, left lower diagnoal data without looking recurivesly using Fill method
            

            //FindRecursively(0, input);

            for (int init = 0; init < output.Count; init++)
            {
                for (int row = 0; row < output[init].GetLength(0); row++)
                {
                    for (int column = 0; column < output[init].GetLength(1); column++)
                    {
                        Console.WriteLine($"Row: {row} Column: {column} Value: {output[init][row, column]}");
                    }
                }
            }
        }

        private void FindRecursivelyWithoutRecrusvieFillMethodCall(int columnIndex, int[,] input, int n) // O(n!)
        {
            var rowLength = input.GetLength(0);
            var columnLength = input.GetLength(1);
            if (columnIndex >= input.GetLength(1))
            {
                var tempOutput = new int[rowLength, columnLength];

                for (int row = 0; row < rowLength; row++)
                {
                    for (int column = 0; column < columnLength; column++)
                    {
                        tempOutput[row, column] = input[row, column];
                    }
                }
                output.Add(tempOutput);
            }

            for (int row = 0; row < rowLength; row++)
            {
                if (leftRow[row] == 0 &&
                   leftUpperDiagnoal[row + columnIndex] == 0 &&
                   leftLowerDiagnoal[n - 1 + columnIndex - row] == 0)
                {
                    input[row, columnIndex] = 1;
                    leftRow[row] = 1;
                    leftUpperDiagnoal[row + columnIndex] = 1;
                    leftLowerDiagnoal[n - 1 + columnIndex - row] = 1;

                    FindRecursivelyWithoutRecrusvieFillMethodCall(columnIndex + 1, input, n);

                    input[row, columnIndex] = 0;
                    leftRow[row] = 0;
                    leftUpperDiagnoal[row + columnIndex] = 0;
                    leftLowerDiagnoal[n - 1 + columnIndex - row] = 0;
                }
            }
        }

        private void FindRecursively(int columnIndex, int[,] input) // O(n!)
        {
            int rowLength = input.GetLength(0);
            int columnLength = input.GetLength(1);

            if (columnIndex >= columnLength)
            {
                int[,] temp = new int[rowLength, columnLength];

                for (int row = 0; row < rowLength; row++)
                {
                    for (int column = 0; column < columnLength; column++)
                    {
                        temp[row, column] = input[row, column];
                    }
                }
                output.Add(temp);
            }

            for (int row = 0; row < rowLength; row++)
            {
                if (Fill(row, columnIndex, input) == true)
                {
                    input[row, columnIndex] = 1;
                    FindRecursively(columnIndex + 1, input);
                    input[row, columnIndex] = 0;
                }
            }
        }

        private bool Fill(int row, int column, int[,] input)
        {
            var tempRow = row;
            var tempColumn = column;
            while (tempRow - 1 >= 0 && tempColumn - 1 >= 0) // This loop is for upper diagnoal
            {
                tempRow--;
                tempColumn--;
                if (input[tempRow, tempColumn] == 1)
                    return false;
            }

            tempRow = row;
            tempColumn = column;
            while (tempColumn - 1 >= 0) // This loop is for horizontal left row
            {
                tempColumn--;
                if (input[tempRow, tempColumn] == 1)
                    return false;
            }

            tempRow = row;
            tempColumn = column;
            while (tempRow + 1 < input.GetLength(0) && tempColumn - 1 >= 0) // This loop is for lower diagnoal
            {
                tempRow++;
                tempColumn--;
                if (input[tempRow, tempColumn] == 1)
                    return false;
            }

            //We don't need to check all eight directions because we are iterating column by column
            //hence there is no need to check right upper diagnoal, right horizontal row, right lower diagnoal

            return true;
        }
    }
}
