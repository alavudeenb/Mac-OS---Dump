﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Recursion
{
    internal class MColoringProblem // worst case = m*m*m*......n terms => m^n
    {
        Dictionary<int, int> adjacentNodeColorTracker = new Dictionary<int, int>();

        Dictionary<int, List<int>> adjacentNodes = new Dictionary<int, List<int>>();

        public int Find(List<(int node, List<int> adjacents)> input, int mColors)
        {
            foreach (var item in input)
            {
                adjacentNodes.Add(item.node, item.adjacents);
            }

            var result = FindRecursively(input, 0, mColors);

            foreach (var item in adjacentNodeColorTracker)
            {
                Console.WriteLine($"key: {item.Key} value: {item.Value}");
            }

            Console.WriteLine(result);

            return result;
        }

        private int FindRecursively(List<(int node, List<int> adjacents)> input, int inputIndex, int mColors)
        {
            if (inputIndex >= input.Count)
            {
                return 1;
            }

            for (int mInit = 1; mInit <= mColors; mInit++) // O(m) -- All nodes can have mostly any colors. Local (adjacent) nodes can't have but gloablly all nodes can have any colors from mColors
            {
                var currentNode = input[inputIndex].node;
                if (CanIFill(currentNode, mInit) == true)
                {
                    adjacentNodeColorTracker.Add(currentNode, mInit);

                    var result = FindRecursively(input, inputIndex + 1, mColors); // O(n)

                    if (result == 1)
                        return 1;

                    adjacentNodeColorTracker.Remove(currentNode);
                }
            }

            return 0;


            //if (adjacentNodeColorTracker.ContainsKey(currentNode) == false)
            //{
            //    for (int mInit = 1; mInit <= m; mInit++)
            //    {
            //        if (CanIFill(currentNode, mInit, input))
            //        {
            //            adjacentNodeColorTracker.Add(currentNode, mInit);

            //            for (int init = 0; init < input[currentNode].Count; init++)
            //            {
            //                return FindRecursively(input[currentNode][init], m, input);
            //            }
            //        }
            //        else
            //        {
            //            if (mInit == m)
            //                return 0;
            //        }
            //    }
            //}
            //return 1;


            //if (adjacentNodeColorTracker.ContainsKey(currentNode) == false)
            //{
            //    for (int mInit = 1; mInit <= m; mInit++)
            //    {
            //        if (CanIFill(currentNode, mInit, input))
            //        {
            //            adjacentNodeColorTracker.Add(currentNode, mInit);
            //            for (int init = 0; init < input[currentNode].Count; init++)
            //            {
            //                if (adjacentNodeColorTracker.ContainsKey(currentNode) == false)
            //                {
            //                    var result = FindRecursively(input[currentNode][init], m, input);

            //                    if (result == 1)
            //                        return 1;
            //                }
            //            }
            //        }
            //    }
            //    return 0;
            //}
            //return 1;
        }

        private bool CanIFill(int currentNode, int mInit)
        {
            var _adjacentNodesList = adjacentNodes[currentNode];

            for (int init = 0; init < _adjacentNodesList.Count; init++)
            {
                var _adjacentNodeAtInit = _adjacentNodesList[init];

                int color;
                if (adjacentNodeColorTracker.TryGetValue(_adjacentNodeAtInit, out color) && color == mInit)
                    return false;
            }
            return true;
        }
    }
}
