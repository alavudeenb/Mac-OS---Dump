﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Recursion
{
    internal class PalindromePartitioning
    {
        List<string> output = new List<string>();

        public List<string> Get(string input)
        {
            FindRecursively(0, input, new StringBuilder());
            return output;
        }

        private void FindRecursively(int index, string input, StringBuilder partitionedOutput)
        {
            if (index >= input.Length)
            {
                output.Add(partitionedOutput.ToString());
                return;
            }

            for (int init = index; init < input.Length; init++)
            {
                if (CanIPartition(index, init, input))
                {
                    var lastIndex = partitionedOutput.ToString().LastIndexOf('|');
                    partitionedOutput.Append(input.Substring(index, (init - index) + 1)).Append("|");

                    FindRecursively(init + 1, input, partitionedOutput);

                    if (lastIndex == -1)
                    {
                        partitionedOutput.Clear();
                    }
                    else
                    {
                        partitionedOutput.Remove(lastIndex, partitionedOutput.ToString().LastIndexOf('|') - lastIndex);
                    }
                }
            }
        }

        private bool CanIPartition(int startingIndex, int currentIndex, string input)
        {
            var tempCurrentIndex = currentIndex;
            for (int init = startingIndex; init <= tempCurrentIndex; init++)
            {
                if (input[init] != input[tempCurrentIndex])
                    return false;

                tempCurrentIndex--;
            }
            return true;
        }
    }
}
