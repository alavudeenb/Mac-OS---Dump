﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Recursion
{
    internal class RatNMaze // O(4^(n*m)) => 4*4*4*........n*m times
    {
        List<string> output = new List<string>();
        int[,] visited;
        public string[] FindPath(int[,] input)
        {
            this.visited = new int[input.GetLength(0), input.GetLength(1)];
            this.visited[0, 0] = 1;

            FindRecursively(0, 0, input, new StringBuilder(), this.visited);

            return this.output.ToArray();
        }

        private void FindRecursively(int row, int column, int[,] input, StringBuilder output, int[,] visited)
        {
            if (row == input.GetLength(0) - 1 && column == input.GetLength(1) - 1)
            {
                this.output.Add(output.ToString());
                return;
            }

            List<(string direction, (int row, int column))> arrayDirection = new List<(string direction, (int row, int column))>(){
                                                                             ("L", ( 0, -1 )),
                                                                             ("R", ( 0, 1 )),
                                                                             ("U", ( -1, 0 )),
                                                                             ("D", ( 1, 0 ))};

            foreach (var item in arrayDirection)
            {
                var currentRow = item.Item2.row + row;
                var currentColumn = item.Item2.column + column;
                var currentDirection = item.direction;

                if (CanRatMove(currentRow, currentColumn, input, visited))
                {
                    visited[currentRow, currentColumn] = 1;
                    int LastIndex = output.Length;
                    output.Append(currentDirection);

                    FindRecursively(currentRow, currentColumn, input, output, visited);

                    visited[currentRow, currentColumn] = 0;
                    output.Remove(LastIndex, 1);
                }

            }

        }

        private bool CanRatMove(int row, int column, int[,] input, int[,] visited)
        {
            if (row < input.GetLength(0) && column < input.GetLength(1) && row >= 0 && column >= 0 && input[row, column] == 1 && visited[row, column] == 0)
                return true;

            return false;
        }
    }
}
