

//var input = new[] { 1, -3, 4, -1, 2, 1, -5, 4 };
//var result = MaximumSumOfSubarray.Find(input);
//int sum = 0;
//foreach (var item in result)
//{
//    sum = sum + item;
//    Console.Write(item);
//}
//Console.WriteLine();
//Console.WriteLine($"Sum of largerst sub array is: {sum}");


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TwoPointers_Problems
{
    public static class MaximumSumOfSubarray
    {
        public static int[] Find(int[] input)
        {
            var result = new List<int>();
            int maxSum = 0;
            int currentSum = input[0];

            int startIndex = 0;
            int endIndex = 0;
            int tempStartIndex = 0;
            int tempEndIndex = 0;

            for (int counter = 1; counter < input.Length; counter++)
            {
                if ((currentSum + input[counter]) > input[counter])
                {
                    currentSum = currentSum + input[counter];
                    tempEndIndex = counter;
                }
                else
                {
                    currentSum = input[counter];
                    tempStartIndex = counter;
                    tempEndIndex = counter;
                }

                if (maxSum < currentSum)
                {
                    maxSum = currentSum;
                    startIndex = tempStartIndex;
                    endIndex = tempEndIndex;
                }
            }

            for (int counter = startIndex; counter <= endIndex; counter++)
            {
                result.Add(input[counter]);
            }

            return result.ToArray();
        }
    }
}
