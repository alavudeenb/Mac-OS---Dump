
//int[] input = new[] { 1, 8, 6, 2, 5, 4, 8, 3, 7 };
//var result = MaxWaterTrap.GetMaxArea(input);
//Console.WriteLine($"Max water that can be stored is:{result}");

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TwoPointers_Problems
{
    public static class MaxWaterTrap
    {
        public static int GetMaxArea(int[] input)
        {
            int maxarea = 0;
            int leftPointer = 0;
            int rightPointer = input.Length - 1;

            while (leftPointer <= rightPointer)
            {
                var length = Math.Min(input[leftPointer], input[rightPointer]);
                var width = (rightPointer) - leftPointer;
                var area = length * width;
                maxarea = Math.Max(maxarea, area);

                if (input[leftPointer] < input[rightPointer])
                    leftPointer = leftPointer + 1;
                else
                    rightPointer = rightPointer - 1;
            }

            return maxarea;
        }
    }
}
