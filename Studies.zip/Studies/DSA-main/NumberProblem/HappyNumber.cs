/*Problem:
Given an integer find it is a happy number or not

Solution:
Apply modulus operator (%) to get remainder of the number. for example 19%10 = 9. Then multiply by itself (9*9) store the result in the local varaiable. 
Then apply divide operator (/) to get quotient (19/10 = 1). Run the loop untl the result is not equal to given number to avoid cyclic && result is not equal to 1.

Given number is 19
1² + 9² = 1 + 81 = 82  
8² + 2² = 64 + 4 = 68  
6² + 8² = 36 + 64 = 100  
1² + 0² + 0² = 1 → Happy number!
*/

public static class HappyNumber
{
    public static bool IsTrue(int input)
    {
        var result = GetNextNumber(input);

        while (result != 1 && input != result )
        {
            result = GetNextNumber(result);
        }

        return result == 1;
    }

    private static int GetNextNumber(int num)
    {
        var result = 0;

        while (num > 0)
        {
            var digit = num % 10;

            result = result + digit * digit;

            num = num / 10;
        }

        return result;
    }
}



/*var input = 4; // 19;
var result = HappyNumber.IsTrue(input);
Console.WriteLine($"Is it Happy Number {result}");*/
