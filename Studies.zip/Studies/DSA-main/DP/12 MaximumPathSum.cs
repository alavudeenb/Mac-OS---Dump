﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DP
{
    internal class MaximumPathSum
    {
        int[,] memo;
        int[,] dp;
        public int Find(int[,] input)
        {
            memo = new int[input.GetLength(0), input.GetLength(1)];
            dp = new int[input.GetLength(0), input.GetLength(1)];

            return FindUsingSpaceOptimization(input);
            return FindUsingDP(input);
            int max = 0;
            for (int column = 0; column < input.GetLength(1); column++)
            {
                var tempMax = FindUsingMemo(0, column, input);
                //var tempMax = FindRecursively(0, column, input);

                max = Math.Max(max, tempMax);
            }
            return max;
        }

        private int FindRecursively(int row, int column, int[,] input) // O(3^n)
        {
            if (row == input.GetLength(0) - 1)
                return input[row, column];


            int localMax = 0;
            int[,] directions = new[,] { { 1, 0 }, { 1, -1 }, { 1, 1 } };
            for (int init = 0; init < directions.GetLength(0); init++)
            {
                var currentRow = row + directions[init, 0];
                var currentColumn = column + directions[init, 1];
                if (currentRow >= 0 && currentRow < input.GetLength(0) && currentColumn >= 0 && currentColumn < input.GetLength(1))
                {
                    int tempMax = input[row, column] + FindRecursively(currentRow, currentColumn, input);
                    localMax = Math.Max(localMax, tempMax);
                }
            }
            return localMax;
        }

        private int FindUsingMemo(int row, int column, int[,] input) //O(n*m) space stack O(n) memo O(n*m)
        {
            if (row == input.GetLength(0) - 1)
                return input[row, column];

            if (memo[row, column] != 0) return memo[row, column];

            int localMax = 0;
            int[,] directions = new[,] { { 1, 0 }, { 1, -1 }, { 1, 1 } };
            for (int init = 0; init < directions.GetLength(0); init++)
            {
                var currentRow = row + directions[init, 0];
                var currentColumn = column + directions[init, 1];
                if (currentRow >= 0 && currentRow < input.GetLength(0) && currentColumn >= 0 && currentColumn < input.GetLength(1))
                {
                    int tempMax = input[row, column] + FindRecursively(currentRow, currentColumn, input);
                    localMax = Math.Max(localMax, tempMax);
                }
            }

            memo[row, column] = localMax;
            return localMax;
        }

        private int FindUsingDP(int[,] input) // O(n*m) space dp O(n*m)
        {
            int globalMax = 0;
            for (int row = input.GetLength(0) - 1; row >= 0; row--)
            {
                for (int column = input.GetLength(1) - 1; column >= 0; column--)
                {
                    if (row == input.GetLength(0) - 1)
                    {
                        dp[row, column] = input[row, column];
                    }
                    else
                    {
                        int localMax = 0;
                        int[,] directions = new[,] { { 1, 0 }, { 1, -1 }, { 1, 1 } };
                        for (int init = 0; init < directions.GetLength(0); init++)
                        {
                            var currentRow = row + directions[init, 0];
                            var currentColumn = column + directions[init, 1];
                            if (currentRow >= 0 && currentRow < input.GetLength(0) && currentColumn >= 0 && currentColumn < input.GetLength(1))
                            {
                                int tempMax = input[row, column] + dp[currentRow, currentColumn];
                                localMax = Math.Max(localMax, tempMax);
                            }
                        }
                        dp[row, column] = localMax;

                        if (row == 0)
                            globalMax = Math.Max(globalMax, localMax);
                    }
                }
            }

            return globalMax;
        }

        private int FindUsingSpaceOptimization(int[,] input) // O(n*m) space O(4) => O(1)
        {
            var prev = new int[input.GetLength(1)];
            var globalMax = 0;
            for (int row = input.GetLength(0) - 1; row >= 0; row--)
            {
                var curr = new int[input.GetLength(1)];
                for (int column = input.GetLength(1) - 1; column >= 0; column--)
                {
                    if (row == input.GetLength(0) - 1)
                    {
                        curr[column] = input[row, column];
                    }
                    else
                    {
                        int localMax = 0;
                        int[,] directions = new[,] { { 1, 0 }, { 1, -1 }, { 1, 1 } };
                        for (int init = 0; init < directions.GetLength(0); init++)
                        {
                            var currentRow = row + directions[init, 0];
                            var currentColumn = column + directions[init, 1];
                            if (currentRow >= 0 && currentRow < input.GetLength(0) && currentColumn >= 0 && currentColumn < input.GetLength(1))
                            {
                                int tempMax = input[row, column] + prev[currentColumn];
                                localMax = Math.Max(localMax, tempMax);
                            }
                        }
                        curr[column] = localMax;

                        if (row == 0)
                            globalMax = Math.Max(globalMax, localMax);
                    }
                }
                prev = curr;
            }
            return globalMax;
        }
    }
}
