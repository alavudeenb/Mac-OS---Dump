﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DP
{
    internal class _46_LongestBitonicSubsequence
    {
        public int Find(int[] input)
        {
            var forwarddp = new int[input.Length];
            var backwarddp = new int[input.Length];

            for (int ind = 0; ind < input.Length; ind++)
            {
                forwarddp[ind] = 1;
                backwarddp[ind] = 1;
            }

            for (int ind = 0; ind < input.Length; ind++)
            {
                for (int prevInd = 0; prevInd < ind; prevInd++)
                {
        // Longest increasing subsequnece condition    
                    if (input[ind] > input[prevInd] && forwarddp[ind] < 1 + forwarddp[prevInd])
                    {
                        forwarddp[ind] = 1 + forwarddp[prevInd];
                    }
                }
            }

            for (int ind = input.Length - 1; ind >= 0; ind--)
            {
                for (int prevInd = input.Length - 1; prevInd > ind; prevInd--)
                {
                    if (input[ind] > input[prevInd] && backwarddp[ind] < 1 + backwarddp[prevInd])
                    {
                        backwarddp[ind] = 1 + backwarddp[prevInd];
                    }
                }
            }

            var max = 0;
            for (int ind = 0; ind < input.Length; ind++)
            {
                max = Math.Max(max, (forwarddp[ind] + backwarddp[ind] - 1)); // -1 is because when going from forward and backward there is a common element shared between them
            }

            return max;
        }
    }
}
