﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DP
{
    internal class _53_PartitionDP_PalindromePartition2
    {
        char[] inputString;
        int[] memo;
        int[] dp;

        public int FindMinimumPartition(char[] inputString)
        {
            this.inputString = inputString;
            this.memo = new int[this.inputString.Length];
            this.dp = new int[this.inputString.Length + 1];

            for (int ind = 0; ind < this.memo.Length; ind++)
                this.memo[ind] = -1;

            return this.FindUsingTabulation() - 1;
            return this.FindUsingMemo(0) - 1;
            return this.FindUsingRecursion(0) - 1; // -1 is because after last character also the partition happens hence -1 is to subtract the count
        }

        private int FindUsingRecursion(int i) // Exponential
        {
            if (i == this.inputString.Length) return 0;

            var countMin = Int32.MaxValue;
            for (int ind = i; ind < this.inputString.Length; ind++)
            {
                if (IsPalindrome(i, ind))
                {
                    var localMin = 1 + this.FindUsingRecursion(ind + 1);
                    countMin = Math.Min(countMin, localMin);
                }
            }

            return countMin;
        }


        private int FindUsingMemo(int i) // o(n2) // space O(n) stack O(n) 
        {
            if (i == this.inputString.Length) return 0;

            if (this.memo[i] != -1) return this.memo[i];

            var countMin = Int32.MaxValue;
            for (int ind = i; ind < this.inputString.Length; ind++)
            {
                if (IsPalindrome(i, ind))
                {
                    var localMin = 1 + this.FindUsingMemo(ind + 1);
                    countMin = Math.Min(countMin, localMin);
                }
            }

            this.memo[i] = countMin;

            return countMin;
        }

        private int FindUsingTabulation() // o(n2) // space O(n)
        {
            this.dp[this.inputString.Length] = 0;

            for (int i = this.inputString.Length - 1; i >= 0; i--)
            {
                var countMin = Int32.MaxValue;
                for (int ind = i; ind < this.inputString.Length; ind++)
                {
                    if (IsPalindrome(i, ind))
                    {
                        var localMin = 1 + this.dp[ind + 1];
                        countMin = Math.Min(countMin, localMin);
                    }
                }
                this.dp[i] = countMin;
            }            

            return this.dp[0];
        }


        private bool IsPalindrome(int i, int j)
        {
            var _i = i;
            var _j = j;
            while (_i < _j)
            {
                if (this.inputString[_i] != this.inputString[_j]) return false;

                _i++;
                _j--;
            }
            return true;
        }
    }
}
