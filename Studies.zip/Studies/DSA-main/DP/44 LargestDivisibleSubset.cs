﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DP
{
    internal class _44_LargestDivisibleSubset
    {
        public int[] Find(int[] input)
        {
            var dp = new int[input.Length];
            var backTracking = new int[input.Length];

            for (int ind = 0; ind < input.Length; ind++)
            {
                dp[ind] = 1;
                backTracking[ind] = ind;
            }

            int maxLDS = 0;
            int maxLDSIndex = 0;
            for (int ind = 0; ind < input.Length; ind++)
            {
                for (int prevInd = 0; prevInd < ind; prevInd++)
                {
                    if ((input[ind] % input[prevInd] == 0 ||
                       input[prevInd] % input[ind] == 0) && dp[ind] < 1 + dp[prevInd])
                    {
                        dp[ind] = 1 + dp[prevInd];
                        backTracking[ind] = prevInd;
                    }
                }
                if (maxLDS < dp[ind])
                {
                    maxLDS = dp[ind];
                    maxLDSIndex = ind;
                }
            }

            var output = new List<int>();
            output.Add(input[maxLDSIndex]);

            while (maxLDSIndex != backTracking[maxLDSIndex])
            {
                maxLDSIndex = backTracking[maxLDSIndex];
                output.Add(input[maxLDSIndex]);
            }

            return output.ToArray();


        }
    }
}
