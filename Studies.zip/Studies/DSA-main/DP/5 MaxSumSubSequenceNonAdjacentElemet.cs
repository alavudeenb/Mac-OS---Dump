﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DP
{
    internal class MaxSumSubSequenceNonAdjacentElemet
    {
        int maximumSubSequence = 0;

        int[] memo;
        int[] dp;
        public int Find(int[] input)
        {
            memo = new int[input.Length];
            dp = new int[input.Length];

            return FindRecursivelyAnotherWayWithDPVariables(input);
            //return FindRecursivelyAnotherWayWithDP(input);
            //return FindRecursivelyAnotherWayWithMemo(0, input);
            //return FindRecursivelyAnotherWay2(0, input);
            //return FindRecursivelyAnotherWay(0, input);
            //return FindRecursively(0, 0, input);
        }

        private int FindRecursively(int index, int sum, int[] input) // O(2^n) NOTE: Not possible Memo due to varying sum parameter
        {
            if (index >= input.Length)
            {
                maximumSubSequence = Math.Max(maximumSubSequence, sum);
                return maximumSubSequence;
            }

            sum = sum + input[index];
            FindRecursively(index + 2, sum, input);
            sum = sum - input[index];

            FindRecursively(index + 1, sum, input);

            return maximumSubSequence;
        }

        private int FindRecursivelyAnotherWay(int index, int[] input) // O(2^n)
        {
            if (index == input.Length - 1)
                return input[index];

            if (index >= input.Length)
                return 0;

            var sum1 = input[index] + FindRecursivelyAnotherWay(index + 2, input);

            var sum2 = 0 + FindRecursivelyAnotherWay(index + 1, input);

            return Math.Max(sum1, sum2);
        }

        private int FindRecursivelyAnotherWay2(int index, int[] input) // O(n*(2^n))
        {
            int maxResult = 0;
            for (int init = 0; init < input.Length; init++)
            {
                var result = FindRecursivelyAnotherWay2_1(init, input);
                maxResult = Math.Max(maxResult, result);
            }
            return maxResult;
        }
        private int FindRecursivelyAnotherWay2_1(int index, int[] input)
        {
            if (index == input.Length - 1)
                return input[index];

            if (index >= input.Length)
                return 0;

            int localMaximumSubSequence = 0;
            for (int init = index; init < input.Length; init++)
            {
                var result = input[index] + FindRecursivelyAnotherWay2_1(init + 2, input);

                localMaximumSubSequence = Math.Max(result, localMaximumSubSequence);
            }

            return Math.Max(maximumSubSequence, localMaximumSubSequence);
        }

        private int FindRecursivelyAnotherWayWithMemo(int index, int[] input) // O(n) Space O(n)+O(n)
        {
            if (index == input.Length - 1)
                return input[index];

            if (index >= input.Length)
                return 0;

            if (memo[index] != 0)
                return memo[index];

            var left = input[index] + FindRecursivelyAnotherWayWithMemo(index + 2, input);

            var right = 0 + FindRecursivelyAnotherWayWithMemo(index + 1, input);

            var result = Math.Max(left, right);
            memo[index] = result;

            return result;
        }

        private int FindRecursivelyAnotherWayWithDP(int[] input) // O(n) Space O(n)
        {
            dp[input.Length - 1] = input[input.Length - 1];

            for (int init = input.Length - 2; init >= 0; init--)
            {
                var left = input[init];
                if (init + 2 < input.Length) left += dp[init + 2];
                var right = 0 + dp[init + 1];

                dp[init] = Math.Max(left, right);
            }

            return dp[0];
        }

        private int FindRecursivelyAnotherWayWithDPVariables(int[] input) // O(n) Space O(1)
        {
            var prev2 = 0;
            var prev = input[input.Length - 1];

            for (int init = input.Length - 2; init >= 0; init--)
            {
                var left = input[init];
                if (init + 2 < input.Length) left += prev2;
                var right = 0 + prev;

                var curr = Math.Max(left, right);

                prev2 = prev;
                prev = curr;
            }

            return prev;
        }
    }
}
