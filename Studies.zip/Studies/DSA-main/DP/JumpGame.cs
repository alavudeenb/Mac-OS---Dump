﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DP
{
    internal class JumpGame
    {
        public static int NumberOfWays(int logOfWoods)
        {
            return f(0, logOfWoods);
        }

        private static int f(int index, int n)
        {
            if (index == n)
                return 1;

            if (index > n)
                return 0;

            return f(index + 1, n) + f(index + 2, n) + f(index + 3, n);
        }
    }
}
