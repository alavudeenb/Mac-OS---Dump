﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DP
{
    internal class CherryPick2
    {
        int globalMax = 0;
        int[,,] memo;
        int[,,] dp;
        public int Find(int[,] input)
        {
            memo = new int[input.GetLength(0), input.GetLength(1), input.GetLength(1)];
            dp = new int[input.GetLength(0), input.GetLength(1), input.GetLength(1)];

            return FindUsingSpaceOptimization(input);
            return FindUsingDP(input);
            return FindUsingMemo(0, 0, input.GetLength(1) - 1, input);
            return FindRecursively(0, 0, input.GetLength(1) - 1, input);
        }

        private int FindRecursively(int row, int robo1Column1, int robo2Column2, int[,] input) // O(9^n)
        {
            if (row == input.GetLength(0) - 1)
            {
                if (robo1Column1 == robo2Column2)
                    return input[row, robo1Column1];
                else
                    return input[row, robo1Column1] + input[row, robo2Column2];
            }

            int localMax = 0;
            for (int _3directionsOfrobo1Column1 = -1; _3directionsOfrobo1Column1 <= 1; _3directionsOfrobo1Column1++)
            {
                for (int _3directionsOfrobo2Column2 = -1; _3directionsOfrobo2Column2 <= 1; _3directionsOfrobo2Column2++)
                {
                    int tempLocalMax = 0;
                    var currentRobo1Column1 = robo1Column1 + _3directionsOfrobo1Column1;
                    var currentRobo2Column2 = robo2Column2 + _3directionsOfrobo2Column2;
                    //Maximum can be acheived when both the robots collects from the valid cells.
                    //Hence when any one of the robot goes outside matrix boundy returning 0 will make the value is lesser.
                    if (currentRobo1Column1 >= 0 && currentRobo1Column1 < input.GetLength(1) && currentRobo2Column2 >= 0 && currentRobo2Column2 < input.GetLength(1))
                    {
                        if (robo1Column1 == robo2Column2)
                            tempLocalMax = input[row, robo1Column1] + FindRecursively(row + 1, currentRobo1Column1, currentRobo2Column2, input);
                        else
                            tempLocalMax = input[row, robo1Column1] + input[row, robo2Column2] + FindRecursively(row + 1, currentRobo1Column1, currentRobo2Column2, input);

                        localMax = Math.Max(localMax, tempLocalMax);
                    }
                }
            }

            return Math.Max(globalMax, localMax);
        }

        private int FindUsingMemo(int row, int robot1Column1, int robot2Column2, int[,] input) // O(n*m*m)*9 => O(n*m2) space stack O(n) memo = O(n*m*m)
        {
            if (row == input.GetLength(0) - 1)
            {
                if (robot1Column1 == robot2Column2)
                    return input[row, robot1Column1];
                else
                    return input[row, robot1Column1] + input[row, robot2Column2];
            }

            if (memo[row, robot1Column1, robot2Column2] != 0)
                return memo[row, robot1Column1, robot2Column2];

            int localMax = 0;
            for (int _3directionsRobot1Column1 = -1; _3directionsRobot1Column1 <= 1; _3directionsRobot1Column1++)
            {
                for (int _3directionsRobot2Column2 = -1; _3directionsRobot2Column2 <= 1; _3directionsRobot2Column2++)
                {
                    int tempLocalMax = 0;
                    var currentRobot1Column1 = robot1Column1 + _3directionsRobot1Column1;
                    var currentRobot2Column2 = robot2Column2 + _3directionsRobot2Column2;

                    if (currentRobot1Column1 >= 0 && currentRobot1Column1 < input.GetLength(1) && currentRobot2Column2 >= 0 && currentRobot2Column2 < input.GetLength(1))
                    {
                        if (robot1Column1 == robot2Column2)
                            tempLocalMax = input[row, robot1Column1];
                        else
                            tempLocalMax = input[row, robot1Column1] + input[row, robot2Column2];

                        tempLocalMax = tempLocalMax + FindRecursively(row + 1, currentRobot1Column1, currentRobot2Column2, input);
                    }
                    localMax = Math.Max(localMax, tempLocalMax);
                }
            }

            globalMax = Math.Max(globalMax, localMax);

            memo[row, robot1Column1, robot2Column2] = globalMax;

            return globalMax;
        }

        private int FindUsingDP(int[,] input) // O(n*m*m) => O(n*m2) space dp O(n*m*m)
        {
            for (int robot1Column1 = 0; robot1Column1 < input.GetLength(1); robot1Column1++)
            {
                for (int robot2Column2 = 0; robot2Column2 < input.GetLength(1); robot2Column2++)
                {
                    if (robot1Column1 == robot2Column2)
                        dp[input.GetLength(0) - 1, robot1Column1, robot2Column2] = input[input.GetLength(0) - 1, robot1Column1];
                    else
                        dp[input.GetLength(0) - 1, robot1Column1, robot2Column2] = input[input.GetLength(0) - 1, robot1Column1] + input[input.GetLength(0) - 1, robot2Column2];
                }
            }


            for (int row = input.GetLength(0) - 2; row >= 0; row--)
            {
                for (int robot1Column1 = input.GetLength(1) - 1; robot1Column1 >= 0; robot1Column1--)
                {
                    for (int robot2Column2 = input.GetLength(1) - 1; robot2Column2 >= 0; robot2Column2--)
                    {
                        int localMax = 0;
                        for (int _3directionsRobot1Column1 = -1; _3directionsRobot1Column1 <= 1; _3directionsRobot1Column1++)
                        {
                            for (int _3directionsRobot2Column2 = -1; _3directionsRobot2Column2 <= 1; _3directionsRobot2Column2++)
                            {
                                int tempLocalMax = 0;
                                var currentRobot1Column1 = robot1Column1 + _3directionsRobot1Column1;
                                var currentRobot2Column2 = robot2Column2 + _3directionsRobot2Column2;

                                if (currentRobot1Column1 >= 0 && currentRobot1Column1 < input.GetLength(1) && currentRobot2Column2 >= 0 && currentRobot2Column2 < input.GetLength(1))
                                {
                                    if (robot1Column1 == robot2Column2)
                                        tempLocalMax = input[row, robot1Column1];
                                    else
                                        tempLocalMax = input[row, robot1Column1] + input[row, robot2Column2];

                                    tempLocalMax = tempLocalMax + dp[row + 1, currentRobot1Column1, currentRobot2Column2];
                                }
                                localMax = Math.Max(localMax, tempLocalMax);
                            }
                        }

                        globalMax = Math.Max(globalMax, localMax);

                        dp[row, robot1Column1, robot2Column2] = globalMax;
                    }
                }
            }
            return dp[0, 0, input.GetLength(1) - 1];
        }

        private int FindUsingSpaceOptimization(int[,] input)
        {
            var prev = new int[input.GetLength(1), input.GetLength(1)];

            for (int robot1Column1 = 0; robot1Column1 < input.GetLength(1); robot1Column1++)
            {
                for (int robot2Column2 = 0; robot2Column2 < input.GetLength(1); robot2Column2++)
                {
                    if (robot1Column1 == robot2Column2)
                        prev[robot1Column1, robot2Column2] = input[input.GetLength(0) - 1, robot1Column1];
                    else
                        prev[robot1Column1, robot2Column2] = input[input.GetLength(0) - 1, robot1Column1] + input[input.GetLength(0) - 1, robot2Column2];
                }
            }


            for (int row = input.GetLength(0) - 2; row >= 0; row--)
            {
                var curr = new int[input.GetLength(1), input.GetLength(1)];
                for (int robot1Column1 = input.GetLength(1) - 1; robot1Column1 >= 0; robot1Column1--)
                {
                    for (int robot2Column2 = input.GetLength(1) - 1; robot2Column2 >= 0; robot2Column2--)
                    {
                        int localMax = 0;
                        for (int _3directionsRobot1Column1 = -1; _3directionsRobot1Column1 <= 1; _3directionsRobot1Column1++)
                        {
                            for (int _3directionsRobot2Column2 = -1; _3directionsRobot2Column2 <= 1; _3directionsRobot2Column2++)
                            {
                                int tempLocalMax = 0;
                                var currentRobot1Column1 = robot1Column1 + _3directionsRobot1Column1;
                                var currentRobot2Column2 = robot2Column2 + _3directionsRobot2Column2;

                                if (currentRobot1Column1 >= 0 && currentRobot1Column1 < input.GetLength(1) && currentRobot2Column2 >= 0 && currentRobot2Column2 < input.GetLength(1))
                                {
                                    if (robot1Column1 == robot2Column2)
                                        tempLocalMax = input[row, robot1Column1];
                                    else
                                        tempLocalMax = input[row, robot1Column1] + input[row, robot2Column2];

                                    tempLocalMax = tempLocalMax + prev[currentRobot1Column1, currentRobot2Column2];
                                }
                                localMax = Math.Max(localMax, tempLocalMax);
                            }
                        }

                        globalMax = Math.Max(globalMax, localMax);

                        curr[robot1Column1, robot2Column2] = globalMax;
                    }
                }
                prev = curr;
            }
            return prev[0, input.GetLength(1) - 1];
        }
    }
}
