﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DP
{
    internal class _54_PartitionDP_PartitionArrayForMaximumSum
    {
        int[] input;

        int[] memo;

        int[] dp;

        public int FindMaximumSum(int[] input, int kPartition)
        {
            this.input = input;
            this.memo = new int[this.input.Length];
            this.dp = new int[this.input.Length + 1];

            for (int ind = 0; ind < this.memo.Length; ind++)
                this.memo[ind] = -1;

            return this.FindUsingTabulation(kPartition);
            return this.FindUsingMemo(0, kPartition);
            return this.FindUsingRecursion(0, kPartition);
        }

        private int FindUsingRecursion(int i, int kPartition) // Exponential
        {
            if (i > this.input.Length - 1) return 0;

            var _kPartition = kPartition;
            var max = 0;
            for (int ind = i; ind < this.input.Length && _kPartition > 0; ind++)
            {
                var localMax = GetMaxValue(i, ind) * (ind - i + 1) + FindUsingRecursion(ind + 1, kPartition);
                max = Math.Max(localMax, max);
                _kPartition--;
            }

            return max;
        }

        private int FindUsingMemo(int i, int kPartition) // O(n2) // space O(n) stack O(n)
        {
            if (i > this.input.Length - 1) return 0;

            if (this.memo[i] != -1) return this.memo[i];

            var _kPartition = kPartition;
            var max = 0;
            for (int ind = i; ind < this.input.Length && _kPartition > 0; ind++)
            {
                var localMax = GetMaxValue(i, ind) * (ind - i + 1) + FindUsingMemo(ind + 1, kPartition);
                max = Math.Max(localMax, max);
                _kPartition--;
            }

            this.memo[i] = max;
            return max;
        }


        private int FindUsingTabulation(int kPartition)
        {
            this.dp[this.input.Length] = 0;

            for (int i = this.input.Length - 1; i >= 0; i--)
            {
                var _kPartition = kPartition;
                var max = 0;
                for (int ind = i; ind < this.input.Length && _kPartition > 0; ind++)
                {
                    var localMax = GetMaxValue(i, ind) * (ind - i + 1) + dp[ind + 1];
                    max = Math.Max(localMax, max);
                    _kPartition--;
                }
                
                this.dp[i] = max;
            }

            return this.dp[0];
        }

        private int GetMaxValue(int i, int j)
        {
            var max = 0;
            for (int ind = i; ind <= j; ind++)
            {
                max = Math.Max(max, this.input[ind]);
            }
            return max;
        }
    }
}
