﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace DP
{
    internal class _37_BuySellStock3
    {
        int[] stockPrices;
        int[,,] memo;

        public int FindMaxProfit(int[] stockPrices, int maxTransactions) // Only maxTransaction (NOT unlimited, NOT only once)
        {
            this.stockPrices = stockPrices;
            this.memo = new int[this.stockPrices.Length, 2, maxTransactions + 1];

            for (int x = 0; x < this.memo.GetLength(0); x++)
                for (int y = 0; y < this.memo.GetLength(1); y++)
                    for (int z = 0; z < this.memo.GetLength(2); z++)
                        this.memo[x, y, z] = -1;

            return FindUsingSpaceOptimization(maxTransactions);
            return FindUsingTabulation(maxTransactions);
            return FindUsingMemo(0, true, maxTransactions);
            return FindRecursively(0, true, maxTransactions);
        }

        private int FindRecursively(int index, bool buy, int maxTransactions) // O(2^n)
        {
            if (maxTransactions == 0) return 0;

            if (index == this.stockPrices.Length) return 0;

            var profit = 0;
            if (buy)
                profit = Math.Max(-this.stockPrices[index] + FindRecursively(index + 1, false, maxTransactions),
                                  0 + FindRecursively(index + 1, true, maxTransactions));
            else
                profit = Math.Max(this.stockPrices[index] + FindRecursively(index + 1, true, maxTransactions - 1),
                                  0 + FindRecursively(index + 1, false, maxTransactions));

            return profit;
        }

        private int FindUsingMemo(int index, bool buy, int maxTransactions) // O(n*2*maxTransaction) // space: stack O(n) memo = O(n*2*maxTransaction)
        {
            if (maxTransactions == 0) return 0;

            if (index == this.stockPrices.Length) return 0;

            if (this.memo[index, Convert.ToInt32(buy), maxTransactions] != -1) return this.memo[index, Convert.ToInt32(buy), maxTransactions];

            var profit = 0;
            if (buy)
                profit = Math.Max(-this.stockPrices[index] + FindUsingMemo(index + 1, false, maxTransactions),
                                  0 + FindUsingMemo(index + 1, true, maxTransactions));
            else
                profit = Math.Max(this.stockPrices[index] + FindUsingMemo(index + 1, true, maxTransactions - 1),
                                  0 + FindUsingMemo(index + 1, false, maxTransactions));

            this.memo[index, Convert.ToInt32(buy), maxTransactions] = profit;

            return profit;
        }

        private int FindUsingTabulation(int maxTransactions) // O(n*2*maxTransaction) // space dp O(n*2*maxTransactions)
        {
            var dp = new int[this.stockPrices.Length, 2, maxTransactions + 1];

            for (int index = 0; index < dp.GetLength(0); index++)
                for (int buy = 0; buy < dp.GetLength(1); buy++)
                    dp[index, buy, 0] = 0;

            for (int buy = 0; buy < dp.GetLength(1); buy++)
                for (int _maxTransactions = 0; _maxTransactions < dp.GetLength(2); _maxTransactions++)
                    dp[this.stockPrices.Length, buy, _maxTransactions] = 0;


            for (int index = this.stockPrices.Length - 1; index >= 0; index--)
            {
                for (int buy = 1; buy >= 0; buy--)
                {
                    for (int _maxTransactions = maxTransactions; _maxTransactions > 0; _maxTransactions--)
                    {

                        var profit = 0;
                        if (Convert.ToBoolean(buy))
                            profit = Math.Max(-this.stockPrices[index] + dp[index + 1, 0, _maxTransactions],
                                              0 + dp[index + 1, 1, _maxTransactions]);
                        else
                            profit = Math.Max(this.stockPrices[index] + dp[index + 1, 1, _maxTransactions - 1],
                                              0 + dp[index + 1, 0, _maxTransactions]);

                        dp[index, buy, _maxTransactions] = profit;
                    }
                }
            }

            return dp[0, Convert.ToInt32(true), maxTransactions];
        }

        private int FindUsingSpaceOptimization(int maxTransactions) // O(n*2*maxTransaction) space: dp O(2*maxTransactions)
        {
            var prev = new int[2, maxTransactions + 1];

            for (int buy = 0; buy < 2; buy++)
                prev[buy, 0] = 0;

            for (int buy = 0; buy < 2; buy++)
                for (int _maxTransactions = 0; _maxTransactions < maxTransactions + 1; _maxTransactions++)
                    prev[buy, _maxTransactions] = 0;


            for (int index = this.stockPrices.Length - 1; index >= 0; index--)
            {
                var curr = new int[2, maxTransactions +1];
                for (int buy = 1; buy >= 0; buy--)
                {
                    for (int _maxTransactions = maxTransactions; _maxTransactions > 0; _maxTransactions--)
                    {

                        var profit = 0;
                        if (Convert.ToBoolean(buy))
                            profit = Math.Max(-this.stockPrices[index] + prev[0, _maxTransactions],
                                              0 + prev[1, _maxTransactions]);
                        else
                            profit = Math.Max(this.stockPrices[index] + prev[1, _maxTransactions - 1],
                                              0 + prev[0, _maxTransactions]);

                        curr[buy, _maxTransactions] = profit;
                    }
                }
                prev = curr;
            }

            return prev[Convert.ToInt32(true), maxTransactions];
        }
    }
}
