﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DP
{
    internal class _48_PartitionDB_MCM
    {
        int[] inputMatrixDimensions;

        int[,] memo;

        public int FindMinimumOperation(int[] inputMatrixDimensions)
        {
            this.inputMatrixDimensions = inputMatrixDimensions;
            this.memo = new int[this.inputMatrixDimensions.Length, this.inputMatrixDimensions.Length];

            for (int row = 0; row < this.memo.GetLength(0); row++)
                for (int column = 0; column < this.memo.GetLength(1); column++)
                    this.memo[row, column] = -1;

            return FindUsingTabulation();
            return FindUsingMemo(1, this.inputMatrixDimensions.Length - 1);
            return FindRecursively(1, this.inputMatrixDimensions.Length - 1);
        }

        private int FindRecursively(int i, int j) // O(2^n)
        {
            if (i == j) return 0;

            var min = Int32.MaxValue;
            for (int k = i; k <= j - 1; k++) // Reason for j-1 is because in line no 29 is having k + 1. If K reaches till end of the array which is j value then K+1 will go outside array.
            {
                var localMin = (this.inputMatrixDimensions[i - 1] * // The reason for [i-1] [k] [j] is,
                                                                    // let's say A((BC)D). input = [10,20,30,40,50] , assume i = 1st index and j=4th (n-1)  index, then A = 10*20 B = 20*30 C = 30*40 D = 40*50
                                                                    // BC = 20*30*30*40 = result array 20*40. no of operations = 20*30*40
                                                                    // ((BC)D) = 20*40*40*50 = result array 20*50. no of operations 20*40*50
                                                                    // A((BC)D) = 10*20*20*50 = result array 10*50. no of operations 10*20*50. 10 is present in the i-1th position in the input array and then 20 is present in the kth position and finally 50 is present in the jth position.
                               this.inputMatrixDimensions[k] *
                               this.inputMatrixDimensions[j]) +
                               FindRecursively(i, k) + // Partition 1
                               FindRecursively(k + 1, j); // Partition 2

                min = Math.Min(min, localMin);
            }

            return min;
        }

        private int FindUsingMemo(int i, int j) // O(n*n*n) = O(n3). parameter i will have n values, j will have n values and for each value of i and j there is a loop inside function running hence it is also n. Therefore n3
        {
            if (i == j) return 0;

            if (this.memo[i, j] != -1) return this.memo[i, j];

            var min = Int32.MaxValue;
            for (int k = i; k <= j - 1; k++) // Reason for j-1 is because in line no 29 is having k + 1. If K reaches till end of the array which is j value then K+1 will go outside array.
            {
                var localMin = (this.inputMatrixDimensions[i - 1] * // The reason for [i-1] [k] [j] is,
                                                                    // let's say A((BC)D). input = [10,20,30,40,50] , assume i = 1st index and j=4th (n-1)  index, then A = 10*20 B = 20*30 C = 30*40 D = 40*50
                                                                    // BC = 20*30*30*40 = result array 20*40. no of operations = 20*30*40
                                                                    // ((BC)D) = 20*40*40*50 = result array 20*50. no of operations 20*40*50
                                                                    // A((BC)D) = 10*20*20*50 = result array 10*50. no of operations 10*20*50. 10 is present in the i-1th position in the input array and then 20 is present in the kth position and finally 50 is present in the jth position.
                               this.inputMatrixDimensions[k] *
                               this.inputMatrixDimensions[j]) +
                               FindUsingMemo(i, k) +
                               FindUsingMemo(k + 1, j);

                min = Math.Min(min, localMin);
            }

            this.memo[i, j] = min;

            return min;
        }

        private int FindUsingTabulation() // O(n3)
        {
            var dp = new int[this.inputMatrixDimensions.Length, this.inputMatrixDimensions.Length];

            for (int row = 0; row < dp.GetLength(0); row++)
                for (int column = 0; column < dp.GetLength(1); column++)
                    dp[row, column] = row == column ? 0 : 0; // This is just to keep base case matching from the recursion funciton. Even if we didn't write it would be 0

            for (int i = this.inputMatrixDimensions.Length - 1; i >= 1; i--) // In the recursion function i is begining from 1 to n-1 and j is begingin from n-1 to 1
            {
                for (int j = i + 1; j <= this.inputMatrixDimensions.Length - 1; j++) // The reason for i+1 is because j should always be after i th position hence i+1
                {
                    if (i != j)
                    {
                        var min = Int32.MaxValue;
                        for (int k = i; k <= j - 1; k++) // Reason for j-1 is because in line no 29 is having k + 1. If K reaches till end of the array which is j value then K+1 will go outside array.
                        {
                            var localMin = (this.inputMatrixDimensions[i - 1] * // The reason for [i-1] [k] [j] is,
                                                                                // let's say A((BC)D). input = [10,20,30,40,50] , assume i = 1st index and j=4th (n-1)  index, then A = 10*20 B = 20*30 C = 30*40 D = 40*50
                                                                                // BC = 20*30*30*40 = result array 20*40. no of operations = 20*30*40
                                                                                // ((BC)D) = 20*40*40*50 = result array 20*50. no of operations 20*40*50
                                                                                // A((BC)D) = 10*20*20*50 = result array 10*50. no of operations 10*20*50. 10 is present in the i-1th position in the input array and then 20 is present in the kth position and finally 50 is present in the jth position.
                                           this.inputMatrixDimensions[k] *
                                           this.inputMatrixDimensions[j]) +
                                           dp[i, k] +
                                           dp[k + 1, j];

                            min = Math.Min(min, localMin);
                        }
                        dp[i, j] = min;
                    }
                }
            }

            return dp[1, this.inputMatrixDimensions.Length - 1];
        }
    }
}
