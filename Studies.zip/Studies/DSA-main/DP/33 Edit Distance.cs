﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DP
{
    internal class _33_Edit_Distance
    {
        string str1;

        string str2;

        int[,] memo;

        public int Find(string str1, string str2)
        {
            this.str1 = str1;
            this.str2 = str2;
            this.memo = new int[this.str1.Length + 1, this.str2.Length + 1];

            for (int row = 0; row <= this.str1.Length; row++)
                for (int column = 0; column <= this.str2.Length; column++)
                    this.memo[row, column] = -1;

            return this.FindUsingSpaceOptimization();
            return this.FindUsingTabulation();
            return this.FindUsingMemo(this.str1.Length, this.str2.Length);
            return this.FindRecursively(this.str1.Length, this.str2.Length);

            //return this.FindRecursively(this.str1.Length - 1, this.str2.Length - 1);
        }

        /*private int FindRecursively(int index1, int index2)
        {
            if (index2 < 0) // This condition is for number of remaining characters to be deleted from str1
                return index1 + 1; // +1 is because of zero based index.

            if (index1 < 0) // This condition is for number of remaining characters to be inserted from str2
                return index2 + 1;

            if (this.str1[index1] == this.str2[index2])
                return 0 + FindRecursively(index1 - 1, index2 - 1);
            else
                return Math.Min(1 + FindRecursively(index1, index2 - 1),
                            Math.Min(1 + FindRecursively(index1 - 1, index2),
                                     1 + FindRecursively(index1 - 1, index2 - 1)));
        }*/

        private int FindRecursively(int index1, int index2)
        {
            if (index2 == 0) // This condition is for number of remaining characters to be deleted from str1
                return (index1 - 1) + 1; // -1 because 1D array. +1 is because of zero based index. 

            if (index1 == 0) // This condition is for number of remaining characters to be inserted from str2
                return (index2 - 1) + 1; // -1 because 1D array. +1 is because of zero based index. 

            if (this.str1[index1 - 1] == this.str2[index2 - 1])
                return 0 + FindRecursively(index1 - 1, index2 - 1);
            else
                return Math.Min(1 + FindRecursively(index1, index2 - 1),
                            Math.Min(1 + FindRecursively(index1 - 1, index2),
                                     1 + FindRecursively(index1 - 1, index2 - 1)));
        }

        private int FindUsingMemo(int index1, int index2) // O(n*m) //space stack O(n+m) memo O(n*m)
        {
            if (index2 == 0) // This condition is for number of remaining characters to be deleted from str1
                return (index1 - 1) + 1; // -1 because 1D array. +1 is because of zero based index. 

            if (index1 == 0) // This condition is for number of remaining characters to be inserted from str2
                return (index2 - 1) + 1; // -1 because 1D array. +1 is because of zero based index. 

            if (this.memo[index1, index2] != -1) return this.memo[index1, index2];

            if (this.str1[index1 - 1] == this.str2[index2 - 1])
            {
                var result = 0 + FindUsingMemo(index1 - 1, index2 - 1);
                this.memo[index1, index2] = result;
                return result;
            }
            else
            {
                var result = Math.Min(1 + FindUsingMemo(index1, index2 - 1),
                                Math.Min(1 + FindUsingMemo(index1 - 1, index2),
                                         1 + FindUsingMemo(index1 - 1, index2 - 1)));
                this.memo[index1, index2] = result;
                return result;
            }
        }

        private int FindUsingTabulation()// O(n*m) //space dp O(n*m)
        {
            var dp = new int[this.str1.Length + 1, this.str2.Length + 1];

            for (int ind1 = 0; ind1 <= this.str1.Length; ind1++) // Index2==0
                dp[ind1, 0] = ind1 - 1 + 1;

            for (int ind2 = 0; ind2 <= this.str2.Length; ind2++) // Index1==0
                dp[0, ind2] = ind2 - 1 + 1;

            for (int ind1 = 1; ind1 <= this.str1.Length; ind1++)
            {
                for (int ind2 = 1; ind2 <= this.str2.Length; ind2++)
                {
                    if (this.str1[ind1 - 1] == this.str2[ind2 - 1])
                        dp[ind1, ind2] = 0 + dp[ind1 - 1, ind2 - 1];
                    else
                        dp[ind1, ind2] = Math.Min(1 + dp[ind1, ind2 - 1],
                                            Math.Min(1 + dp[ind1 - 1, ind2],
                                                     1 + dp[ind1 - 1, ind2 - 1]));
                }
            }

            return dp[this.str1.Length, this.str2.Length];
        }

        private int FindUsingSpaceOptimization()// O(n*m) //space O(m)
        {
            var prev = new int[this.str2.Length + 1];

            // Index2==0
            prev[0] = 0 - 1 + 1;

            for (int ind2 = 0; ind2 <= this.str2.Length; ind2++) // Index1==0
                prev[ind2] = ind2 - 1 + 1;

            for (int ind1 = 1; ind1 <= this.str1.Length; ind1++)
            {
                var curr = new int[this.str2.Length + 1];
                curr[0] = ind1;
                for (int ind2 = 1; ind2 <= this.str2.Length; ind2++)
                {
                    if (this.str1[ind1 - 1] == this.str2[ind2 - 1])
                        curr[ind2] = 0 + prev[ind2 - 1];
                    else
                        curr[ind2] = Math.Min(1 + curr[ind2 - 1],
                                            Math.Min(1 + prev[ind2],
                                                     1 + prev[ind2 - 1]));
                }
                prev = curr;
            }

            return prev[this.str2.Length];
        }

    }
}
