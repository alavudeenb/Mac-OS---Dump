﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DP
{
    internal class _28_LongestPalindromeSubsequence
    {
        public string Find(string str1)
        {
            return FindUsingTabulation(str1);
        }
        private string FindUsingTabulation(string str1)
        {
            var str2 = new string(str1.Reverse().ToArray());
            var dp = new int[str1.Length + 1, str2.Length + 1];

            for (int ind1 = 0; ind1 <= str1.Length; ind1++) //Index2 = 0
            {
                dp[ind1, 0] = 0;
            }

            for (int ind2 = 0; ind2 < str2.Length; ind2++)
            {
                dp[0, ind2] = 0;
            }

            for (int ind1 = 1; ind1 <= str1.Length; ind1++) // O(n*m)
            {
                for (int ind2 = 1; ind2 <= str2.Length; ind2++)
                {
                    if (str1[ind1 - 1] == str2[ind2 - 1])
                        dp[ind1, ind2] = 1 + dp[ind1 - 1, ind2 - 1];
                    else
                        dp[ind1, ind2] = 0 + Math.Max(dp[ind1 - 1, ind2], dp[ind1, ind2 - 1]);
                }
            }

            var outputIndex = dp[str1.Length, str2.Length];
            char[] output = new char[outputIndex];
            var index1 = str1.Length;
            var index2 = str2.Length;

            while (index1 > 0 && index2 > 0) // O(n+m)
            {
                if (str1[index1 - 1] == str2[index2 - 1])
                {
                    output[outputIndex - 1] = str1[index1 - 1];
                    outputIndex--;
                    index1--;
                    index2--;
                }
                else if (dp[index1 - 1, index2] > dp[index1, index2 - 1])
                {
                    index1 = index1 - 1;
                }
                else
                {
                    index2 = index2 - 1;
                }
            }

            return new string(output);
        }
    }
}
