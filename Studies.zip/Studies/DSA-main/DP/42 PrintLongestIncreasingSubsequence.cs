﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DP
{
    internal class _42_PrintLongestIncreasingSubsequence
    {
        public int[] Get(int[] input)
        {
            var dp = new int[input.Length];
            for (int ind = 0; ind < input.Length; ind++)
                dp[ind] = 1;

            var backTrackPreviousIndex = new int[input.Length];
            for (int ind = 0; ind < input.Length; ind++)
                backTrackPreviousIndex[ind] = ind;

            int maxLIS = 0;
            int maxLISIndex = 0;
            for (int ind = 0; ind < input.Length; ind++)
            {
                for (int prevInd = 0; prevInd < ind; prevInd++)
                {
                    if (input[prevInd] < input[ind] && 1 + dp[prevInd] > dp[ind]) // Previous value in the input is smaller than current value
                    {
                        // Add 1 to check existing previously seen count is greater than current seen count

                        dp[ind] = 1 + dp[prevInd]; // Store the max value
                        backTrackPreviousIndex[ind] = prevInd; // Store the previous index. So that going to previous index we get all values of longest increase subsequence.
                    }
                }
                if (dp[ind] > maxLIS) // Track index holding, max value
                {
                    maxLIS = dp[ind];
                    maxLISIndex = ind;
                }
            }

            List<int> output = new List<int>();
            output.Add(input[maxLISIndex]);

            int _maxLISIndex = maxLISIndex;
            while (_maxLISIndex != backTrackPreviousIndex[_maxLISIndex])
            {
                _maxLISIndex = backTrackPreviousIndex[_maxLISIndex];
                output.Add(input[_maxLISIndex]);
            }

            return output.ToArray();
        }
    }
}
