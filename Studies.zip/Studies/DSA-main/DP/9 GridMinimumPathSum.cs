﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DP
{
    internal class GridMinimumPathSum
    {
        int[,] memo;
        int[,] dp;

        public int Find(int[,] input)
        {
            memo = new int[input.GetLength(0), input.GetLength(1)];
            dp = new int[input.GetLength(0), input.GetLength(1)];

            return FindUsingSpaceOptimisation(input);
            return FindUsingTablulation(input);
            return FindUsingMemo(0, 0, input);
            return FindRecursively(0, 0, input);
        }

        private int FindRecursively(int row, int column, int[,] input) // output: O(2^(n+m))
        {
            if (row == input.GetLength(0) - 1 && column == input.GetLength(1) - 1)
            {
                return input[row, column];
            }

            var directions = new[,] { { 0, 1 }, { 1, 0 } };

            var right = Int32.MaxValue;
            var currentRow = row + directions[0, 0];
            var currentColumn = column + directions[0, 1];
            if (currentRow >= 0 && currentRow < input.GetLength(0) && currentColumn >= 0 && currentColumn < input.GetLength(1))
                right = input[row, column] + FindRecursively(currentRow, currentColumn, input);

            var down = Int32.MaxValue;
            currentRow = row + directions[1, 0];
            currentColumn = column + directions[1, 1];
            if (currentRow >= 0 && currentRow < input.GetLength(0) && currentColumn >= 0 && currentColumn < input.GetLength(1))
                down = input[row, column] + FindRecursively(currentRow, currentColumn, input);

            return Math.Min(right, down);
        }

        private int FindUsingMemo(int row, int column, int[,] input) //O(n*m) space stack space O(n+m) memo space O(n*m)
        {
            if (row == input.GetLength(0) - 1 && column == input.GetLength(1) - 1)
            {
                return input[row, column];
            }

            if (memo[row, column] != 0)
                return memo[row, column];

            var directions = new[,] { { 0, 1 }, { 1, 0 } };

            var right = Int32.MaxValue;
            var currentRow = row + directions[0, 0];
            var currentColumn = column + directions[0, 1];
            if (currentRow >= 0 && currentRow < input.GetLength(0) && currentColumn >= 0 && currentColumn < input.GetLength(1))
                right = input[row, column] + FindUsingMemo(currentRow, currentColumn, input);

            var down = Int32.MaxValue;
            currentRow = row + directions[1, 0];
            currentColumn = column + directions[1, 1];
            if (currentRow >= 0 && currentRow < input.GetLength(0) && currentColumn >= 0 && currentColumn < input.GetLength(1))
                down = input[row, column] + FindUsingMemo(currentRow, currentColumn, input);

            var min = Math.Min(right, down);
            memo[row, column] = min;
            return min;
        }

        private int FindUsingTablulation(int[,] input) // O(n*m) space dp space O(n*m)
        {
            for (int row = input.GetLength(0) - 1; row >= 0; row--)
            {
                for (int column = input.GetLength(1) - 1; column >= 0; column--)
                {
                    if (row == input.GetLength(0) - 1 && column == input.GetLength(1) - 1)
                    {
                        dp[input.GetLength(0) - 1, input.GetLength(1) - 1] = input[input.GetLength(0) - 1, input.GetLength(1) - 1];
                    }
                    else
                    {
                        var directions = new[,] { { 0, 1 }, { 1, 0 } };

                        var right = Int32.MaxValue;
                        var currentRow = row + directions[0, 0];
                        var currentColumn = column + directions[0, 1];
                        if (currentRow >= 0 && currentRow < input.GetLength(0) && currentColumn >= 0 && currentColumn < input.GetLength(1))
                            right = input[row, column] + dp[currentRow, currentColumn];

                        var down = Int32.MaxValue;
                        currentRow = row + directions[1, 0];
                        currentColumn = column + directions[1, 1];
                        if (currentRow >= 0 && currentRow < input.GetLength(0) && currentColumn >= 0 && currentColumn < input.GetLength(1))
                            down = input[row, column] + dp[currentRow, currentColumn];

                        var min = Math.Min(right, down);
                        dp[row, column] = min;
                    }
                }
            }

            return dp[0, 0];
        }


        private int FindUsingSpaceOptimisation(int[,] input)
        {
            var prev = new int[input.GetLength(1)];

            for (int row = input.GetLength(0) - 1; row >= 0; row--)
            {
                var curr = new int[input.GetLength(1)];
                for (int column = input.GetLength(1) - 1; column >= 0; column--)
                {
                    if (row == input.GetLength(0) - 1 && column == input.GetLength(1) - 1)
                    {
                        curr[column] = input[row, column];
                    }
                    else
                    {
                        var directions = new[,] { { 0, 1 }, { 1, 0 } };

                        var right = Int32.MaxValue;
                        var currentRow = row + directions[0, 0];
                        var currentColumn = column + directions[0, 1];
                        if (currentRow >= 0 && currentRow < input.GetLength(0) && currentColumn >= 0 && currentColumn < input.GetLength(1))
                            right = input[row, column] + curr[currentColumn];

                        var down = Int32.MaxValue;
                        currentRow = row + directions[1, 0];
                        currentColumn = column + directions[1, 1];
                        if (currentRow >= 0 && currentRow < input.GetLength(0) && currentColumn >= 0 && currentColumn < input.GetLength(1))
                            down = input[row, column] + prev[currentColumn];

                        var min = Math.Min(right, down);
                        curr[column] = min;
                    }
                }
                prev = curr;
            }

            return prev[0];
        }
    }
}

