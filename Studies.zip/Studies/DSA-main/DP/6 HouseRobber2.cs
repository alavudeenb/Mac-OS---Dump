﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DP
{
    internal class HouseRobber2
    {
        //It is same as MaxSumSubSequenceNonAdjacentElemet hence i will be taking only space optimized solution for this

        public int Find(int[] input)
        {
            var withOutLastValue = FindUsingDPSpaceOptimized(input.Take(input.Length - 1).ToArray());
            var withOutFirstValue = FindUsingDPSpaceOptimized(input.Skip(1).ToArray());

            return Math.Max(withOutLastValue, withOutFirstValue);

        }

        private int FindUsingDPSpaceOptimized(int[] input) // O(n) space O(1)
        {
            var prev2 = 0;
            var prev = input[input.Length - 1];

            for (int init = input.Length - 2; init >= 0; init--)
            {
                var left = input[init];

                if (init + 2 < input.Length)
                    left = left + prev2;

                var right = 0 + prev;

                var curr = Math.Max(left, right);

                prev2 = prev;
                prev = curr;
            }

            return prev;
        }
    }
}
