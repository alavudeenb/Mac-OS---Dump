﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DP
{
    internal class _30_MinimumInsertionsDeletionsToConvertStringAtoB
    {
        string str1;

        string str2;

        public int Find(string str1, string str2)
        {
            this.str1 = str1;
            this.str2 = str2;
            return this.FindUsingTabulation();
        }

        private int FindUsingTabulation()
        {
            var dp = new int[this.str1.Length + 1, this.str2.Length + 1];

            for (int ind1 = 0; ind1 <= this.str1.Length; ind1++)
                dp[ind1, 0] = 0;

            for (int ind2 = 0; ind2 < this.str2.Length; ind2++)
                dp[0, ind2] = 0;

            for (int ind1 = 1; ind1 <= this.str1.Length; ind1++)
            {
                for (int ind2 = 1; ind2 <= this.str2.Length; ind2++)
                {
                    if (this.str1[ind1 - 1] == this.str2[ind2 - 1])
                        dp[ind1, ind2] = 1 + dp[ind1 - 1, ind2 - 1];
                    else
                        dp[ind1, ind2] = 0 + Math.Max(dp[ind1, ind2 - 1], dp[ind1 - 1, ind2]);
                }
            }

            var longestCommonSubsequence = dp[this.str1.Length, this.str2.Length];

            var deletion = this.str1.Length - longestCommonSubsequence;
            var addition = this.str2.Length - longestCommonSubsequence;

            var totalNumberOfOperations = deletion + addition;
            
            return totalNumberOfOperations;
        }
    }
}
