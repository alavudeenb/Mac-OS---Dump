﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DP
{
    internal class BuySell
    {

        Dictionary<int, Dictionary<bool, int>> memo = new Dictionary<int, Dictionary<bool, int>>();

        int[] prices;
        public BuySell(int[] _prices)
        {
            this.prices = _prices;
        }

        public int GetMaxProfit(int index, bool buy)//, int cap)
        {
            //if (cap == 0) return 0;
            if (index >= prices.Length) return 0;


            var profit = 0;
            if (buy)
            {
                var dobuy = -prices[index] + GetMaxProfit(index + 1, false);
                var donotbuy = 0 + GetMaxProfit(index + 1, true);
                profit = Math.Max(dobuy, donotbuy);
            }
            else
            {
                var dosell = prices[index] + GetMaxProfit(index + 1, true);
                var donotsell = 0 + GetMaxProfit(index + 1, false);
                profit = Math.Max(dosell, donotsell);
            }

            return profit;
        }

        public int GetMaxProfitWithMemo(int index, bool buy)//, int cap)
        {
            Dictionary<bool, int> result;
            if (memo.TryGetValue(index, out result) && result.ContainsKey(buy))
                return memo[index][buy];

            //if (cap == 0) return 0;
            if (index >= prices.Length) return 0;


            var profit = 0;
            if (buy)
            {
                var dobuy = -prices[index] + GetMaxProfit(index + 1, false);
                var donotbuy = 0 + GetMaxProfit(index + 1, true);
                profit = Math.Max(dobuy, donotbuy);
            }
            else
            {
                var dosell = prices[index] + GetMaxProfit(index + 1, true);
                var donotsell = 0 + GetMaxProfit(index + 1, false);
                profit = Math.Max(dosell, donotsell);
            }

            Dictionary<bool, int> _result;
            if (memo.TryGetValue(index, out _result))
            {
                _result.Add(buy, profit);
            }
            else
            {
                var buyOrSellProfits = new Dictionary<bool, int>();
                buyOrSellProfits.Add(buy, profit);
                memo.Add(index, buyOrSellProfits);
            }

            return profit;
        }
    }
}
