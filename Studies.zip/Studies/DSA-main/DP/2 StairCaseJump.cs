﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DP
{
    internal class StairCaseJump
    {
        int[] memo;
        public int FindNumberOfWays(int totalStairs)
        {
            memo = new int[totalStairs + 1];

            return FindRecursivelyWithTabulation(totalStairs);
            //return FindRecursivelyWithMemo(0, totalStairs);
            //return FindRecursively(0, numberOfStairs);
        }

        private int FindRecursively(int index, int totalStairs) // O(2^n)
        {
            if (index == totalStairs) return 1;

            int countWays = 0;
            countWays = FindRecursively(index + 1, totalStairs);

            if (index + 2 <= totalStairs)
                countWays = countWays + FindRecursively(index + 2, totalStairs);

            return countWays;
        }

        private int FindRecursivelyWithMemo(int index, int numberOfStairs) //O(n)
        {
            if (index == numberOfStairs) return 1;

            if (memo[index] != 0) return memo[index];

            int countWays = 0;

            countWays = FindRecursively(index + 1, numberOfStairs);

            if (index + 2 <= numberOfStairs)
                countWays = countWays + FindRecursively(index + 2, numberOfStairs);

            memo[index] = countWays;

            return countWays;
        }

        private int FindRecursivelyWithTabulation(int numberOfStairs) //O(n)
        {
            var prev = 1;
            var prev2 = 0;

            for (int init = numberOfStairs - 1; init >= 0; init--)
            {
                var curr = prev + prev2;
                prev2 = prev;
                prev = curr;
            }

            return prev;
        }
    }
}
