﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DP
{
    internal class DP16_SubsetsWithMinimumAbsoluteSumDifference
    {
        public int Find(int[] input)
        {
            return FindUsingTabulation(input);
        }

        private int FindUsingTabulation(int[] input)
        {
            var totalSum = 0;
            for (int init = 0; init < input.Length; init++)
            {
                totalSum = totalSum + input[init];
            }

            var target = totalSum;
            var n = input.Length;
            var k = target + 1;

            var dp = new bool[n, k];

            for (int ind = 0; ind < n; ind++)
            {
                dp[ind, 0] = true;
            }

            if (input[0] <= target)
                dp[0, input[0]] = true;

            for (int ind = 1; ind < n; ind++)
            {
                for (int _k = 1; _k < k; _k++)
                {
                    var take = false;

                    if (input[ind] <= _k)
                        take = dp[ind - 1, _k - input[ind]];

                    var donotTake = dp[ind - 1, _k];

                    dp[ind, _k] = take || donotTake;
                }
            }

            var minimumSumDifference = Int32.MaxValue;

            for (int _k = 0; _k < k; _k++)
            {
                if (dp[n - 1, _k] == true)
                    minimumSumDifference = Math.Min(minimumSumDifference, Math.Abs(_k - (totalSum - _k)));
            }

            return minimumSumDifference;
        }
    }
}
