﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace DP
{
    internal class _22_CoinChange2InfiniteSupplyOfSameCoin
    {
        private int[] input;

        private int n;

        private int[,] memo;

        private int k;

        private int[,] dp;

        public int Find(int[] input, int target)
        {
            this.input = input;
            this.n = this.input.Length;
            this.k = target + 1;
            this.memo = new int[this.n, this.k];
            for (int row = 0; row < this.n; row++)
            {
                for (int column = 0; column < this.k; column++)
                {
                    this.memo[row, column] = -1;
                }
            }
            this.dp = new int[this.n, this.k];

            return FindUsingSpaceOptimization(target);
            return FindUsingTabulation(target);
            return FindUsingMemo(this.n - 1, target);
            return FindRecursively(this.n - 1, target);
        }

        private int FindRecursively(int index, int target)// Exponential -> ~O(2^n)
        {
            if (index == 0)
            {
                if (target == 0 && input[index] == 0)
                    return 2;
                else if (target == 0 && input[index] != 0)
                    return 1;
                else if (input[index] != 0 && target % input[index] == 0)
                    return 1;
                else
                    return 0;
            }

            var take = 0;
            if (input[index] <= target)
                take = FindRecursively(index, target - input[index]);

            var notTake = FindRecursively(index - 1, target);

            return take + notTake;
        }

        private int FindUsingMemo(int index, int target)// O(n*target) space memo O(n*target) stack O(n*target)
        {
            if (index == 0)
            {
                if (target == 0 && input[index] == 0)
                    return 2;
                else if (target == 0 && input[index] != 0)
                    return 1;
                else if (input[index] != 0 && target % input[index] == 0)
                    return 1;
                else
                    return 0;
            }

            if (this.memo[index, target] != -1) return this.memo[index, target];

            var take = 0;
            if (input[index] <= target)
                take = FindUsingMemo(index, target - input[index]);

            var notTake = FindUsingMemo(index - 1, target);

            var result = take + notTake;

            this.memo[index, target] = result;

            return result;
        }

        private int FindUsingTabulation(int target) // O(n*traget) space dp O(n*target)
        {
            for (int _k = 0; _k < this.k; _k++)
            {
                if (_k == 0 && input[0] == 0)
                    dp[0, _k] = 2;
                else if (_k == 0 && input[0] != 0)
                    dp[0, _k] = 1;
                else if (input[0] != 0 && _k % input[0] == 0)
                    dp[0, _k] = 1;
                else
                    dp[0, _k] = 0;
            }

            for (int ind = 1; ind < this.n; ind++)
            {
                for (int _k = 0; _k < this.k; _k++)
                {
                    var take = 0;
                    if (input[ind] <= _k)
                        take = dp[ind, _k - input[ind]];

                    var notTake = dp[ind - 1, _k];

                    var result = take + notTake;

                    this.dp[ind, _k] = result;
                }
            }

            return this.dp[this.n - 1, target];
        }

        private int FindUsingSpaceOptimization(int target) // O(n*target) space O(target)
        {
            var prev = new int[this.k];
            for (int _k = 0; _k < this.k; _k++)
            {
                if (_k == 0 && input[0] == 0)
                    prev[_k] = 2;
                else if (_k == 0 && input[0] != 0)
                    prev[_k] = 1;
                else if (input[0] != 0 && _k % input[0] == 0)
                    prev[_k] = 1;
                else
                    prev[_k] = 0;
            }

            for (int ind = 1; ind < this.n; ind++)
            {
                var curr = new int[this.k];
                for (int _k = 0; _k < this.k; _k++)
                {
                    var take = 0;
                    if (input[ind] <= _k)
                        take = curr[_k - input[ind]];

                    var notTake = prev[_k];

                    var result = take + notTake;

                    curr[_k] = result;
                }
                prev = curr;
            }

            return prev[target];
        }
    }
}
