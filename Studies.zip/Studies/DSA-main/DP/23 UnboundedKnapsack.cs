﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DP
{
    internal class _23_UnboundedKnapsack
    {
        int[] weight;

        int[] value;

        int n;

        int[,] memo;

        int k;

        int[,] dp;
        public int Find(int[] weight, int[] value, int bagWeight)
        {
            this.weight = weight;
            this.value = value;
            this.n = this.weight.Length;
            this.k = bagWeight + 1;
            this.memo = new int[this.n, this.k];
            this.dp = new int[this.n, this.k];

            for (int row = 0; row < this.n; row++)
                for (int column = 0; column < this.k; column++)
                    this.memo[row, column] = -1;

            return FindUsingSpaceOptimization(bagWeight);
            return FindUsingTabulation(bagWeight);
            return FindUsingMemo(this.n - 1, bagWeight);
            return FindRecursively(this.n - 1, bagWeight);
        }

        private int FindRecursively(int index, int bagWeight)
        {
            if (index == 0)
            {
                if (bagWeight % this.weight[index] == 0)
                    return (bagWeight / this.weight[index]) * this.value[index];
                else
                    return 0;
            }

            var take = 0;
            if (this.weight[index] <= bagWeight)
                take = this.value[index] + FindRecursively(index, bagWeight - this.weight[index]);

            var notTake = 0 + FindRecursively(index - 1, bagWeight);

            return Math.Max(take, notTake);
        }

        private int FindUsingMemo(int index, int bagWeight)
        {
            if (index == 0)
            {
                if (bagWeight % this.weight[index] == 0)
                    return (bagWeight / this.weight[index]) * this.value[index];
                else
                    return 0;
            }

            if (this.memo[index, bagWeight] != -1)
                return this.memo[index, bagWeight];

            var take = 0;
            if (this.weight[index] <= bagWeight)
                take = this.value[index] + FindUsingMemo(index, bagWeight - this.weight[index]);

            var notTake = 0 + FindUsingMemo(index - 1, bagWeight);

            var result = Math.Max(take, notTake);

            this.memo[index, bagWeight] = result;

            return result;
        }

        private int FindUsingTabulation(int bagWeight)
        {
            for (int _k = 0; _k < this.k; _k++)
            {
                if (_k % this.weight[0] == 0)
                    dp[0, _k] = (_k / this.weight[0]) * this.value[0];
                else
                    dp[0, _k] = 0;
            }

            for (int ind = 1; ind < this.n; ind++)
            {
                for (int _k = 0; _k < this.k; _k++)
                {
                    var take = 0;
                    if (this.weight[ind] <= _k)
                        take = this.value[ind] + dp[ind, _k - this.weight[ind]];

                    var notTake = 0 + dp[ind - 1, _k];

                    var result = Math.Max(take, notTake);

                    this.dp[ind, _k] = result;
                }
            }
            return this.dp[this.n - 1, bagWeight];
        }

        private int FindUsingSpaceOptimization(int bagWeight)
        {
            var prev = new int[this.k];
            for (int _k = 0; _k < this.k; _k++)
            {
                if (_k % this.weight[0] == 0)
                    prev[_k] = (_k / this.weight[0]) * this.value[0];
                else
                    prev[_k] = 0;
            }

            for (int ind = 1; ind < this.n; ind++)
            {
                var curr = new int[this.k];
                for (int _k = 0; _k < this.k; _k++)
                {
                    var take = 0;
                    if (this.weight[ind] <= _k)
                        take = this.value[ind] + curr[_k - this.weight[ind]];

                    var notTake = 0 + prev[_k];

                    var result = Math.Max(take, notTake);

                    curr[_k] = result;
                }
                prev = curr;
            }
            return prev[bagWeight];
        }
    }
}
