﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DP
{
    internal class GridUniquePaths
    {
        int[,] memo;
        int[,] dp;
        int[] previousArray;

        public int Find(int[,] input)
        {
            memo = new int[input.GetLength(0), input.GetLength(1)];
            dp = new int[input.GetLength(0), input.GetLength(1)];
            previousArray = new int[input.GetLength(1)];

            return FindWithSpaceOptimization(input);
            return FindRecursionWithDP(input);
            return FindRecursivelyWithMemo(0, 0, input);
            return FindRecursively(0, 0, input);
        }

        private int FindRecursively(int row, int column, int[,] input) // O(2^(n+m))
        {
            if (row == input.GetLength(0) - 1 && column == input.GetLength(1) - 1)
            {
                return 1;
            }

            var direction = new[,] { { 0, 1 }, { 1, 0 } };

            int sum = 0;
            for (int init = 0; init < direction.GetLength(0); init++)
            {
                if (row + direction[init, 0] < input.GetLength(0) && 
                    column + direction[init, 1] < input.GetLength(1) && 
                    row + direction[init, 0] >= 0 && 
                    column + direction[init, 1] >= 0)
                    sum = sum + FindRecursively(row + direction[init, 0], column + direction[init, 1], input);
            }
            return sum;
        }

        private int FindRecursivelyWithMemo(int row, int column, int[,] input) //O(n*m*2) => O(n*m) //space O(n*m) + stack O(n+m)
        {
            if (row == input.GetLength(0) - 1 && column == input.GetLength(1) - 1)
            {
                return 1;
            }

            if (memo[row, column] != 0)
                return memo[row, column];

            var direction = new[,] { { 0, 1 }, { 1, 0 } };

            int sum = 0;
            for (int init = 0; init < direction.GetLength(0); init++)
            {
                if (row + direction[init, 0] < input.GetLength(0) && column + direction[init, 1] < input.GetLength(1) && row + direction[init, 0] >= 0 && column + direction[init, 1] >= 0)
                    sum = sum + FindRecursivelyWithMemo(row + direction[init, 0], column + direction[init, 1], input);
            }
            memo[row, column] = sum;
            return sum;
        }

        private int FindRecursionWithDP(int[,] input) // O(n*m) // space O(n*m)
        {
            var direction = new[,] { { 0, 1 }, { 1, 0 } };

            for (int row = input.GetLength(0) - 1; row >= 0; row--)
            {
                for (int column = input.GetLength(1) - 1; column >= 0; column--)
                {
                    if (row == input.GetLength(0) - 1 && column == input.GetLength(1) - 1)
                    {
                        dp[input.GetLength(0) - 1, input.GetLength(1) - 1] = 1;
                    }
                    else
                    {
                        int sum = 0;
                        for (int init = 0; init < direction.GetLength(0); init++)
                        {
                            var currentRow = row + direction[init, 0];
                            var currentColumn = column + direction[init, 1];
                            if (currentRow < input.GetLength(0) && currentColumn < input.GetLength(1) && currentRow >= 0 && currentColumn >= 0)
                                sum = sum + dp[row + direction[init, 0], column + direction[init, 1]];
                        }
                        dp[row, column] = sum;
                    }
                }
            }

            return dp[0, 0];
        }

        private int FindWithSpaceOptimization(int[,] input) // O(n*m) space: O(4) => O(1)
        {
            var currArray = new int[input.GetLength(1)];
            for (int row = input.GetLength(0) - 1; row >= 0; row--)
            {
                for (int column = input.GetLength(1) - 1; column >= 0; column--)
                {
                    if (row == input.GetLength(0) - 1 && column == input.GetLength(1) - 1)
                    {
                        currArray[previousArray.Length - 1] = 1;
                    }
                    else
                    {
                        //other way to write below code is
                        int sum = 0;
                        if (row < input.GetLength(0) - 1)
                            sum = sum + previousArray[column];

                        if (column < input.GetLength(1) - 1)
                            sum = sum + currArray[column + 1];

                        currArray[column] = sum;

                        /*int[,] directions = new[,] { { 0, 1 }, { 1, 0 } };
                        int sum = 0;
                        for (int init = 0; init < directions.GetLength(0); init++)
                        {
                            var currentRow = row + directions[init, 0];
                            var currentColumn = column + directions[init, 1];

                            // Without the first condition for loop will always executes if loop never executes else if
                            if (currentRow < input.GetLength(0) && currentRow >= 0 && currentColumn < input.GetLength(1) && currentColumn >= 0)
                            {
                                if (directions[init, 0] > 0)
                                    sum = sum + previousArray[currentColumn]; // when row is next row and column is same then pick value from previous array
                                else
                                    sum = sum + currArray[currentColumn]; // when row is same and column is next then pick value from same array 
                            }
                        }
                        currArray[column] = sum;*/
                    }
                }
                previousArray = currArray;
            }
            return currArray[0];
        }
    }
}
