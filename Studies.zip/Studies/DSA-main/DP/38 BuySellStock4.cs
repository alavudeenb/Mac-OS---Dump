﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DP
{
    internal class _38_BuySellStock4 // K transactions
    {
        int[] stockPrices;

        public int FindMaxProfit(int[] stockPrices, int KTransactions)
        {
            this.stockPrices = stockPrices;
            return FindRecursively(0, true, KTransactions);
        }

        private int FindRecursively(int index, bool buy, int KTransactions) // O(2^n)
        {
            if (index == this.stockPrices.Length) return 0;

            if (KTransactions == 0) return 0;

            var profit = 0;
            if (buy)
                profit = Math.Max(-this.stockPrices[index] + FindRecursively(index + 1, false, KTransactions),
                                  0 + FindRecursively(index + 1, true, KTransactions));
            else
                profit = Math.Max(this.stockPrices[index] + FindRecursively(index + 1, true, KTransactions - 1),
                                  0 + FindRecursively(index + 1, false, KTransactions));

            return profit;
        }

        //Memo, Tabulation and Space optimization follows
    }
}
