﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace DP
{
    internal class SubSetSumEqualsK
    {
        int[,] memo;
        bool[,] dp;
        public bool Find(int[] input, int target)
        {
            memo = new int[input.Length, target + 1];

            for (int x = 0; x < memo.GetLength(0); x++)
            {
                for (int y = 0; y < memo.GetLength(1); y++)
                {
                    memo[x, y] = -1;
                }
            }

            return FindRecursivelyStarting_nminus1usingSpaceOptimization(input, target);
            return FindRecursivelyStarting_nminus1usingTabulation(input, target);
            return FindUsingTabulation(input, target);
            return FindUsingMemo(0, target, input);
            return FindRecursively(0, target, input);
        }

        // Below approach is little bit simpler while doing Tabulation becuase of starting form n-1 index

        private bool FindRecursivelyStarting_nminus1(int index, int target, int[] input) // O(2^n)
        {
            if (target == 0)
                return true;

            if (index == 0)
                return input[index] == target;

            bool take = false;

            if (input[index] <= target)
                take = FindRecursivelyStarting_nminus1(index - 1, target - input[index], input);

            bool notTake = FindRecursivelyStarting_nminus1(index - 1, target, input);

            return take || notTake;

        }

        private bool FindRecursivelyStarting_nminus1usingmemo(int index, int target, int[] input) // O(n*k) // space stack O(n) memo O(n*k)
        {
            if (target == 0)
                return true;

            if (index == 0)
                return input[index] == target;

            if (memo[index, target] != -1)
                return Convert.ToBoolean(memo[index, target]);

            bool take = false;

            if (input[index] <= target)
                take = FindRecursivelyStarting_nminus1(index - 1, target - input[index], input);

            bool notTake = FindRecursivelyStarting_nminus1(index - 1, target, input);

            var result = take || notTake;
            memo[index, target] = Convert.ToInt32(result);

            return result;
        }

        private bool FindRecursivelyStarting_nminus1usingTabulation(int[] input, int target) // O(n*k) // space: dp O(n*k)
        {
            int n = input.Length;
            int k = target + 1; // because we need to have till target value if targe is 4 then 0,1,2,3,4 as column values hence setting target+1 to accomodate target (4) as well
            dp = new bool[n, k];

            for (int ind = 0; ind < n; ind++)
                dp[ind, 0] = true;

            if (input[0] <= k)
                dp[0, input[0]] = true;

            for (int ind = 1; ind < n; ind++)
            {
                for (int _k = 1; _k < k; _k++)
                {
                    bool take = false;

                    if (input[ind] <= _k)
                        take = dp[ind - 1, _k - input[ind]];

                    bool donotTake = dp[ind - 1, _k];

                    dp[ind, _k] = take || donotTake;
                }
            }
            return dp[n - 1, target];
        }

        private bool FindRecursivelyStarting_nminus1usingSpaceOptimization(int[] input, int target) // O(n*k) space prev and curr O(n) + O(n) = O(2n) = O(n)
        {
            var n = input.Length;
            var k = target + 1;
            var prev = new bool[k];

            prev[0] = true;
            if (input[0] < target)
                prev[input[0]] = true;

            for (int ind = 1; ind < n; ind++)
            {
                var curr = new bool[k];
                curr[0] = true;
                for (int _k = 1; _k < k; _k++)
                {
                    var take = false;
                    if (input[ind] <= _k)
                        take = prev[_k - input[ind]];

                    var notTake = prev[_k];

                    curr[_k] = take || notTake;
                }
                prev = curr;
            }

            return prev[target];
        }

        //Below approach is somewhat harder while doing Tabulation because of starting from 0th index

        private bool FindRecursively(int index, int target, int[] input) // O(2^n)
        {
            if (target == 0)
                return true;

            if (index >= input.Length)
                return false;

            bool take = false;

            if (input[index] <= target)
                take = FindRecursively(index + 1, target - input[index], input);

            bool notTake = FindRecursively(index + 1, target, input);

            return take || notTake;
        }

        private bool FindUsingMemo(int index, int target, int[] input) // O(n * k) // space stack O(n) memo O(n*k)
        {
            if (target == 0)
                return true;

            if (index >= input.Length)
                return false;

            if (memo[index, target] != -1)
                return Convert.ToBoolean(memo[index, target]);

            bool take = false;
            if (input[index] <= target)
                take = FindRecursively(index + 1, target - input[index], input);

            bool notTake = FindRecursively(index + 1, target, input);

            var result = take || notTake;

            memo[index, target] = Convert.ToInt32(result);

            return result;
        }

        private bool FindUsingTabulation(int[] input, int target) // O(n*k) // space dp O(n*k)
        {
            var n = input.Length;
            var k = target;
            var dp = new bool[n + 1, k + 1];

            for (int dpBottomK = 0; dpBottomK <= k; dpBottomK++)
            {
                dp[n, dpBottomK] = false;
            }

            for (int index = 0; index <= n; index++)
            {
                dp[index, 0] = true;
            }

            for (int row = n - 1; row >= 0; row--)
            {
                for (int kValues = k; kValues >= 1; kValues--)
                {
                    bool take = false;

                    if (input[row] <= kValues)
                        take = dp[row + 1, kValues - input[row]];

                    bool notTake = dp[row + 1, kValues];

                    var result = take || notTake;

                    dp[row, kValues] = result;
                }
            }

            return dp[0, target];
        }
    }
}
