﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DP
{
    internal class _31_ShortestCommonSupersequence
    {
        string str1;

        string str2;

        public string Find(string str1, string str2)
        {
            this.str1 = str1;
            this.str2 = str2;

            return this.FindUsingTabulation();
        }

        private string FindUsingTabulation()
        {
            var dp = new int[this.str1.Length + 1, this.str2.Length + 1];

            for (int ind1 = 0; ind1 <= this.str1.Length; ind1++)
                dp[ind1, 0] = 0;

            for (int ind2 = 0; ind2 <= this.str2.Length; ind2++)
                dp[0, ind2] = 0;

            for (int ind1 = 1; ind1 <= this.str1.Length; ind1++)
            {
                for (int ind2 = 1; ind2 <= this.str2.Length; ind2++)
                {
                    if (this.str1[ind1 - 1] == this.str2[ind2 - 1])
                        dp[ind1, ind2] = 1 + dp[ind1 - 1, ind2 - 1];
                    else
                        dp[ind1, ind2] = 0 + Math.Max(dp[ind1 - 1, ind2], dp[ind1, ind2 - 1]);
                }
            }

            var longestCommonSubsequence = dp[this.str1.Length, this.str2.Length];
            // For common characters      Only for string1 chars without common chars   Only for string2 chars without common chars
            var shortestCommonSuperSequenceLength = longestCommonSubsequence + (this.str1.Length - longestCommonSubsequence) + (this.str2.Length - longestCommonSubsequence);

            var outputLength = shortestCommonSuperSequenceLength;
            char[] output = new char[outputLength];
            var index1 = this.str1.Length;
            var index2 = this.str2.Length;

            while (index1 > 0 && index2 > 0)
            {
                if (this.str1[index1 - 1] == this.str2[index2 - 1])
                {
                    output[outputLength - 1] = this.str1[index1 - 1];
                    index1--;
                    index2--;
                    outputLength--;
                }
                else if (dp[index1 - 1, index2] > dp[index1, index2 - 1])
                {
                    output[outputLength - 1] = this.str1[index1 - 1];
                    index1--;
                    outputLength--;
                }
                else
                {
                    output[outputLength - 1] = this.str2[index2 - 1];
                    index2--;
                    outputLength--;
                }
            }


            while (index1 > 0)
            {
                output[outputLength - 1] = this.str1[index1 - 1];
                outputLength--;
                index1--;
            }
            while (index2 > 0)
            {
                output[outputLength - 1] = this.str2[index2 - 1];
                outputLength--;
                index2--;
            }

            return new string(output);
        }
    }
}
