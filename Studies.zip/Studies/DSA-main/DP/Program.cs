﻿// See https://aka.ms/new-console-template for more information
// using DP;

Console.WriteLine("Hello, World!");

// DP technic in problem solving will be considered when
// 1. Question states that count number of ways
// 2. Find min from the all possible ways
// 3. Find max from the all possible ways
// Solution: Recursion -> memo -> tabulation

//************************************************
// 1) Try to represent the problem interms of index
// 2) Do all possible stuff on that index, according to the problem statement
// 3) Sum of all stuffs -> count number of ways
//    min of all stuffs -> Find minimum
//    max of all stuffs -> Find maximum
//************************************************

//var prices = new[] { 3, 2, 6, 5, 0, 3 }; // 2,4,1  

//var result = new BuySell(prices).GetMaxProfit(0, true);
//Console.WriteLine(result);


/*var result=JumpGame.NumberOfWays(4);
Console.WriteLine(result);*/


/*
var result = new StairCaseJump().FindNumberOfWays(totalStairs: 5);
Console.WriteLine($"Count number of ways to reach target stairs (numberOfStairs) : {result}");
*/



//var input = new[] { 30, 10, 60, 10, 60, 50 }; //output: 40 //new[] { 10, 20, 30, 40, 50 }; //output: 40 //new[] { 10, 50, 10 }; output:0 //new[] { 10, 20, 30, 10 } output:20
//var result = new FrogJump().FindMinimumEnergyLoss(input, k: 3);
//Console.WriteLine($"{result}");


//var input = new[] { 4, 3, 7, 6, 1 }; //output: 12 //new[] { 2, 1, 4, 9 }; // output: 11 (2+9)
//var result = new MaxSumSubSequenceNonAdjacentElemet().Find(input);
//Console.WriteLine(result);


//var input = new[] { 1, 2, 3, 1, 5 };//output: 8  //new[] { 1, 2, 3, 1 }; // output:4
//var result = new HouseRobber2().Find(input);
//Console.WriteLine(result);


//var input = new[,] { { 2, 1, 3 }, { 3, 4, 6 }, { 10, 1, 6 }, { 8, 3, 7 } };
//var result = new NinjasTraining().Find(input); // output: 25
//Console.WriteLine(result);


//var input = new int[3, 7]; //output:28
//var result = new GridUniquePaths().Find(input);
//Console.WriteLine(result);


//var input = new[,] { { 1, 3, 1 }, { 1, 5, 1 }, { 4, 2, 1 } };//output: 7 // new[,] { { 1, 2, 3 }, { 4, 5, 6 } }; //output: 12 
//var result = new GridMinimumPathSum().Find(input);
//Console.WriteLine(result);


//var input = new[,] { { 2, 0, 0, 0 }, { 3, 4, 0, 0 }, { 6, 5, 7, 0 }, { 4, 1, 8, 3 } }; // output: 11
//var result = new TriangleFixedStartVariableEnd().Find(input);
//Console.WriteLine(result);


//var input = new[,] { { 10, 2, 3 }, { 3, 7, 2 }, { 8, 1, 5 } }; //output: 25 //new[,] { { 1, 2, 10, 4 }, { 100, 3, 2, 1 }, { 1, 1, 20, 2 }, { 1, 2, 2, 1 } }; // output:105
//var result = new MaximumPathSum().Find(input);
//Console.WriteLine(result);


//var input = new[,] { { 3, 1, 1 }, { 2, 5, 1 }, { 1, 5, 5 }, { 2, 1, 1 } };
//var result = new CherryPick2().Find(input); // output: 24
//Console.WriteLine(result);


//var input = new[] { 3, 7, 1, 2 }; //output: True  new[] { 3, 7, 2 }; //output: False //new[] { 2, 3, 1, 1 }; // output: True
//var result = new SubSetSumEqualsK().Find(input, 4);
//Console.WriteLine(result);


//var input = new[] { 2, 8, 4, 4 }; // output: false //new[] { 2, 3, 4, 5 }; // output: true
//var result = new DP_15_EqualSubsetSum().Find(input);
//Console.WriteLine(result);



//var input = new[] { 1, 2, 3, 2 }; // output: 0 new[] { 3, 2, 7 }; // output:2
//var result = new DP16_SubsetsWithMinimumAbsoluteSumDifference().Find(input);
//Console.WriteLine(result);



//var input = new[] { 1, 2, 3, 2 };
//var target = 3;
//var result = new DP17_CountSubsetWithSumK().Find(input, target);
//Console.WriteLine(result);



//var input = new[] {1,1,1,1 }; //output:6 new[] { 5, 2, 6, 4 }; // output: 1
//var difference = 0; //3;
//var result = new DP18_CountPartitionsWithGivenDifference().Find(input, difference);
//Console.WriteLine(result);


//var weights = new[] { 3, 2, 5 }; //output: 70
//var values = new[] { 30, 40, 60 };
//var bagWeight = 6;
//var result = new DP19_01_Knapsack().Find(weights, values, bagWeight);
//Console.WriteLine(result);


//var input = new[] { 9, 6, 5, 1 };
//var target = 11;
//var result = new DP20_MinimumCoins().Find(input, target);
//Console.WriteLine(result);



//var input = new[] { 1, 2, 3, 1 };
//var target = 3;
//var result = new _21_TargetSum__().Find(input, target);
//Console.WriteLine(result);


//var input = new[] { 1, 2, 3 }; // output: 4
//var target = 4;
//var result = new _22_CoinChange2InfiniteSupplyOfSameCoin().Find(input, target);
//Console.WriteLine(result);



//var weight = new[] { 2, 4, 6 }; // output: 27
//var value = new[] { 5, 11, 13 };
//var bagWeight = 10;
//var result = new _23_UnboundedKnapsack().Find(weight, value, bagWeight);
//Console.WriteLine(result);


//var rodSize = new[] { 1, 2, 3, 4, 5, };
//var rodValues = new[] { 2, 5, 7, 8, 10 };
//var N = 5;
//var result = new _24_RodCutting().Find(rodSize, rodValues, N);
//Console.WriteLine(result);


//var str1 = "bdefg"; // output: 3
//var str2 = "bfg";
//var result = new _25_LongestCommonSubsequence().Find(str1, str2);
//Console.WriteLine(result);


//var str1 = "bdefg"; // output: bfg
//var str2 = "bfg";
//var result = new _26_PrintLongestCommonSubsequence().Find(str1, str2);
//Console.WriteLine(result);


//var str1 = "abcdghlm";   // "bdefg"; // output: 2 (fg) *This is substring problem*
//var str2 = "acdghr";  // "bfg";
//var result = new _27_LongestCommonSubstring().Find(str1, str2);
//Console.WriteLine(result);


//var str1 = "bbabcbcab"; // output: babcbab
//var result = new _28_LongestPalindromeSubsequence().Find(str1);
//Console.WriteLine(result);


//var str1 = "mbadm"; // output:2 "zzazz"; //output: 0 because it is already palindrome
//var result = new _29_MinimumInsertionToMakeStringPalindrome().Find(str1);
//Console.WriteLine(result);


//var str1 = "abcd"; // output: 3
//var str2 = "anc";
//var result = new _30_MinimumInsertionsDeletionsToConvertStringAtoB().Find(str1, str2);
//Console.WriteLine(result);


//var str1 = "brute";
//var str2 = "groot";
//var result = new _31_ShortestCommonSupersequence().Find(str1, str2);
//Console.WriteLine(result);


//var str1 = "babgbag"; // output 5
//var str2 = "bag";
//var result = new _32_NumberOfDistinctSubsequences().Find(str1, str2);
//Console.WriteLine(result);


//var str1 = "horse"; // output: 3
//var str2 = "ros";
//var result = new _33_Edit_Distance().Find(str1, str2);
//Console.WriteLine(result);


/*
var str1 = "a*?d"; // output: true // "*abc"; //output: true // "a?b"; // output: false //" ?xy"; // output: true // "ab*cd"; // output: true
var str2 = "abcfd";               // "defabc";              // "hab";                 // "uxy";                 // "abdefcd";
var result = new _34_Wildcard_Matching().Find(str1, str2);
Console.WriteLine(result);
*/



//var input = new[] { 7, 1, 5, 3, 6, 4 }; //output: 5
//var result = new _35_BestTimeToBuyAndSell().FindMaxProfit(input);
//Console.WriteLine(result);



//var input = new[] { 7, 1, 5, 3, 6, 4 }; // output: 7
//var result = new _36_BuySellStock2().FindMaxProfit(input);
//Console.WriteLine(result);


//var input = new[] { 3, 3, 5, 0, 0, 3, 1, 4 }; // output: 6
//var maxTransactions = 2;
//var result = new _37_BuySellStock3().FindMaxProfit(input, maxTransactions);
//Console.WriteLine(result);


//var input = new[] { 3, 3, 5, 0, 0, 3, 1, 4 }; // output: 8
//var KTransactions = 3;
//var result = new _38_BuySellStock4().FindMaxProfit(input, KTransactions);
//Console.WriteLine(result);



//var input = new[] { 4, 9, 0, 4, 10 }; // output: 11
//var result = new _39_BuySellStockWithCooldown().FindMaxProfit(input);
//Console.WriteLine(result);



//var input = new[] { 1, 3, 2, 8, 4, 9 }; //output: 8
//var transactionFee = 2;
//var result = new _40_BuySellStockWithTransactionFee().FindMaxProfit(input, transactionFee);
//Console.WriteLine(result);


//var input = new[] { 10, 9, 2, 5, 3, 7, 101, 18 }; // output: 4
//var result = new _41_LongestIncreasingSubsequence().Find(input);
//Console.WriteLine(result);


//var input = new[] { 5, 4, 11, 1, 16, 8 }; // output: 5 11 16
//var result = new _42_PrintLongestIncreasingSubsequence().Get(input);
//foreach (var item in result.Reverse())
//    Console.Write($"{item} ");


//var input = new[] { 1, 16, 7, 8, 4 }; // output: 1 16 8 4
//var result = new _44_LargestDivisibleSubset().Find(input);
//foreach (var item in result.Reverse())
//    Console.Write($"{item} ");


//var input = new[] { "xbc", "pcxbcf", "xb", "cxbc", "pcxbc" }; // output: xb xbc cxbc pcxbc pcxbcf // new[] { "a", "b", "ba", "bca", "bda", "bdca" }; // output: a ba bca bdca
//var result = new _45_LongestStringChain().Find(input);
//foreach (var item in result.Reverse())
//    Console.Write($"{item} ");



//var input = new[] { 1, 11, 2, 10, 4, 5, 2, 1 }; // output: 6
//var result = new _46_LongestBitonicSubsequence().Find(input);
//Console.WriteLine(result);



//var input = new[] { 1, 3, 5, 4, 7 }; // output: 2 // new[] { 1, 5, 4, 3, 2, 6, 7, 10, 8, 9 }; // output: 1
//var result = new _47_NumberOfLongestIncreasingSubsequence().Find(input);
//Console.WriteLine(result);


var input = new[,]
{
   { 'b', 'b', 'b', 'a', 'l', 'l', 'o', 'o' },
   { 'b', 'a', 'c', 'c', 'e', 's', 'c', 'n' },
   { 'a', 'l', 't', 'e', 'w', 'c', 'e', 'w' },
   { 'a', 'l', 'o', 's', 's', 'e', 'c', 'c' },
   { 'w', 'o', 'o', 'w', 'a', 'c', 'a', 'w' },
   { 'i', 'b', 'w', 'o', 'w', 'w', 'o', 'w' }
};
var word = "wow";// "access";

var result = new DP.WordOnGrid().Find(input, word);

var count = result.Count;
for (int init = 0; init < count; init++)
   Console.WriteLine(result.Pop());


//var input = new[] { 10, 20, 30, 40, 50 }; // output: 38000 // new[] { 2, 1, 3, 4 }; // output: 20
//var result = new _48_PartitionDB_MCM().FindMinimumOperation(input);
//Console.WriteLine(result);


//var stickIndexToCut = new[] { 5, 6, 1, 4, 2 }; //output:22 // new[] { 1, 3, 4, 5 }; // output: 16
//var lengthOfTheStick = 9; // 7;
//var result = new _50_PartitionDP_MinimumCostToCutStick().Find(stickIndexToCut, lengthOfTheStick);
//Console.WriteLine(result);



//var input = new[] { 3,1,5,8 }; // output: 167
//var result = new _51_PartitionDP_BurstingBalloons().FindMaxCoin(input);
//Console.WriteLine(result);


//var booleanExpressionInput =  new[] { 'T', '|', 'T', '&', 'F', '^', 'T' }; // output: 4 ((T|T)&(F^T)), (T|(T&(F^T))), (((T|T)&F)^T) and (T|((T&F)^T)). //new[] { 'T', '^', 'F', '|', 'F' }; //output: 2 ((T^F)|F) and (T^(F|F)).
//var result = new _52_PartitionDP_EvaluateBooleanExpressionToTrue().Find(booleanExpressionInput);
//Console.WriteLine(result);


//var inputString = new[] { 'a', 'a', 'c', 'c', 'b' }; // output: 2 // new[] { 'a', 'b', 'a', 'b', 'a' }; // output 0
//var result = new _53_PartitionDP_PalindromePartition2().FindMinimumPartition(inputString);
//Console.WriteLine(result);


/*var input = new[] { 1, 4, 1, 5, 7, 3, 6, 1, 9, 9, 3 }; // output: 83 // new[] { 1, 15, 7, 9, 2, 5, 10 }; // output: 84
var kPartition = 4; // 3;
var result = new _54_PartitionDP_PartitionArrayForMaximumSum().FindMaximumSum(input, kPartition);
Console.WriteLine(result);*/