﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DP
{
    internal class _32_NumberOfDistinctSubsequences
    {
        string str1;

        string str2;

        int[,] memo;

        public int Find(string str1, string str2)
        {
            this.str1 = str1;
            this.str2 = str2;
            this.memo = new int[this.str1.Length + 1, this.str2.Length + 1];

            for (int row = 0; row < this.str1.Length + 1; row++)
            {
                for (int column = 0; column < this.str2.Length + 1; column++)
                {
                    memo[row, column] = -1;
                }
            }

            return FindUsingSpaceOptimization();
            return FindUsingTabulation();
            return FindUsingMemo(this.str1.Length, this.str2.Length);
            return FindRecursively(this.str1.Length, this.str2.Length); // 1D indexing
        }

        private int FindRecursively(int index1, int index2)
        {
            if (index2 == 0) return 1; // Index2 condition should be first because when index1 and index2 reaches 0 then it should be considered as match found
            if (index1 == 0) return 0;


            if (this.str1[index1 - 1] == this.str2[index2 - 1])
                return FindRecursively(index1 - 1, index2 - 1) + FindRecursively(index1 - 1, index2);
            else
                return FindRecursively(index1 - 1, index2);
        }

        private int FindUsingMemo(int index1, int index2)
        {
            if (index2 == 0) return 1;
            if (index1 == 0) return 0;

            if (this.memo[index1, index2] != -1) return this.memo[index1, index2];

            if (this.str1[index1 - 1] == this.str2[index2 - 1])
            {
                var result = FindUsingMemo(index1 - 1, index2 - 1) + FindUsingMemo(index1 - 1, index2);
                this.memo[index1, index2] = result;
                return result;
            }
            else
            {
                var result = FindUsingMemo(index1 - 1, index2);
                this.memo[index1, index2] = result;
                return result;
            }
        }

        private int FindUsingTabulation()
        {
            var dp = new int[this.str1.Length + 1, this.str2.Length + 1];

            for (int ind2 = 0; ind2 <= this.str2.Length; ind2++) // Index 1 ==0
            {
                dp[0, ind2] = 0;
            }

            for (int ind1 = 0; ind1 <= this.str1.Length; ind1++) // Index 2 == 0 // This should be second otherwise the above for loop will override 0,0 cell
            {
                dp[ind1, 0] = 1;
            }

            for (int ind1 = 1; ind1 <= this.str1.Length; ind1++)
            {
                for (int ind2 = 1; ind2 <= this.str2.Length; ind2++)
                {
                    if (this.str1[ind1 - 1] == this.str2[ind2 - 1])
                        dp[ind1, ind2] = dp[ind1 - 1, ind2 - 1] + dp[ind1 - 1, ind2];
                    else
                        dp[ind1, ind2] = dp[ind1 - 1, ind2];
                }
            }

            return dp[this.str1.Length, this.str2.Length];
        }


        private int FindUsingSpaceOptimization()
        {
            var prev = new int[this.str2.Length + 1];

            for (int ind2 = 0; ind2 <= this.str2.Length; ind2++) // Index 1 ==0
            {
                prev[ind2] = 0;
            }

            prev[0] = 1; // Index2==0


            for (int ind1 = 1; ind1 <= this.str1.Length; ind1++)
            {
                var curr = new int[this.str2.Length + 1];
                curr[0] = 1;
                for (int ind2 = 1; ind2 <= this.str2.Length; ind2++)
                {
                    if (this.str1[ind1 - 1] == this.str2[ind2 - 1])
                        curr[ind2] = prev[ind2 - 1] + prev[ind2];
                    else
                        curr[ind2] = prev[ind2];
                }
                prev = curr;
            }

            return prev[this.str2.Length];
        }
    }
}
