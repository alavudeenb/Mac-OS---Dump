﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DP
{
    internal class _34_Wildcard_Matching
    {
        string str1;

        string str2;

        int[,] memo;

        public bool Find(string str1, string str2)
        {
            this.str1 = str1;
            this.str2 = str2;
            this.memo = new int[this.str1.Length + 1, this.str2.Length + 1];
            for (int row = 0; row <= this.str1.Length; row++)
                for (int column = 0; column <= this.str2.Length; column++)
                    this.memo[row, column] = -1;

            return this.FindUsingTabulation();
            return this.FindUsingMemo(this.str1.Length, this.str2.Length);
            return this.FindRecursively(this.str1.Length, this.str2.Length);
            return this.FindRecursivelyWith_n_1(this.str1.Length - 1, this.str2.Length - 1);
        }

        private bool FindRecursively(int index1, int index2) // O(2^n)
        {
            if (index1 == 0 && index2 == 0) // str1 & str2 both are exhausted
                return true;

            if (index2 == 0) // str2 is exhausted but str1 is NOT exhausted
            {
                while (index1 > 0)
                {
                    if (str1[index1 - 1] != '*') // If str1 is NOT having * then false
                    {
                        return false;
                    }
                    index1--;
                }
                return true; // if str1 is only having * becuase * means 1 or more characters
            }

            if ((index1 == 0 && index2 > 0)) // str1 is exhausted but str2 is NOT exhausted
                return false;

            var left = false;
            var right = false;

            if (this.str1[index1 - 1] == this.str2[index2 - 1] || this.str1[index1 - 1] == '?')
                left = FindRecursively(index1 - 1, index2 - 1);
            else if (this.str1[index1 - 1] == '*')
                right = FindRecursively(index1 - 1, index2) || FindRecursively(index1, index2 - 1);

            return left || right;
        }

        private bool FindUsingMemo(int index1, int index2) // O(2^n)
        {
            if (index1 == 0 && index2 == 0) // str1 & str2 both are exhausted
                return true;

            if (index2 == 0) // str2 is exhausted but str1 is NOT exhausted
            {
                while (index1 > 0)
                {
                    if (this.str1[index1 - 1] != '*') // If str1 is NOT having * then false
                    {
                        return false;
                    }
                    index1--;
                }
                return true; // if str1 is only having * becuase * means 1 or more characters
            }

            if ((index1 == 0 && index2 > 0)) // str1 is exhausted but str2 is NOT exhausted
                return false;

            if (this.memo[index1, index2] != -1) return Convert.ToBoolean(this.memo[index1, index2]);

            var left = false;
            var right = false;

            if (this.str1[index1 - 1] == this.str2[index2 - 1] || this.str1[index1 - 1] == '?')
                left = FindUsingMemo(index1 - 1, index2 - 1);
            else if (this.str1[index1 - 1] == '*')
                right = FindUsingMemo(index1 - 1, index2) || FindUsingMemo(index1, index2 - 1);

            var result = left || right;
            this.memo[index1, index2] = Convert.ToInt32(result);
            return result;
        }


        private bool FindUsingTabulation()
        {
            var dp = new bool[this.str1.Length + 1, this.str2.Length + 1];

            for (int ind2 = 1; ind2 <= this.str2.Length; ind2++)
                dp[0, ind2] = false;

            for (int ind1 = 1; ind1 <= this.str1.Length; ind1++)
            {
                var tempInd1 = ind1;
                bool flag = true;
                while (tempInd1 > 0)
                {
                    if (this.str1[ind1 - 1] != '*')
                    {
                        flag = false;
                        break;
                    }
                    tempInd1--;
                }
                dp[ind1, 0] = flag;
            }

            dp[0, 0] = true;

            for (int ind1 = 1; ind1 <= this.str1.Length; ind1++)
            {
                for (int ind2 = 1; ind2 <= this.str2.Length; ind2++)
                {
                    var left = false;
                    var right = false;

                    if (this.str1[ind1 - 1] == this.str2[ind2 - 1] || this.str1[ind1 - 1] == '?')
                        left = FindUsingMemo(ind1 - 1, ind2 - 1);
                    else if (this.str1[ind1 - 1] == '*')
                        right = FindUsingMemo(ind1 - 1, ind2) || FindUsingMemo(ind1, ind2 - 1);

                    var result = left || right;
                    dp[ind1, ind2] = result;
                }
            }

            return dp[this.str1.Length, this.str2.Length];
        }




        private bool FindRecursivelyWith_n_1(int index1, int index2) // O(2^n)
        {
            if (index1 < 0 && index2 < 0) // str1 & str2 both are exhausted
                return true;

            if (index2 < 0) // str2 is exhausted but str1 is NOT exhausted
            {
                while (index1 >= 0)
                {
                    if (str1[index1] != '*') // If str1 is NOT having * then false
                    {
                        return false;
                    }
                    index1--;
                }
                return true; // if str1 is only having * becuase * means 1 or more characters
            }

            if ((index1 < 0 && index2 >= 0)) // str1 is exhausted but str2 is NOT exhausted
                return false;

            var left = false;
            var right = false;

            if (this.str1[index1] == this.str2[index2] || this.str1[index1] == '?')
                left = FindRecursively(index1 - 1, index2 - 1);
            else if (this.str1[index1] == '*')
                right = FindRecursively(index1 - 1, index2) || FindRecursively(index1, index2 - 1);

            return left || right;
        }

        private bool FindRecursively_Alternative1(int index1, int index2) // O(n+m)
        {
            if (index1 == 0 && this.str1[index1] == '*')
                return true;

            if (index1 < 0 && index2 < 0)
                return true;

            if ((index1 < 0 && index2 >= 0) || (index1 >= 0 && index2 < 0))
                return false;

            var left = false;
            var right = false;

            if (this.str1[index1] == this.str2[index2] || this.str1[index1] == '?')
                left = FindRecursively_Alternative1(index1 - 1, index2 - 1);
            else
            {
                if (this.str1[index1] == '*' && this.str1[index1 - 1] == this.str2[index2 - 1])
                    right = FindRecursively_Alternative1(index1 - 1, index2 - 1);
                else if (this.str1[index1] == '*')
                    right = FindRecursively_Alternative1(index1, index2 - 1);
                else
                    return false;
            }

            return left || right;
        }

        private bool FindRecursively_Alternative2(int index1, int index2) // O(n+m)
        {
            if (index1 == 0 && this.str1[index1] == '*')
                return true;

            if (index1 < 0 && index2 < 0) // str1 & str2 both are exhausted
                return true;

            if (index2 < 0) // str2 is exhausted but str1 is NOT exhausted
            {
                while (index1 >= 0)
                {
                    if (str1[index1] != '*') // If str1 is NOT having * then false
                    {
                        return false;
                    }
                    index1--;
                }
                return true; // if str1 is only having * becuase * means 1 or more characters
            }

            if ((index1 < 0 && index2 >= 0)) // str1 is exhausted but str2 is NOT exhausted
                return false;

            var left = false;
            var right = false;

            if (this.str1[index1] == this.str2[index2] || this.str1[index1] == '?')
                left = FindRecursively_Alternative2(index1 - 1, index2 - 1);
            else
            {
                if (this.str1[index1] == '*')
                {
                    if (this.str1[index1 - 1] == this.str2[index2 - 1])
                        right = FindRecursively_Alternative2(index1 - 1, index2 - 1);
                    else
                        right = FindRecursively_Alternative2(index1, index2 - 1);
                }
            }

            return left || right;
        }
    }
}
