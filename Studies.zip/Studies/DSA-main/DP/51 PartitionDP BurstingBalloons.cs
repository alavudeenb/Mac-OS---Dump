﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DP
{
    internal class _51_PartitionDP_BurstingBalloons
    {
        int[] updatedBaloonsInput;

        int[,] memo;

        int[,] dp;

        public int FindMaxCoin(int[] input)
        {
            this.updatedBaloonsInput = new int[input.Length + 2];
            this.memo = new int[input.Length + 2, input.Length + 2];
            this.dp = new int[input.Length + 2, input.Length + 2];

            for (int row = 0; row < this.memo.GetLength(0); row++)
                for (int column = 0; column < this.memo.GetLength(1); column++)
                    this.memo[row, column] = -1;

            this.updatedBaloonsInput[0] = 1;
            this.updatedBaloonsInput[this.updatedBaloonsInput.Length - 1] = 1;

            for (int ind = 0; ind < input.Length; ind++)
                this.updatedBaloonsInput[ind + 1] = input[ind];

            return FindRecursivelyUsingTabulation();
            return FindRecursivelyUsingMemo(1, this.updatedBaloonsInput.Length - 2);
            return FindRecursively(1, this.updatedBaloonsInput.Length - 2);
        }

        /* This problem goes like this. For input [3,1,5,8], add 1 in the begining and 1 in the end. [1,3,1,5,8,1]
         *                                                                            Index (Indices) 0 1 2 3 4 5
         * For each element in the array, Let's say it is the last element to be bursted.
         * For example if 5 is the last element then 5->3->1->8 or 5->1->3->8
         * So 5 will be the last burst. 3 will be second last so it will be there for 1 and 8.
         * 1 will be third last so it will be there for only 8. 
         * In other case 5 will be the last burst then 1 will be second last then 3 will be thrid last and very first will be 8.
         * 
         * Note: For loop is checking each/all element is bursted at a particular level.
         * 
         * 
         */

        private int FindRecursively(int i, int j) // O(Exponential) => O(3^n)
        {
            if (i > j) return 0;

            var max = Int32.MinValue;
            for (int ind = i; ind <= j; ind++)
            {
                var localMax = this.updatedBaloonsInput[i - 1] * this.updatedBaloonsInput[ind] * this.updatedBaloonsInput[j + 1] +
                               FindRecursively(i, ind - 1) +
                               FindRecursively(ind + 1, j);
                max = Math.Max(max, localMax);
            }

            return max;
        }


        private int FindRecursivelyUsingMemo(int i, int j) // O(n3) space: stack O(n2)
        {
            if (i > j) return 0;

            if (this.memo[i, j] != -1) return this.memo[i, j];

            var max = Int32.MinValue;
            for (int ind = i; ind <= j; ind++)
            {
                var localMax = this.updatedBaloonsInput[i - 1] * this.updatedBaloonsInput[ind] * this.updatedBaloonsInput[j + 1] +
                               FindRecursively(i, ind - 1) +
                               FindRecursively(ind + 1, j);
                max = Math.Max(max, localMax);
            }

            this.memo[i, j] = max;
            return max;
        }

        private int FindRecursivelyUsingTabulation() // O(n3)
        {
            for (int i = 0; i < this.dp.GetLength(0); i++)
            {
                for (int j = 0; j < this.dp.GetLength(1); j++)
                {
                    if (i > j)
                        this.dp[i, j] = 0;
                }
            }

            for (int i = this.updatedBaloonsInput.Length - 2; i >= 1; i--)
            {
                for (int j = i; j <= this.updatedBaloonsInput.Length - 2; j++)
                {
                    var max = Int32.MinValue;
                    for (int ind = i; ind <= j; ind++)
                    {
                        var localMax = this.updatedBaloonsInput[i - 1] * this.updatedBaloonsInput[ind] * this.updatedBaloonsInput[j + 1] +
                                       dp[i, ind - 1] +
                                       dp[ind + 1, j];
                        max = Math.Max(max, localMax);
                    }
                    dp[i, j] = max;
                }
            }
            return dp[1, this.updatedBaloonsInput.Length - 2];
        }
    }
}
