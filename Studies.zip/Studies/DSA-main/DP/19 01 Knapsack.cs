﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace DP
{
    internal class DP19_01_Knapsack
    {
        int[] weights;

        int[] values;

        int[,] memo;

        int[,] dp;

        int n;

        int bagWght;

        public int Find(int[] weights, int[] values, int bagWeight)
        {
            this.weights = weights;
            this.values = values;

            this.n = this.weights.Length;
            this.bagWght = bagWeight + 1;
            this.memo = new int[n, this.bagWght];
            this.dp = new int[n, this.bagWght];

            return FindUsingSpaceOptimizationWithOnlyOne1D(bagWeight);
            return FindUsingSpaceOptimization(bagWeight);
            return FindUsingTabulation(bagWeight);
            return FindUsingMemo(n - 1, bagWeight);
            return FindRecursively(n - 1, bagWeight);
        }

        private int FindRecursively(int index, int bagWeight) // O(2^n)
        {
            if (bagWeight == 0) return 0;

            if (index == 0)
            {
                if (bagWeight >= this.weights[index]) return this.values[index];
                else return 0;
            }

            var take = 0;
            if (bagWeight >= this.weights[index])
                take = values[index] + FindRecursively(index - 1, bagWeight - this.weights[index]);

            var notTake = 0 + FindRecursively(index - 1, bagWeight);

            return Math.Max(take, notTake);
        }
        private int FindUsingMemo(int index, int bagWeight) // O(n*bagWeight) // space stack O(n) memo O(n*bagWeight)
        {
            if (bagWeight == 0) return 0;

            if (index == 0)
            {
                if (bagWeight >= this.weights[index]) return this.values[index];
                else return 0;
            }

            if (this.memo[index, bagWeight] != 0) return this.memo[index, bagWeight];

            var take = 0;
            if (bagWeight >= this.weights[index])
                take = values[index] + FindUsingMemo(index - 1, bagWeight - this.weights[index]);

            var notTake = 0 + FindUsingMemo(index - 1, bagWeight);

            var result = Math.Max(take, notTake);
            this.memo[index, bagWeight] = result;

            return result;
        }

        private int FindUsingTabulation(int bagWeight) // O(n*bagWeight) // space dp O(n*bagWeight)
        {
            for (int ind = 0; ind < this.n; ind++)
                dp[ind, 0] = 0;

            for (int _bagWeight = 1; _bagWeight < this.bagWght; _bagWeight++)
            {
                if (_bagWeight >= this.weights[0])
                    dp[0, _bagWeight] = this.values[0];
                else
                    dp[0, _bagWeight] = 0;
            }

            for (int ind = 1; ind < n; ind++)
            {
                for (int _bagWeight = 1; _bagWeight < this.bagWght; _bagWeight++)
                {
                    var take = 0;
                    if (_bagWeight >= this.weights[ind])
                        take = values[ind] + dp[ind - 1, _bagWeight - this.weights[ind]];

                    var notTake = 0 + dp[ind - 1, _bagWeight];

                    dp[ind, _bagWeight] = Math.Max(take, notTake);
                }
            }
            return dp[this.n - 1, bagWeight];
        }

        private int FindUsingSpaceOptimization(int bagWeight) //O(n*bagWeight) //space O(bagWght) + O(bagWght)
        {
            var prev = new int[this.bagWght];
            prev[0] = 0;

            for (int _bagWeight = 0; _bagWeight < this.bagWght; _bagWeight++)
            {
                if (_bagWeight >= this.weights[0])
                    prev[_bagWeight] = this.values[0];
                else
                    prev[_bagWeight] = 0;
            }

            for (int ind = 1; ind < n; ind++)
            {
                var curr = new int[this.bagWght];
                curr[0] = 0;
                for (int _bagWeight = 1; _bagWeight < this.bagWght; _bagWeight++)
                {
                    var take = 0;
                    if (_bagWeight >= this.weights[ind])
                        take = values[ind] + prev[_bagWeight - this.weights[ind]];

                    var notTake = 0 + prev[_bagWeight];

                    curr[_bagWeight] = Math.Max(take, notTake);
                }
                prev = curr;
            }
            return prev[bagWeight];
        }

        private int FindUsingSpaceOptimizationWithOnlyOne1D(int bagWeight) //O(n*bagWeight) //space O(bagWght)
        {
            var prev = new int[this.bagWght];
            prev[0] = 0;

            for (int _bagWeight = 0; _bagWeight < this.bagWght; _bagWeight++)
            {
                if (_bagWeight >= this.weights[0])
                    prev[_bagWeight] = this.values[0];
                else
                    prev[_bagWeight] = 0;
            }

            for (int ind = 1; ind < n; ind++)
            {
                for (int _bagWeight = this.bagWght-1; _bagWeight >=0; _bagWeight--)
                {
                    var take = 0;
                    if (_bagWeight >= this.weights[ind])
                        take = values[ind] + prev[_bagWeight - this.weights[ind]];

                    var notTake = 0 + prev[_bagWeight];

                    prev[_bagWeight] = Math.Max(take, notTake);
                }
            }
            return prev[bagWeight];
        }

    }
}
