﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DP
{
    internal class _29_MinimumInsertionToMakeStringPalindrome
    {
        string str1;

        string str2;

        public int Find(string str)
        {
            this.str1 = str;
            this.str2 = new string(this.str1.Reverse().ToArray());
            return FindUsingTabulation();
        }

        private int FindUsingTabulation()
        {
            var dp = new int[this.str1.Length + 1, this.str2.Length + 1];

            for (int ind1 = 0; ind1 <= this.str1.Length; ind1++)
                dp[ind1, 0] = 0;

            for (int ind2 = 0; ind2 <= this.str2.Length; ind2++)
                dp[0, ind2] = 0;

            for (int ind1 = 1; ind1 <= this.str1.Length; ind1++)
            {
                for (int ind2 = 1; ind2 <= this.str2.Length; ind2++)
                {
                    if (this.str1[ind1 - 1] == this.str2[ind2 - 1])
                        dp[ind1, ind2] = 1 + dp[ind1 - 1, ind2 - 1];
                    else
                        dp[ind1, ind2] = 0 + Math.Max(dp[ind1 - 1, ind2], dp[ind1, ind2 - 1]);
                }
            }

            var longestCommonSubsequence = dp[this.str1.Length, this.str2.Length];
            var stringLength = this.str1.Length;

            return stringLength - longestCommonSubsequence;
        }
    }
}
