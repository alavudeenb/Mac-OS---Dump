﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DP
{
    internal class _24_RodCutting
    {
        int[] rodSize;

        int[] rodValues;

        int n;

        int k;

        int[,] memo;

        int[,] dp;

        public int Find(int[] rodSize, int[] rodValues, int N)
        {
            this.rodSize = rodSize;
            this.rodValues = rodValues;
            this.n = this.rodSize.Length;
            this.k = N + 1;
            this.memo = new int[this.n, this.k];
            this.dp = new int[this.n, this.k];
            for (int row = 0; row < this.n; row++)
                for (int column = 0; column < this.k; column++)
                    this.memo[row, column] = -1;

            return FindUsingSpaceOptimization(N);
            return FindUsingTabulation(N);
            return FindUsingMemo(this.n - 1, N);
            return FindRecursively(this.n - 1, N);

        }

        private int FindRecursively(int index, int N)
        {
            if (index == 0)
            {
                if (N % this.rodSize[index] == 0)
                    return (N / this.rodSize[index]) * this.rodValues[index];
                else
                    return 0;
            }

            var take = 0;
            if (this.rodSize[index] <= N)
                take = this.rodValues[index] + FindRecursively(index, N - this.rodSize[index]);

            var notTake = 0 + FindRecursively(index - 1, N);

            return Math.Max(take, notTake);
        }
        private int FindUsingMemo(int index, int N)
        {
            if (index == 0)
            {
                if (N % this.rodSize[index] == 0)
                    return (N / this.rodSize[index]) * this.rodValues[index];
                else
                    return 0;
            }

            if (this.memo[index, N] != -1) return this.memo[index, N];

            var take = 0;
            if (this.rodSize[index] <= N)
                take = this.rodValues[index] + FindUsingMemo(index, N - this.rodSize[index]);

            var notTake = 0 + FindUsingMemo(index - 1, N);

            var result = Math.Max(take, notTake);

            this.memo[index, N] = result;
            return result;
        }

        private int FindUsingTabulation(int N)
        {
            for (int _k = 0; _k < this.k; _k++)
            {
                if (_k % this.rodSize[0] == 0)
                    dp[0, _k] = (_k / this.rodSize[0]) * this.rodValues[0];
                else
                    dp[0, _k] = 0;
            }

            for (int ind = 1; ind < this.n; ind++)
            {
                for (int _k = 0; _k < this.k; _k++)
                {
                    var take = 0;
                    if (this.rodSize[ind] <= _k)
                        take = this.rodValues[ind] + dp[ind, _k - this.rodSize[ind]];

                    var notTake = 0 + dp[ind - 1, _k];

                    var result = Math.Max(take, notTake);

                    this.dp[ind, _k] = result;
                }
            }
            return this.dp[this.n - 1, N];
        }

        private int FindUsingSpaceOptimization(int N)
        {
            var prev = new int[this.k];

            for (int _k = 0; _k < this.k; _k++)
            {
                if (_k % this.rodSize[0] == 0)
                    prev[_k] = (_k / this.rodSize[0]) * this.rodValues[0];
                else
                    prev[_k] = 0;
            }

            for (int ind = 1; ind < this.n; ind++)
            {
                var curr = new int[this.k];
                for (int _k = 0; _k < this.k; _k++)
                {
                    var take = 0;
                    if (this.rodSize[ind] <= _k)
                        take = this.rodValues[ind] + curr[_k - this.rodSize[ind]];

                    var notTake = 0 + prev[_k];

                    var result = Math.Max(take, notTake);

                    curr[_k] = result;
                }
                prev = curr;
            }
            return prev[N];
        }
    }
}
