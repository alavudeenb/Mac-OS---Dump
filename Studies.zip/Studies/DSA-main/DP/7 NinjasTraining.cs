﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DP
{
    internal class NinjasTraining
    {
        Dictionary<int, Dictionary<int, int>> memo;
        int[,] dp;

        public int Find(int[,] input)
        {
            memo = new Dictionary<int, Dictionary<int, int>>();
            dp = new int[input.GetLength(0), input.GetLength(1)];

            return FindWithSpaceOptimization(input);
            return FindWithDP(input);
            return FindWithMemo(3, -1, input);
            return FindRecursively(3, -1, input);
        }

        private int FindRecursively(int day, int lastUsed, int[,] input) // O((m)^n)
        {
            if (day == 0)
            {
                int max = 0;
                for (int column = 0; column < input.GetLength(1); column++)
                {
                    if (column != lastUsed)
                    {
                        max = Math.Max(max, input[day, column]);
                    }
                }
                return max;
            }


            int localMax = 0;
            for (int column = 0; column < input.GetLength(1); column++)
            {
                if (column != lastUsed)
                {
                    var result = input[day, column] + FindRecursively(day - 1, column, input);
                    localMax = Math.Max(localMax, result);
                }
            }

            return localMax;
        }

        private int FindWithMemo(int day, int lastUsed, int[,] input) // O(n*m*m) => O(n*m2) //Space: O(n*m) + O(n*m)
        {
            if (day == 0)
            {
                int max = 0;
                for (int column = 0; column < input.GetLength(1); column++)
                {
                    if (column != lastUsed)
                        max = Math.Max(max, input[day, column]);
                }
                return max;
            }

            Dictionary<int, int> innerDictionary = new Dictionary<int, int>();
            int sum;
            if (memo.TryGetValue(day, out innerDictionary) && innerDictionary.TryGetValue(lastUsed, out sum))
            {
                return sum;
            }

            int localMax = 0;
            for (int column = 0; column < input.GetLength(1); column++)
            {
                if (column != lastUsed)
                {
                    var result = input[day, column] + FindWithMemo(day - 1, column, input);
                    localMax = Math.Max(localMax, result);
                }
            }

            innerDictionary = new Dictionary<int, int>();
            if (memo.TryGetValue(day, out innerDictionary))
            {
                innerDictionary[lastUsed] = localMax;
            }
            else
            {
                memo.Add(day, new Dictionary<int, int>() { { lastUsed, localMax } });
            }

            return localMax;
        }

        private int FindWithDP(int[,] input) // O(n*m*m) => O(n*m2) //Space: O(n*m)
        {
            for (int column = 0; column < input.GetLength(1); column++)
            {
                dp[0, column] = input[0, column];
            }


            int max = 0;
            for (int row = 1; row < input.GetLength(0); row++)
            {
                for (int column = 0; column < input.GetLength(1); column++)
                {
                    int localMax = 0;
                    for (int previousColumn = 0; previousColumn < input.GetLength(1); previousColumn++)
                    {
                        if (column != previousColumn)
                            localMax = Math.Max(localMax, input[row, column] + dp[row - 1, previousColumn]);
                    }
                    dp[row, column] = localMax;

                    if (row == input.GetLength(0) - 1)
                        max = Math.Max(max, localMax);
                }
            }

            return max;
        }

        private int FindWithSpaceOptimization(int[,] input) // O(n*m*m) => O(n*m2) //Space: 2O(4) => O(4)
        {
            var prev = new int[input.GetLength(1)];

            for (int column = 0; column < input.GetLength(1); column++)
            {
                prev[column] = input[0, column];
            }

            int max = 0;
            for (int row = 1; row < input.GetLength(0); row++)
            {
                var tempPreviousColumn = new int[input.GetLength(1)];
                for (int column = 0; column < input.GetLength(1); column++)
                {
                    int localMax = 0;
                    for (int previousColumn = 0; previousColumn < input.GetLength(1); previousColumn++)
                    {
                        if (column != previousColumn)
                        {
                            localMax = Math.Max(localMax, input[row, column] + prev[previousColumn]);
                        }
                    }
                    tempPreviousColumn[column] = localMax;

                    if (row == input.GetLength(0) - 1)
                        max = Math.Max(max, localMax);
                }
                prev = tempPreviousColumn;
            }

            return max;
        }
    }
}
