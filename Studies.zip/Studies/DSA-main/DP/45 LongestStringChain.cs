﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DP
{
    internal class _45_LongestStringChain
    {
        public string[] Find(string[] input)
        {
            var minHeap = new PriorityQueue<string, int>();

            for (int init = 0; init < input.Length; init++)
            {
                minHeap.Enqueue(input[init], input[init].Length);
            }

            var count = minHeap.Count;
            for (int init = 0; init < count; init++)
            {
                input[init] = minHeap.Dequeue();
            }

            var dp = new int[input.Length];
            var backTracking = new int[input.Length];

            for (int ind = 0; ind < input.Length; ind++)
            {
                dp[ind] = 1;
                backTracking[ind] = ind;
            }

            int maxLIS = 0;
            int maxLISIndex = 0;
            for (int ind = 0; ind < input.Length; ind++)
            {
                for (int previousIndex = 0; previousIndex < ind; previousIndex++)
                {
                    if (input[ind].Length == input[previousIndex].Length + 1 &&
                        DoesPreviousIndexMatch(input[previousIndex], input[ind]) == true &&
                        dp[ind] < 1 + dp[previousIndex])
                    {
                        dp[ind] = 1 + dp[previousIndex];
                        backTracking[ind] = previousIndex;
                    }
                }

                if (maxLIS < dp[ind])
                {
                    maxLIS = dp[ind];
                    maxLISIndex = ind;
                }
            }

            var output = new List<string>();
            output.Add(input[maxLISIndex]);

            while (maxLISIndex != backTracking[maxLISIndex])
            {
                maxLISIndex = backTracking[maxLISIndex];
                output.Add(input[maxLISIndex]);
            }

            return output.ToArray();
        }

        private bool DoesPreviousIndexMatch(string previousString, string currentString)
        {
            foreach (var item in previousString)
            {
                if (currentString.Contains(item) == false)
                    return false;
            }

            return true;
        }
    }
}
