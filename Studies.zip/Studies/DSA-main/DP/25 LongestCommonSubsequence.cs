﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DP
{
    internal class _25_LongestCommonSubsequence
    {
        string str1;

        string str2;

        int[,] memo;

        int[,] dp;

        int str1LengthPlusOne;

        int str2LengthPlusOne;

        public int Find(string str1, string str2)
        {
            this.str1 = str1;
            this.str2 = str2;
            this.str1LengthPlusOne = this.str1.Length + 1;
            this.str2LengthPlusOne = this.str2.Length + 1;
            this.memo = new int[this.str1LengthPlusOne, this.str2LengthPlusOne];
            this.dp = new int[this.str1LengthPlusOne, this.str2LengthPlusOne];

            for (int row = 0; row < this.str1LengthPlusOne; row++)
                for (int column = 0; column < this.str2LengthPlusOne; column++)
                    this.memo[row, column] = -1;

            return FindRecursivelyUsingRightShitAndSpaceOptimization();
            return FindRecursivelyUsingRightShitAndTabulation();
            return FindRecursivelyUsingRightShitAndMemo(this.str1.Length, this.str2.Length);
            return FindRecursivelyUsingRightShit(this.str1.Length, this.str2.Length);
            return FindRecursively(this.str1.Length - 1, this.str2.Length - 1);
        }

        private int FindRecursively(int index1, int index2) // O(2^n) * O(2^m)
        {
            if (index1 < 0 || index2 < 0)
            {
                return 0;
            }

            if (this.str1[index1] == this.str2[index2])
                return 1 + FindRecursively(index1 - 1, index2 - 1);

            return 0 + Math.Max(FindRecursively(index1 - 1, index2), FindRecursively(index1, index2 - 1));
        }

        private int FindRecursivelyUsingRightShit(int index1, int index2) // O(2^n) * O(2^m)
        {
            if (index1 == 0 || index2 == 0)
            {
                return 0;
            }

            if (this.str1[index1 - 1] == this.str2[index2 - 1]) // if index1 == n we are checking n-1. It is called right shift
                return 1 + FindRecursivelyUsingRightShit(index1 - 1, index2 - 1);

            return 0 + Math.Max(FindRecursivelyUsingRightShit(index1 - 1, index2), FindRecursivelyUsingRightShit(index1, index2 - 1));
        }

        private int FindRecursivelyUsingRightShitAndMemo(int index1, int index2) // O(n*m) // space stack O(n+m) memo O(n*m)
        {
            if (index1 == 0 || index2 == 0)
                return 0;

            if (this.memo[index1, index2] != -1)
                return this.memo[index1, index2];

            if (this.str1[index1 - 1] == this.str2[index2 - 1]) // if index1 == n we are checking n-1. It is called right shift
            {
                var result = 1 + FindRecursivelyUsingRightShit(index1 - 1, index2 - 1);
                this.memo[index1, index2] = result;
                return result;
            }

            var _result = 0 + Math.Max(FindRecursivelyUsingRightShit(index1 - 1, index2), FindRecursivelyUsingRightShit(index1, index2 - 1));
            this.memo[index1, index2] = _result;
            return _result;
        }

        private int FindRecursivelyUsingRightShitAndTabulation() // O(n*m) // space dp O(n*m)
        {
            for (int ind2 = 0; ind2 < this.str2LengthPlusOne; ind2++) // Index1 == 0
                dp[0, ind2] = 0;

            for (int ind1 = 0; ind1 < this.str1LengthPlusOne; ind1++) // Index2 == 0
                dp[ind1, 0] = 0;

            for (int ind1 = 1; ind1 < this.str1LengthPlusOne; ind1++)
            {
                for (int ind2 = 1; ind2 < this.str2LengthPlusOne; ind2++)
                {
                    if (this.str1[ind1 - 1] == this.str2[ind2 - 1]) // if index1 == n we are checking n-1. It is called right shift
                    {
                        var result = 1 + dp[ind1 - 1, ind2 - 1];
                        dp[ind1, ind2] = result;
                    }
                    else
                    {
                        var _result = 0 + Math.Max(dp[ind1 - 1, ind2], dp[ind1, ind2 - 1]);
                        dp[ind1, ind2] = _result;
                    }
                }
            }

            return dp[this.str1.Length, this.str2.Length];
        }

        private int FindRecursivelyUsingRightShitAndSpaceOptimization() // O(n*m) // space O(m)
        {
            var prev = new int[this.str2LengthPlusOne];
            for (int ind2 = 0; ind2 < this.str2LengthPlusOne; ind2++) // Index1 == 0
                prev[ind2] = 0;

            prev[0] = 0; // Index2 == 0. The reason for no for loop is we will be setting it in curr array while initializing it

            for (int ind1 = 1; ind1 < this.str1LengthPlusOne; ind1++)
            {
                var curr = new int[this.str2LengthPlusOne];
                curr[0] = 0;
                for (int ind2 = 1; ind2 < this.str2LengthPlusOne; ind2++)
                {
                    if (this.str1[ind1 - 1] == this.str2[ind2 - 1]) // if index1 == n we are checking n-1. It is called right shift
                    {
                        var result = 1 + prev[ind2 - 1];
                        curr[ind2] = result;
                    }
                    else
                    {
                        var _result = 0 + Math.Max(prev[ind2], curr[ind2 - 1]);
                        curr[ind2] = _result;
                    }
                }
                prev = curr;
            }

            return prev[this.str2.Length];
        }
    }
}
