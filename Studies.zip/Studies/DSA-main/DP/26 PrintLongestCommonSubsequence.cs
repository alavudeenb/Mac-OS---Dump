﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DP
{
    internal class _26_PrintLongestCommonSubsequence
    {
        string str1;

        string str2;

        private StringBuilder stringBuilder;

        int str1LengthWithPlusOne;

        int str2LengthWithPlusOne;

        int[,] dp;

        public char[] Find(string str1, string str2)
        {
            this.str1 = str1;
            this.str2 = str2;
            this.str1LengthWithPlusOne = this.str1.Length + 1;
            this.str2LengthWithPlusOne = this.str2.Length + 1;
            this.stringBuilder = new StringBuilder();
            this.dp = new int[this.str1LengthWithPlusOne, this.str2LengthWithPlusOne];

            return this.FindUsingTabulation();
        }

        private char[] FindUsingTabulation()
        {
            for (int ind1 = 0; ind1 < this.str1LengthWithPlusOne; ind1++)
                dp[ind1, 0] = 0;

            for (int ind2 = 0; ind2 < this.str2LengthWithPlusOne; ind2++)
                dp[0, ind2] = 0;

            for (int ind1 = 1; ind1 < this.str1LengthWithPlusOne; ind1++) // O(n*m)
            {
                for (int ind2 = 1; ind2 < this.str2LengthWithPlusOne; ind2++)
                {
                    if (this.str1[ind1 - 1] == this.str2[ind2 - 1])
                        dp[ind1, ind2] = 1 + dp[ind1 - 1, ind2 - 1];
                    else
                        dp[ind1, ind2] = 0 + Math.Max(dp[ind1 - 1, ind2], dp[ind1, ind2 - 1]);
                }
            }


            int index1 = this.str1.Length;
            int index2 = this.str2.Length;

            int outputIndex = dp[index1, index2];
            char[] output = new char[outputIndex];

            while (index1 > 0 && index2 > 0) // O(n+m) where n = string 1 length m=string 2 length
            {
                if (this.str1[index1 - 1] == this.str2[index2 - 1])
                {
                    output[outputIndex - 1] = this.str1[index1 - 1];
                    outputIndex--;
                    index1 = index1 - 1;
                    index2 = index2 - 1;
                }
                else if (dp[index1 - 1, index2] > dp[index1, index2 - 1])
                {
                    index1 = index1 - 1;
                }
                else
                {
                    index2 = index2 - 1;
                }
            }

            return output;
        }
    }
}
