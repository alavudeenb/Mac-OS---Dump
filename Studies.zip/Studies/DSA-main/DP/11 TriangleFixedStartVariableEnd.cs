﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DP
{
    internal class TriangleFixedStartVariableEnd
    {
        int[,] memo;
        int[,] dp;
        public int Find(int[,] input)
        {
            memo = new int[input.GetLength(0), input.GetLength(1)];
            dp = new int[input.GetLength(0), input.GetLength(1)];

            return FindUsingSpaceOptimization(input);
            return FindUsingTabulation(input);
            return FindUsingMemo(0, 0, input);
            return FindRecursively(0, 0, input);
        }

        private int FindRecursively(int row, int column, int[,] input) // O(2^n)
        {
            if (row == input.GetLength(0) - 1)
                return input[row, column];

            var directions = new[,] { { 1, 0 }, { 1, 1 } };

            var down = 0;
            var currentRow = row + directions[0, 0];
            var currentColumn = column + directions[0, 1];
            if (currentRow >= 0 && currentRow < input.GetLength(0) && currentColumn >= 0 && currentColumn < input.GetLength(1))
                down = input[row, column] + FindRecursively(currentRow, currentColumn, input);

            var diag = 0;
            currentRow = row + directions[1, 0];
            currentColumn = column + directions[1, 1];
            if (currentRow >= 0 && currentRow < input.GetLength(0) && currentColumn >= 0 && currentColumn < input.GetLength(1))
                diag = input[row, column] + FindRecursively(currentRow, currentColumn, input);

            return Math.Min(down, diag);
        }

        private int FindUsingMemo(int row, int column, int[,] input) // O(n*m) space stack O(n) memo O(n*m)
        {
            if (row == input.GetLength(0) - 1)
                return input[row, column];

            if (memo[row, column] != 0)
                return memo[row, column];

            var directions = new[,] { { 1, 0 }, { 1, 1 } };
            var down = 0;
            var currentRow = row + directions[0, 0];
            var currentColumn = column + directions[0, 1];
            if (currentRow >= 0 && currentRow < input.GetLength(0) && currentColumn >= 0 && currentColumn < input.GetLength(1))
                down = input[row, column] + FindUsingMemo(currentRow, currentColumn, input);

            var diag = 0;
            currentRow = row + directions[1, 0];
            currentColumn = column + directions[1, 1];
            if (currentRow >= 0 && currentRow < input.GetLength(0) && currentColumn >= 0 && currentColumn < input.GetLength(1))
                diag = input[row, column] + FindUsingMemo(currentRow, currentColumn, input);

            var min = Math.Min(down, diag);
            memo[row, column] = min;
            return min;
        }

        private int FindUsingTabulation(int[,] input) // O(n*m) space dp O(n*m)
        {
            for (int row = input.GetLength(0) - 1; row >= 0; row--)
            {
                for (int column = input.GetLength(1) - 1; column >= 0; column--)
                {
                    if (row == input.GetLength(0) - 1)
                        dp[row, column] = input[row, column];
                    else
                    {
                        var directions = new[,] { { 1, 0 }, { 1, 1 } };
                        var down = 0;
                        var currentRow = row + directions[0, 0];
                        var currentColumn = column + directions[0, 1];
                        if (currentRow >= 0 && currentRow < input.GetLength(0) && currentColumn >= 0 && currentColumn < input.GetLength(1))
                            down = input[row, column] + dp[currentRow, currentColumn];

                        var diag = 0;
                        currentRow = row + directions[1, 0];
                        currentColumn = column + directions[1, 1];
                        if (currentRow >= 0 && currentRow < input.GetLength(0) && currentColumn >= 0 && currentColumn < input.GetLength(1))
                            diag = input[row, column] + dp[currentRow, currentColumn];

                        var min = Math.Min(down, diag);
                        dp[row, column] = min;
                    }
                }
            }

            return dp[0, 0];
        }

        private int FindUsingSpaceOptimization(int[,] input) // O(n*m) space O(4) => O(1)
        {
            var prev = new int[input.GetLength(1)];

            for (int row = input.GetLength(0) - 1; row >= 0; row--)
            {
                var curr = new int[input.GetLength(1)];
                for (int column = input.GetLength(1) - 1; column >= 0; column--)
                {
                    if (row == input.GetLength(0) - 1)
                        curr[column] = input[row, column];
                    else
                    {
                        var directions = new[,] { { 1, 0 }, { 1, 1 } };
                        var down = 0;
                        var currentRow = row + directions[0, 0];
                        var currentColumn = column + directions[0, 1];
                        if (currentRow >= 0 && currentRow < input.GetLength(0) && currentColumn >= 0 && currentColumn < input.GetLength(1))
                            down = input[row, column] + prev[currentColumn];

                        var diag = 0;
                        currentRow = row + directions[1, 0];
                        currentColumn = column + directions[1, 1];
                        if (currentRow >= 0 && currentRow < input.GetLength(0) && currentColumn >= 0 && currentColumn < input.GetLength(1))
                            diag = input[row, column] + prev[currentColumn];

                        var min = Math.Min(down, diag);
                        curr[column] = min;
                    }
                }
                prev = curr;
            }

            return prev[0];
        }

    }
}
