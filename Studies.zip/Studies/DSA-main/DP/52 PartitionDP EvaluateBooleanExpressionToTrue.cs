﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DP
{
    internal class _52_PartitionDP_EvaluateBooleanExpressionToTrue
    {
        char[] _booleanExpression;
        int[,,] memo;
        int[,,] dp;


        public int Find(char[] booleanExpression)
        {
            this._booleanExpression = booleanExpression;
            this.memo = new int[this._booleanExpression.Length, this._booleanExpression.Length, 2];
            this.dp = new int[this._booleanExpression.Length, this._booleanExpression.Length, 2];

            for (int row = 0; row < this.memo.GetLength(0); row++)
            {
                for (int column = 0; column < this.memo.GetLength(1); column++)
                {
                    for (int zaxis = 0; zaxis < this.memo.GetLength(2); zaxis++)
                    {
                        this.memo[row, column, zaxis] = -1;
                    }
                }
            }

            return FindUsingDP();
            return FindRecursivelyUsingMemo(0, this._booleanExpression.Length - 1, 1);
            return FindRecursively(0, this._booleanExpression.Length - 1, 1); // 1 means true 0 means false
        }

        private int FindRecursively(int i, int j, int lookingForTrue) // Exponential
        {
            if (i > j) return 0;

            if (i == j)
            {
                if (lookingForTrue == 1)
                {
                    if (this._booleanExpression[i] == 'T')
                        return 1;
                    else
                        return 0;
                }
                else
                {
                    if (this._booleanExpression[i] == 'F')
                        return 1;
                    else
                        return 0;
                }
            }

            var count = 0;
            for (int ind = i + 1; ind < j; ind = ind + 2)
            {
                var leftTrue = FindRecursively(i, ind - 1, 1);
                var leftFalse = FindRecursively(i, ind - 1, 0);
                var rightTrue = FindRecursively(ind + 1, j, 1);
                var rightFalse = FindRecursively(ind + 1, j, 0);

                if (this._booleanExpression[ind] == '&')
                {
                    if (lookingForTrue == 1)
                        count = count + leftTrue * rightTrue;
                    else
                        count = count + (leftTrue * rightFalse) + (leftFalse * rightTrue) + (leftFalse * rightFalse);
                }
                else if (this._booleanExpression[ind] == '|')
                {
                    if (lookingForTrue == 1)
                        count = count + (leftTrue * rightTrue) + (leftTrue * rightFalse) + (leftFalse * rightTrue);
                    else
                        count = count + leftFalse * rightFalse;
                }
                else if (this._booleanExpression[ind] == '^')
                {
                    if (lookingForTrue == 1)
                        count = count + (leftFalse * rightTrue) + (leftTrue * rightFalse);
                    else
                        count = count + (leftTrue * rightTrue);
                }
            }

            return count;
        }

        private int FindRecursivelyUsingMemo(int i, int j, int lookingForTrue) // O(n3) // space O(n2) stack O(n) auxilary stack space is O(n2+n) = O(n2)
        {
            if (i > j) return 0;

            if (this.memo[i, j, lookingForTrue] != -1)
                return this.memo[i, j, lookingForTrue];

            if (i == j)
            {
                if (lookingForTrue == 1)
                {
                    if (this._booleanExpression[i] == 'T')
                        return 1;
                    else
                        return 0;
                }
                else
                {
                    if (this._booleanExpression[i] == 'F')
                        return 1;
                    else
                        return 0;
                }
            }

            var count = 0;
            for (int ind = i + 1; ind < j; ind = ind + 2)
            {
                var leftTrue = FindRecursivelyUsingMemo(i, ind - 1, 1);
                var leftFalse = FindRecursivelyUsingMemo(i, ind - 1, 0);
                var rightTrue = FindRecursivelyUsingMemo(ind + 1, j, 1);
                var rightFalse = FindRecursivelyUsingMemo(ind + 1, j, 0);

                if (this._booleanExpression[ind] == '&')
                {
                    if (lookingForTrue == 1)
                        count = count + leftTrue * rightTrue;
                    else
                        count = count + (leftTrue * rightFalse) + (leftFalse * rightTrue) + (leftFalse * rightFalse);
                }
                else if (this._booleanExpression[ind] == '|')
                {
                    if (lookingForTrue == 1)
                        count = count + (leftTrue * rightTrue) + (leftTrue * rightFalse) + (leftFalse * rightTrue);
                    else
                        count = count + leftFalse * rightFalse;
                }
                else if (this._booleanExpression[ind] == '^')
                {
                    if (lookingForTrue == 1)
                        count = count + (leftFalse * rightTrue) + (leftTrue * rightFalse);
                    else
                        count = count + (leftTrue * rightTrue);
                }
            }

            this.memo[i, j, lookingForTrue] = count;
            return count;
        }


        private int FindUsingDP() // O(n3) // space O(n2)
        {
            for (int i = 0; i < this.dp.GetLength(0); i++)
            {
                for (int j = 0; j < this.dp.GetLength(1); j++)
                {
                    for (int lookingForTrue = 0; lookingForTrue < 2; lookingForTrue++)
                    {
                        if (i > j)
                        {
                            this.dp[i, j, lookingForTrue] = 0;
                        }

                        if (i == j)
                        {
                            if (lookingForTrue == 1)
                            {
                                if (this._booleanExpression[i] == 'T')
                                    this.dp[i, j, lookingForTrue] = 1;
                                else
                                    this.dp[i, j, lookingForTrue] = 0;
                            }
                            else
                            {
                                if (this._booleanExpression[i] == 'F')
                                    this.dp[i, j, lookingForTrue] = 1;
                                else
                                    this.dp[i, j, lookingForTrue] = 0;
                            }
                        }
                    }
                }
            }

            for (int i = this._booleanExpression.Length - 1; i >= 0; i--)
            {
                for (int j = 0; j <= this._booleanExpression.Length - 1; j++)
                {
                    for (int lookingForTrue = 0; lookingForTrue < 2; lookingForTrue++)
                    {
                        if (i > j) continue; // These are very important step as it is covered in the line no 163 to 166

                        if (i == j) continue; // These are very important step as it is covered in the line no 168 to 184

                        var count = 0;
                        for (int ind = i + 1; ind < j; ind = ind + 2)
                        {
                            var leftTrue = this.dp[i, ind - 1, 1];
                            var leftFalse = this.dp[i, ind - 1, 0];
                            var rightTrue = this.dp[ind + 1, j, 1];
                            var rightFalse = this.dp[ind + 1, j, 0];

                            if (this._booleanExpression[ind] == '&')
                            {
                                if (lookingForTrue == 1)
                                    count = count + leftTrue * rightTrue;
                                else
                                    count = count + (leftTrue * rightFalse) + (leftFalse * rightTrue) + (leftFalse * rightFalse);
                            }
                            else if (this._booleanExpression[ind] == '|')
                            {
                                if (lookingForTrue == 1)
                                    count = count + (leftTrue * rightTrue) + (leftTrue * rightFalse) + (leftFalse * rightTrue);
                                else
                                    count = count + leftFalse * rightFalse;
                            }
                            else if (this._booleanExpression[ind] == '^')
                            {
                                if (lookingForTrue == 1)
                                    count = count + (leftFalse * rightTrue) + (leftTrue * rightFalse);
                                else
                                    count = count + (leftTrue * rightTrue);
                            }
                        }
                        this.dp[i, j, lookingForTrue] = count;
                    }
                }
            }

            return this.dp[0, this._booleanExpression.Length - 1, 1];

        }
    }
}
