﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata;
using System.Text;
using System.Threading.Tasks;

namespace DP
{
    internal class DP17_CountSubsetWithSumK
    {
        int[,] memo;
        public int Find(int[] input, int target)
        {
            memo = new int[input.Length, target + 1];

            return FindUsingSpaceOptimization(input, target);
            return FindUsingTabulation(input, target);
            return FindUsingMemo(input.Length - 1, target, input);
            return FindRecursively(input.Length - 1, target, input);
        }

        private int FindRecursively(int index, int target, int[] input)
        {
            if (target == 0) return 1; // This line is for input not having zeros

            if (index == 0)
            {
                if (input[index] == target) return 1;
                else return 0;

                //Below lines are for input having zeros. If i go with below lines above 2 lines can be deleted.

                if (target == 0 && input[index] == 0) return 2; // Why 2 because when input[index] equals 0 && traget equals 0 then both take and nottake case will have same result.
                                                                // That's why returing 2 (1 for take , 1 for nottake).

                if (target == 0 && input[index] != 0) return 1;

                if (input[index] == target) return 1;

                return 0;
            }

            var take = 0;
            if (input[index] <= target)
                take = FindRecursively(index - 1, target - input[index], input);

            var notTake = FindRecursively(index - 1, target, input);

            return take + notTake;
        }

        private int FindUsingMemo(int index, int target, int[] input)
        {
            if (target == 0) return 1;

            if (index == 0)
            {
                if (input[index] == target) return 1;
                else return 0;
            }

            if (memo[index, target] != 0) return memo[index, target];

            var take = 0;
            if (input[index] <= target)
                take = FindRecursively(index - 1, target - input[index], input);

            var notTake = FindRecursively(index - 1, target, input);

            var result = take + notTake;
            memo[index, target] = result;
            return result;
        }

        private int FindUsingTabulation(int[] input, int target)
        {
            var n = input.Length;
            var k = target + 1;
            var dp = new int[n, k];

            for (int ind = 0; ind < n; ind++)
            {
                dp[ind, 0] = 1;
            }

            if (input[0] <= target)
                dp[0, input[0]] = 1;

            // Below lines are for input having zeros. Above "for loop" and "if" condition should be commented if we go with below code

            /*if (input[0] == 0 && target == 0)
                dp[0, 0] = 2;
            else
                dp[0, 0] = 1;

            if (input[0] != 0 && input[0] <= target)
                dp[0, input[0]] = 1;*/

            for (int ind = 1; ind < n; ind++)
            {
                for (int _k = 1; _k < k; _k++) // If we uncomment above lines then the iteration should start from 0
                {
                    var take = 0;
                    if (input[ind] <= _k)
                        take = dp[ind - 1, _k - input[ind]];

                    var notTake = dp[ind - 1, _k];

                    dp[ind, _k] = take + notTake;
                }
            }

            return dp[n - 1, target];
        }

        private int FindUsingSpaceOptimization(int[] input, int target)
        {
            var n = input.Length;
            var k = target + 1;
            var prev = new int[k];

            prev[0] = 1;

            if (input[0] <= target)
                prev[input[0]] = 1;

            for (int ind = 1; ind < n; ind++)
            {
                var curr = new int[k];
                curr[0] = 1;
                for (int _k = 1; _k < k; _k++)
                {
                    var take = 0;
                    if (input[ind] <= _k)
                        take = prev[_k - input[ind]];

                    var notTake = prev[_k];

                    curr[_k] = take + notTake;
                }
                prev = curr;
            }

            return prev[target];
        }
    }
}
