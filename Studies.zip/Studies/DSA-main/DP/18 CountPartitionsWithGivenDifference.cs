﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DP
{
    internal class DP18_CountPartitionsWithGivenDifference
    {
        public int Find(int[] input, int difference)
        {
            var total = 0;
            for (int ind = 0; ind < input.Length; ind++)
            {
                total = total + input[ind];
            }
            if ((total - difference) < 0 || (total - difference) % 2 != 0) 
                return 0;
            var target = (total - difference) / 2;
            return FindUsingTabulation(input, target);
        }

        private int FindUsingTabulation(int[] input, int target)
        {
            var n = input.Length;
            var k = target + 1;
            var dp = new int[n, k];

            /*for (int ind = 0; ind < n; ind++)
            {
                dp[ind, 0] = 1;
            }

            if (input[0] <= target)
                dp[0, input[0]] = 1;*/

            // Below lines are for input having zeros. Above "for loop" and "if" condition should be deleted if we go with below code

            if (input[0] == 0 && target == 0)
                dp[0, 0] = 2;
            else
                dp[0, 0] = 1;

            if (input[0] != 0 && input[0] <= target)
                dp[0, input[0]] = 1;

            for (int ind = 1; ind < n; ind++)
            {
                for (int _k = 0; _k < k; _k++) // As mentioned in the DP17 the base case "if(target==0) return 1;" has been removed by commenting above for loop and if condition hence iterate from 0
                {
                    var take = 0;
                    if (input[ind] <= _k)
                        take = dp[ind - 1, _k - input[ind]];

                    var notTake = dp[ind - 1, _k];

                    dp[ind, _k] = take + notTake;
                }
            }

            return dp[n - 1, target];
        }
    }
}
