﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace DP
{
    internal class _36_BuySellStock2 // Unlimited time Buy and Sell
    {
        int[] stockPrices;

        int[,] memo;

        public int FindMaxProfit(int[] stockPrices)
        {
            this.stockPrices = stockPrices;
            this.memo = new int[this.stockPrices.Length, 2]; //The reason for 2 is because buy parameter in the function will have 2 option buy or don't buy
            for (int row = 0; row < this.memo.GetLength(0); row++)
            {
                for (int column = 0; column < this.memo.GetLength(1); column++)
                {
                    this.memo[row, column] = -1;
                }
            }

            //return FindUsingSpaceOptimisation();
            //return FindUsingTabulation();
            return FindUsingMemo(0, true);
            return FindRecursively(0, true); // The index has to start from 0 because at first the stock should be purchased before selling it. 
                                             // In the reverse order (n -> 0) if we consider the last value as a buy and the previous value as sell it will produce wrong result
        }

        private int FindRecursively(int index, bool buy) // O(2^n)
        {
            if (index == this.stockPrices.Length)
                return 0;

            var profit = 0;
            if (buy)
            {
                profit = Math.Max(-this.stockPrices[index] + FindRecursively(index + 1, false), 0 + FindRecursively(index + 1, true));
            }
            else
            {
                profit = Math.Max(this.stockPrices[index] + FindRecursively(index + 1, true), 0 + FindRecursively(index + 1, false));
            }

            return profit;
        }

        private int FindUsingMemo(int index, bool buy) // O(n*2) // space: memo O(n*2) stack O(n)
        {
            if (index == this.stockPrices.Length)
                return 0;

            if (this.memo[index, Convert.ToInt32(buy)] != -1) return this.memo[index, Convert.ToInt32(buy)];

            var profit = 0;
            if (buy)
            {
                profit = Math.Max(-this.stockPrices[index] + FindUsingMemo(index + 1, false), 0 + FindUsingMemo(index + 1, true));
            }
            else
            {
                profit = Math.Max(this.stockPrices[index] + FindUsingMemo(index + 1, true), 0 + FindUsingMemo(index + 1, false));
            }
            this.memo[index, Convert.ToInt32(buy)] = profit;

            return profit;
        }

        private int FindUsingTabulation() //O(n*2) // space dp O(n*2)
        {
            var dp = new int[this.stockPrices.Length, 2];
            for (int column = 0; column < 2; column++)
                dp[this.stockPrices.Length, column] = 0;

            for (int ind = this.stockPrices.Length - 1; ind >= 0; ind--)
            {
                for (int buy = 0; buy < 2; buy++)
                {
                    var profit = 0;
                    if (Convert.ToBoolean(buy))
                    {
                        profit = Math.Max(-this.stockPrices[ind] + dp[ind + 1, Convert.ToInt32(false)], 0 + dp[ind + 1, Convert.ToInt32(true)]);
                    }
                    else
                    {
                        profit = Math.Max(this.stockPrices[ind] + dp[ind + 1, Convert.ToInt32(true)], 0 + dp[ind + 1, Convert.ToInt32(false)]);
                    }

                    dp[ind, buy] = profit;
                }
            }

            return dp[0, 1]; // 1 means true
        }

        private int FindUsingSpaceOptimisation() //O(n*2) // space O(2)
        {
            var prev = new int[2];
            for (int column = 0; column < 2; column++)
                prev[column] = 0;

            for (int ind = this.stockPrices.Length - 1; ind >= 0; ind--)
            {
                var curr = new int[2];
                for (int buy = 0; buy < 2; buy++)
                {
                    var profit = 0;
                    if (Convert.ToBoolean(buy))
                    {
                        profit = Math.Max(-this.stockPrices[ind] + prev[Convert.ToInt32(false)], 0 + prev[Convert.ToInt32(true)]);
                    }
                    else
                    {
                        profit = Math.Max(this.stockPrices[ind] + prev[Convert.ToInt32(true)], 0 + prev[Convert.ToInt32(false)]);
                    }

                    curr[buy] = profit;
                }
                prev = curr;
            }

            return prev[1]; // 1 means true
        }
    }
}
