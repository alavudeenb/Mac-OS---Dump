﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DP
{
    internal class _27_LongestCommonSubstring
    {
        string str1;

        string str2;

        int str1LengthPlusOne;

        int str2LengthPlusOne;

        int[,] dp;

        public int Find(string str1, string str2)
        {
            this.str1 = str1;
            this.str2 = str2;
            this.str1LengthPlusOne = this.str1.Length + 1;
            this.str2LengthPlusOne = this.str2.Length + 1;
            this.dp = new int[this.str1LengthPlusOne, this.str2LengthPlusOne];

            return FindUsingTabulation();
        }

        private int FindUsingTabulation() // O(n*m)
        {
            for (int ind2 = 0; ind2 <= this.str2.Length; ind2++) // Index1 = 0
                dp[0, ind2] = 0;
            for (int ind1 = 0; ind1 <= this.str1.Length; ind1++) // Index2 = 0
                dp[ind1, 0] = 0;

            int max = 0;
            for (int ind1 = 1; ind1 <= this.str1.Length; ind1++)
            {
                for (int ind2 = 1; ind2 <= this.str2.Length; ind2++)
                {
                    if (this.str1[ind1 - 1] == this.str2[ind2 - 1])
                        dp[ind1, ind2] = 1 + dp[ind1 - 1, ind2 - 1];
                    else
                        dp[ind1, ind2] = 0;

                    max = Math.Max(max, dp[ind1, ind2]);
                }
            }

            return max;
        }
    }
}
