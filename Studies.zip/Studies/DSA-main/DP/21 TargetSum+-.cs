﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DP
{
    internal class _21_TargetSum__
    {

        public int Find(int[] input, int target)
        {
            var totalSum = 0;
            for (int ind = 0; ind < input.Length; ind++)
            {
                totalSum = totalSum + input[ind];
            }

            if (totalSum - target < 0 || (totalSum - target) % 2 != 0)
                return 0;

            var subset2SumAsTarget = (totalSum - target) / 2;

            return FindUsingTabulation(input, subset2SumAsTarget);
        }

        private int FindUsingTabulation(int[] input, int newTarget)
        {

            var n = input.Length;
            var k = newTarget + 1;

            var dp = new int[n, k];

            for (int _k = 0; _k < k; _k++)
            {
                if (_k == 0 && input[0] == 0)
                    dp[0, _k] = 2;
                else if (_k == 0 && input[0] != 0)
                    dp[0, _k] = 1;
                else if (input[0] != 0 && input[0] == _k)
                    dp[0, input[0]] = 1;
                else
                    dp[0, _k] = 0;
            }

            for (int ind = 1; ind < n; ind++)
            {
                for (int _k = 0; _k < k; _k++)
                {
                    var take = 0;
                    if (input[ind] <= _k)
                        take = dp[ind - 1, _k - input[ind]];

                    var notTake = dp[ind - 1, _k];

                    dp[ind, _k] = take + notTake;
                }
            }
            return dp[n - 1, newTarget];
        }
    }
}
