﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DP
{
    internal class DP_15_EqualSubsetSum
    {
        public bool Find(int[] input)
        {
            return FindUsingSubsetSumMethod(input);
        }

        private bool FindUsingSubsetSumMethod(int[] input)
        {
            var totalSum = 0;

            for (int init = 0; init < input.Length; init++)
            {
                totalSum = totalSum + input[init];
            }

            if (totalSum % 2 != 0) return false; // Because for odd numbers we can't equally divide

            var target = totalSum / 2;

            var n = input.Length;
            var k = target + 1;

            var dp = new bool[n, k];

            for (int ind = 0; ind < n; ind++)
            {
                dp[ind, 0] = true;
            }
            
            if (input[0] <= k)
                dp[0, input[0]] = true;

            for (int ind = 1; ind < n; ind++)
            {
                for (int _k = 1; _k < k; _k++)
                {
                    var take = false;

                    if (input[ind] <= _k)
                        take = dp[ind - 1, _k - input[ind]];

                    var notTake = dp[ind - 1, _k];

                    dp[ind, _k] = take || notTake;
                }
            }

            return dp[n - 1, target];
        }
    }
}
