﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DP
{
    internal class WordOnGrid
    {
        Stack<(int x, int y)> output = new Stack<(int x, int y)>();
        public Stack<(int x, int y)> Find(char[,] input, string word)
        {

            FindRecursively(0, 0, 0, input, word);

            return output;
        }

        private bool FindRecursively(int x, int y, int charIndex, char[,] input, string word)
        {
            if (charIndex == word.Length - 1 && word[charIndex] == input[x, y])
            {
                output.Push((x, y));
                return true;
            }

            //if (x == input.GetLength(0) - 1 && y == input.GetLength(1) - 1) return false;

            var directions = new[,] { { 0, 1 }, { 1, 0 } };
            for (int init = 0; init < directions.GetLength(0); init++)
            {
                var currentX = x + directions[init, 0];
                var currentY = y + directions[init, 1];
                if (currentX >= 0 && currentX < input.GetLength(0) &&
                    currentY >= 0 && currentY < input.GetLength(1)
                    )
                {
                    var tempCharIndex = word[charIndex] == input[x, y] ? charIndex + 1 : 0;
                    var result = FindRecursively(currentX, currentY, tempCharIndex, input, word);

                    if (word.Length == output.Count) return result;
                    if (result)
                    {
                        output.Push((x, y));
                        return result;
                    }
                    //else
                    //{
                    //    output.Pop();
                    //    charIndex = word[charIndex] == input[currentX, currentY] ? charIndex - 1 : charIndex;
                    //}
                }
            }

            return false;
        }
    }
}
