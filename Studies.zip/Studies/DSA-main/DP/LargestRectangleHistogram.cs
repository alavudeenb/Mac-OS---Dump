using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

namespace HelloWorld
{
    public class Program
    {
        static int[] input = new[]
{
2,1,5,6,2,3
}; //output 10
        public static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");
            var rightSmallestIndexes = new int[input.Length];

            var leftSmallestIndexes = new int[input.Length];

            var stack = new Stack<int>();

            for (int ind = 0; ind < input.Length; ind++)
            {
                FindLeftSmallestIndex(0, ind, stack, leftSmallestIndexes);
            }

            stack = new Stack<int>();

            for (int ind = input.Length - 1; ind >= 0; ind--)
            {
                FindRightSmallestIndex(input.Length - 1, ind, stack, rightSmallestIndexes);
            }

            var max = 0;

            for (int ind = 0; ind < input.Length; ind++)
            {
                Console.WriteLine($"{max} {rightSmallestIndexes[ind]} {leftSmallestIndexes[ind]} {input[ind]}");
                max = Math.Max(
                    max,
                    (rightSmallestIndexes[ind] - leftSmallestIndexes[ind] + 1) * input[ind]
                );
            }
            Console.WriteLine(max);


        }

        private static void FindLeftSmallestIndex(
    int startingIndex,
    int index,
    Stack<int> stack,
    int[] smallestIndexArray)
        {
            while (stack.Count > 0 &&
                   input[stack.Peek()] > input[index])
            {
                stack.Pop();
            }

            if (stack.Count > 0 &&
                input[stack.Peek()] < input[index])
            {
                smallestIndexArray[index] = stack.Peek() + 1;
            }
            else
            {
                smallestIndexArray[index] = startingIndex;
            }

            stack.Push(index);
        }

        private static void FindRightSmallestIndex(
            int startingIndex,
            int index,
            Stack<int> stack,
            int[] smallestIndexArray)
        {
            while (stack.Count > 0 &&
                   input[stack.Peek()] > input[index])
            {
                stack.Pop();
            }

            if (stack.Count > 0 &&
                input[stack.Peek()] < input[index])
            {
                smallestIndexArray[index] = stack.Peek() - 1;
            }
            else
            {
                smallestIndexArray[index] = startingIndex;
            }

            stack.Push(index);
        }
    }
}