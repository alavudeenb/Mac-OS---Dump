﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DP
{
    internal class _47_NumberOfLongestIncreasingSubsequence
    {
        public int Find(int[] input)
        {
            var dp = new int[input.Length];
            var count = new int[input.Length];

            for (int ind = 0; ind < dp.Length; ind++)
            {
                dp[ind] = 1;
                count[ind] = 1;
            }

            var maxLIS = 0;
            var countNumberOfLIS = 0;
            for (int ind = 0; ind < input.Length; ind++)
            {
                for (int prevInd = 0; prevInd < ind; prevInd++)
                {
                    if (input[ind] > input[prevInd])
                    {
                        if (dp[ind] < 1 + dp[prevInd])
                        {
                            dp[ind] = 1 + dp[prevInd];
                            count[ind] = 1;
                        }
                        else if (dp[ind] == 1 + dp[prevInd])
                        {
                            count[ind] = 1 + count[ind];
                        }
                    }
                }
                if (maxLIS < dp[ind])
                {
                    maxLIS = Math.Max(maxLIS, dp[ind]);
                    countNumberOfLIS = count[ind];
                }
            }

            return countNumberOfLIS;
        }
    }
}
