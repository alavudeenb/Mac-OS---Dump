﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DP
{
    internal class _40_BuySellStockWithTransactionFee
    {
        int[] stockPrices;

        public int FindMaxProfit(int[] stockPrices, int transactionFee)
        {
            this.stockPrices = stockPrices;
            return FindRecursively(0, true, transactionFee);
        }

        private int FindRecursively(int index, bool buy, int transactionFee)
        {
            if (index == this.stockPrices.Length) return 0;

            var profit = 0;
            if (buy)
                profit = Math.Max(-this.stockPrices[index] + FindRecursively(index + 1, false, transactionFee),
                                    0 + FindRecursively(index + 1, true, transactionFee));
            else                                            //Below is the only change
                profit = Math.Max(this.stockPrices[index] - transactionFee  + FindRecursively(index + 1, true, transactionFee),
                                    0 + FindRecursively(index + 1, false, transactionFee));

            return profit;
        }
    }
}
