﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DP
{
    internal class _50_PartitionDP_MinimumCostToCutStick
    {
        int[] updatedStickIndexToCut;

        int[,] memo;

        int[,] dp;

        public int Find(int[] stickIndexToCut, int lengthOfTheStick)
        {
            Array.Sort(stickIndexToCut); // Sorting the input array because then independently the cut can happen from the partitioned array using two recursive function
            this.memo = new int[stickIndexToCut.Length + 1, stickIndexToCut.Length + 1]; // +1 because stickIndexToCut 0th index value is put into to 1st index hence i will start from 1st index and j wil also be increased by 1
            this.dp = new int[stickIndexToCut.Length + 2, stickIndexToCut.Length + 2]; // +2 because in line 97 when i is at the last index of stickIndexToCut array, the dp array is read as dp[ind+1, j], hence to support that operation we have added +2 instead of +1
            
            for (int row = 0; row < this.memo.GetLength(0); row++)
                for (int column = 0; column < this.memo.GetLength(1); column++)
                    this.memo[row, column] = -1;

            this.updatedStickIndexToCut = new int[stickIndexToCut.Length + 2]; // +2 because we want to add 0 in the begining and lengthOfTheStick at the end. The reason is anytime we want to find the current length of the j+1 index of the array and i-1 index of the array
            this.updatedStickIndexToCut[0] = 0;
            this.updatedStickIndexToCut[this.updatedStickIndexToCut.Length - 1] = lengthOfTheStick;

            for (int ind = 0; ind < stickIndexToCut.Length; ind++)
            {
                this.updatedStickIndexToCut[ind + 1] = stickIndexToCut[ind];
            }

            return FindUsingTabulation();
            return FindUsingMemo(1, this.updatedStickIndexToCut.Length - 2);
            return FindRecursively(1, this.updatedStickIndexToCut.Length - 2);
        }

        private int FindRecursively(int i, int j) // O(Exponential)
        {
            if (i > j) return 0;

            var min = Int32.MaxValue;
            for (int ind = i; ind <= j; ind++)
            {
                var localMin = this.updatedStickIndexToCut[j + 1] - this.updatedStickIndexToCut[i - 1] +
                               FindRecursively(i, ind - 1) +
                               FindRecursively(ind + 1, j);
                min = Math.Min(min, localMin);
            }
            return min;
        }

        public int FindUsingMemo(int i, int j) // O(m*m*m) => O(m3) space: O(m2)  stack O(m)
        {
            if (i > j) return 0;

            if (this.memo[i, j] != -1) return this.memo[i, j];

            var min = Int32.MaxValue;
            for (int ind = i; ind <= j; ind++)
            {
                var localMin = this.updatedStickIndexToCut[j + 1] - this.updatedStickIndexToCut[i - 1] +
                               FindUsingMemo(i, ind - 1) +
                               FindUsingMemo(ind + 1, j);
                min = Math.Min(min, localMin);
            }

            this.memo[i, j] = min;
            return min;
        }

        private int FindUsingTabulation() // O(m3) space: O(m2)
        {
            for (int i = 0; i < this.dp.GetLength(0); i++)
            {
                for (int j = 0; j < this.dp.GetLength(1); j++)
                {
                    if (i > j)
                        this.dp[i, j] = 0;
                }
            }

            for (int i = this.updatedStickIndexToCut.Length - 2; i >= 1; i--)
            {
                for (int j = 1; j <= this.updatedStickIndexToCut.Length - 2; j++)
                {
                    if (i > j) continue;

                    var min = Int32.MaxValue;
                    for (int ind = i; ind <= j; ind++)
                    {
                        var localMin = this.updatedStickIndexToCut[j + 1] - this.updatedStickIndexToCut[i - 1] +
                                       dp[i, ind - 1] +
                                       dp[ind + 1, j];
                        min = Math.Min(min, localMin);
                    }
                    dp[i, j] = min;
                }
            }

            return dp[1, this.updatedStickIndexToCut.Length - 2];
        }
    }
}
