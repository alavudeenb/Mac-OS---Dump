﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DP
{
    internal class FrogJump
    {
        int minimumEnery = 0;
        int[] memo;//This helps to optimize time complexity O(2^n) -> O(n*k), space complexity would be O(n) recursion method stack space and memo array space O(n) => O(n+n)
        int[] dp; // This helps to optimize space complexity o(n). how because using only dp array space.NO recursion stack space.
        internal int FindMinimumEnergyLoss(int[] stairsEnergyLevel, int k)
        {
            memo = new int[stairsEnergyLevel.Length];
            dp = new int[stairsEnergyLevel.Length];

            return FindRecursivelyForKJumpsWithDP(stairsEnergyLevel, k);
            //return FindRecursivelyForKJumpsWithMemo(0, stairsEnergyLevel, k);
            //return FindRecursivelyForKJumps(0, stairsEnergyLevel, k);

            //return FindRecursivelyWithDP(stairsEnergyLevel);
            //return FindRecursivelyWithMemo(0, stairsEnergyLevel, memo);
            //return FindRecursively(0, stairsEnergyLevel);
        }

        /*private int FindRecursively(int index, int totalEnergyLevel, int[] stairsEnergyLevel) // Unable to do memo
        {
            if (index == stairsEnergyLevel.Length - 1)
            {
                return totalEnergyLevel;
            }

            var left = FindRecursively(index + 1, totalEnergyLevel + Math.Abs(stairsEnergyLevel[index] - stairsEnergyLevel[index + 1]), stairsEnergyLevel);

            var right = Int32.MaxValue;
            if (index + 2 <= stairsEnergyLevel.Length - 1)
                right = FindRecursively(index + 2, totalEnergyLevel + Math.Abs(stairsEnergyLevel[index] - stairsEnergyLevel[index + 2]), stairsEnergyLevel);

            return Math.Min(left, right);
        }*/

        private int FindRecursively(int index, int[] stairsEnergyLevel) // O(2^n)
        {
            if (index == stairsEnergyLevel.Length - 1)
                return 0;


            var left = Math.Abs(stairsEnergyLevel[index] - stairsEnergyLevel[index + 1]) + FindRecursively(index + 1, stairsEnergyLevel);

            var right = Int32.MaxValue;
            if (index + 2 < stairsEnergyLevel.Length)
            {
                right = Math.Abs(stairsEnergyLevel[index] - stairsEnergyLevel[index + 2]) + FindRecursively(index + 2, stairsEnergyLevel);
            }

            return Math.Min(left, right);
        }

        private int FindRecursivelyWithMemo(int index, int[] stairsEnergyLevel, int[] memo) // O(n)
        {
            if (index == stairsEnergyLevel.Length - 1)
                return 0;

            if (memo[index] != 0)
                return memo[index];

            var left = Math.Abs(stairsEnergyLevel[index] - stairsEnergyLevel[index + 1]) + FindRecursivelyWithMemo(index + 1, stairsEnergyLevel, memo);

            var right = Int32.MaxValue;
            if (index + 2 < stairsEnergyLevel.Length)
            {
                right = Math.Abs(stairsEnergyLevel[index] - stairsEnergyLevel[index + 2]) + FindRecursivelyWithMemo(index + 2, stairsEnergyLevel, memo);
            }

            var result = Math.Min(left, right);
            memo[index] = result;

            return result;
        }

        private int FindRecursivelyWithDP(int[] stairsEnergyLevel) // O(n)
        {
            var prev2 = Int32.MaxValue;
            var prev = 0;

            for (int init = stairsEnergyLevel.Length - 2; init >= 0; init--) // The reason for -2 is because we want to substract two elements.
            {
                var tempPrev = prev + Math.Abs(stairsEnergyLevel[init] - stairsEnergyLevel[init + 1]);

                var tempPrev2 = Int32.MaxValue;
                if (init + 2 < stairsEnergyLevel.Length)
                {
                    tempPrev2 = prev2 + Math.Abs(stairsEnergyLevel[init] - stairsEnergyLevel[init + 2]);
                }

                var curr = Math.Min(tempPrev, tempPrev2);
                prev2 = prev;
                prev = curr;
            }

            return prev;
        }



        private int FindRecursivelyForKJumps(int index, int[] stairsEnergyLevel, int k) // O(k^n)
        {
            if (index == stairsEnergyLevel.Length - 1)
                return 0;

            int minimumJumps = Int32.MaxValue; //**************
            for (int init = 1; init <= k; init++)
            {
                var result = Int32.MaxValue;
                if ((index + init) < stairsEnergyLevel.Length)
                {
                    result = Math.Abs(stairsEnergyLevel[index] - stairsEnergyLevel[index + init]) + FindRecursivelyForKJumps(index + init, stairsEnergyLevel, k);
                }
                minimumJumps = Math.Min(minimumJumps, result);
            }

            return minimumJumps;
        }

        
        // O(n*k) space complexity O(n) stack space +O(n) memo array space. This is for below function
        private int FindRecursivelyForKJumpsWithMemo(int index, int[] stairsEnergyLevel, int k)
        {
            if (index == stairsEnergyLevel.Length - 1)
                return 0;

            if (memo[index] != 0) return memo[index];

            int minimumJumps = Int32.MaxValue;
            for (int init = 1; init <= k; init++)
            {
                var result = Int32.MaxValue;
                if ((index + init) < stairsEnergyLevel.Length)
                {
                    result = Math.Abs(stairsEnergyLevel[index] - stairsEnergyLevel[index + init]) + FindRecursivelyForKJumpsWithMemo(index + init, stairsEnergyLevel, k);
                }
                minimumJumps = Math.Min(minimumJumps, result);
            }

            memo[index] = minimumJumps;

            return minimumJumps;
        }

        // TC is O(n*k). The benefit is only space optimization O(n) this is for dp array.
        //NOTE: we can't do space optimization further with variables instead of dp array because in worst case (k = n) scenario we need k variables to hold prev, prev2, prev3,....prevn which is equalent to n array size.
        private int FindRecursivelyForKJumpsWithDP(int[] stairsEnergyLevel, int k) 
        {
            dp[stairsEnergyLevel.Length - 1] = 0; // *It should be for loop for all cells of the last row*
                                                  // setting last index to be 0 as per base case in the recurive method.

            for (int init = stairsEnergyLevel.Length - 2; init >= 0; init--)
            {
                int minimumEnergyLevel = Int32.MaxValue;

                for (int _k = 1; _k <= k; _k++)
                {
                    if (init + _k < stairsEnergyLevel.Length)
                    {
                        var result = Math.Abs(stairsEnergyLevel[init] - stairsEnergyLevel[init + _k]) + dp[init + _k];
                        minimumEnergyLevel = Math.Min(minimumEnergyLevel, result);
                    }
                }
                dp[init] = minimumEnergyLevel;
            }

            return dp[0];
        }
    }
}
