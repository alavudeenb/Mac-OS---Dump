﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace DP
{
    internal class DP20_MinimumCoins
    {
        int n;
        int[] input;
        int[,] memo;
        int[,] dp;
        int k;

        public double Find(int[] input, int target)
        {
            this.n = input.Length;
            this.input = input;
            this.k = target + 1;

            this.memo = new int[this.n, k];
            this.dp = new int[this.n, k];

            return FindusingSpaceOptimization(target);
            return FindusingTabulation(target);
            return FindusingMemoization(this.n - 1, target);
            return FindRecursively(this.n - 1, target);
        }

        private double FindRecursively(int index, int target) // O(2^n)
        {
            if (index == 0)
            {
                if (target % input[index] == 0)
                    return target / input[index];
                else
                    return 1e7;
            }

            var take = 1e7;
            if (this.input[index] <= target)
                take = 1 + FindRecursively(index, target - this.input[index]);

            var notTake = (double)(0 + FindRecursively(index - 1, target));

            return Math.Min(take, notTake);
        }

        private double FindusingMemoization(int index, int target) // O(n*target) space stack: O(target) memo: O(n*target)
        {
            if (index == 0)
            {
                if (target % input[index] == 0)
                    return target / input[index];
                else
                    return 1e7;
            }

            if (this.memo[index, target] != 0) return this.memo[index, target];

            var take = 1e7;
            if (this.input[index] <= target)
                take = 1 + FindusingMemoization(index, target - this.input[index]);

            var notTake = (double)(0 + FindusingMemoization(index - 1, target));

            var result = Math.Min(take, notTake);

            this.memo[index, target] = (int)result;

            return result;
        }

        private double FindusingTabulation(int target) // O(n*target) space O(n*target)
        {
            for (int _k = 0; _k < this.k; _k++)
            {
                if (_k % this.input[0] == 0)
                    dp[0, _k] = _k / this.input[0];
                else
                    dp[0, _k] = (int)1e7;
            }

            for (int ind = 1; ind < this.n; ind++)
            {
                for (int _k = 0; _k < this.k; _k++)
                {
                    var take = 1e7;
                    if (this.input[ind] <= _k)
                        take = 1 + dp[ind, _k - this.input[ind]];

                    var notTake = (double)(0 + dp[ind - 1, _k]);

                    dp[ind, _k] = (int)Math.Min(take, notTake);
                }
            }
            return dp[this.n - 1, target];
        }

        private double FindusingSpaceOptimization(int target) // O(n*target) space O(target)
        {
            var prev = new int[this.k];

            for (int _k = 0; _k < this.k; _k++)
            {
                if (_k % this.input[0] == 0)
                    prev[_k] = _k / this.input[0];
                else
                    prev[_k] = (int)1e7;
            }

            for (int ind = 1; ind < this.n; ind++)
            {
                var curr = new int[this.k];
                for (int _k = 0; _k < this.k; _k++)
                {
                    var take = 1e7;
                    if (this.input[ind] <= _k)
                        take = 1 + curr[_k - this.input[ind]];

                    var notTake = (double)(0 + prev[_k]);

                    curr[_k] = (int)Math.Min(take, notTake);
                }
                prev = curr;
            }
            return prev[target];
        }
    }
}
