﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DP
{
    internal class _39_BuySellStockWithCooldown
    {
        int[] stockPrices;

        public int FindMaxProfit(int[] stockPrices)
        {
            this.stockPrices = stockPrices;

            return FindRecursively(0, true);
        }

        private int FindRecursively(int index, bool buy) // O(2^n)
        {
            if (index >= this.stockPrices.Length) return 0;

            var profit = 0;
            if (buy)
                profit = Math.Max(-this.stockPrices[index] + FindRecursively(index + 1, false),
                                 0 + FindRecursively(index + 1, true));
            else                                                                    //Below is the only change
                profit = Math.Max(this.stockPrices[index] + FindRecursively(index + 2, true),
                                  0 + FindRecursively(index + 1, false));

            return profit;
        }

        //Memo, Tabulation and Space optimization follows
    }
}
