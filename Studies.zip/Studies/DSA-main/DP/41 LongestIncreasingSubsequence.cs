﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace DP
{
    internal class _41_LongestIncreasingSubsequence
    {
        int[] input;

        int[,] memo;

        public int Find(int[] input)
        {
            this.input = input;
            this.memo = new int[this.input.Length, this.input.Length + 1];
            for (int row = 0; row < this.memo.GetLength(0); row++)
                for (int column = 0; column < this.memo.GetLength(1); column++)
                    this.memo[row, column] = -1;

            return FindUsingSpaceOptimisation2();
            return FindUsingSpaceOptimization();
            return FindUsingTabulation();
            return FindUsingMemo(0, -1);
            return FindRecursively(0, -1);
        }

        private int FindRecursively(int index, int previousIndex) // O(2^n)
        {
            if (index == this.input.Length) return 0;

            var take = 0;
            if (previousIndex == -1 || this.input[index] > this.input[previousIndex])
                take = 1 + FindRecursively(index + 1, index);

            var notTake = 0 + FindRecursively(index + 1, previousIndex);

            return Math.Max(take, notTake);
        }

        private int FindUsingMemo(int index, int previousIndex) // O(n*n) => O(n2) // space stack O(n) memo O(n*n) => O(n2)
        {
            if (index == this.input.Length) return 0;

            if (this.memo[index, previousIndex + 1] != -1) return this.memo[index, previousIndex + 1]; // In the case of previousIndex , right shift storing is being used
                                                                                                       // -1 data is being stored in 0 and 0 is being stored in 1.....and so on

            var take = 0;
            if (previousIndex == -1 || this.input[index] > this.input[previousIndex])
                take = 1 + FindRecursively(index + 1, index);

            var notTake = 0 + FindRecursively(index + 1, previousIndex);

            var result = Math.Max(take, notTake);

            this.memo[index, previousIndex + 1] = result;

            return result;
        }

        private int FindUsingTabulation() // O(n2) space O(n2)
        {
            var dp = new int[this.input.Length + 1, this.input.Length + 1];

            for (int prevIndex = 0; prevIndex < this.input.Length + 1; prevIndex++)
                dp[this.input.Length, prevIndex] = 0;

            for (int ind = this.input.Length - 1; ind >= 0; ind--)
            {
                for (int previousIndex = this.input.Length - 1; previousIndex >= -1; previousIndex--)
                {
                    var take = 0;
                    if (previousIndex == -1 || this.input[ind] > this.input[previousIndex])
                        take = 1 + dp[ind + 1, ind + 1];

                    var notTake = 0 + dp[ind + 1, previousIndex + 1];

                    var result = Math.Max(take, notTake);

                    dp[ind, previousIndex + 1] = result;
                }
            }

            return dp[0, 0];
        }


        private int FindUsingSpaceOptimization() // O(n2) space O(n)+O(n) = 2 O(n)
        {
            var prev = new int[this.input.Length + 1];

            for (int prevIndex = 0; prevIndex < this.input.Length + 1; prevIndex++)
                prev[prevIndex] = 0;

            for (int ind = this.input.Length - 1; ind >= 0; ind--)
            {
                var curr = new int[this.input.Length + 1];
                for (int prevIndex = this.input.Length - 1; prevIndex >= -1; prevIndex--)
                {
                    var take = 0;
                    if (prevIndex == -1 || this.input[ind] > this.input[prevIndex])
                        take = 1 + prev[ind + 1];

                    var notTake = 0 + prev[prevIndex + 1];

                    var result = Math.Max(take, notTake);

                    curr[prevIndex + 1] = result;
                }
                prev = curr;
            }

            return prev[0];
        }


        private int FindUsingSpaceOptimisation2() // O(n2) space O(n)
        {
            var dp = new int[this.input.Length];

            for (int ind = 0; ind < dp.Length; ind++)
                dp[ind] = 1;

            int maxLIS = 0;
            for (int ind = 0; ind < this.input.Length; ind++)
            {
                for (int prevIndex = 0; prevIndex < ind; prevIndex++)
                {
                    if (this.input[prevIndex] < this.input[ind])
                        dp[ind] = Math.Max(dp[ind], 1 + dp[prevIndex]);
                }
                maxLIS = Math.Max(maxLIS, dp[ind]);
            }
            return maxLIS;
        }
    }
}
