﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DP
{
    internal class _35_BestTimeToBuyAndSell // Only once Buy and Sell
    {
        public int FindMaxProfit(int[] stockPrices) // O(n)
        {
            int maxProfit = 0;
            int minPrice = stockPrices[0];

            for (int init = 1; init < stockPrices.Length; init++)
            {
                maxProfit = Math.Max(maxProfit, (stockPrices[init] - minPrice));
                minPrice = Math.Min(minPrice, stockPrices[init]);
            }

            return maxProfit;
        }
    }
}
