/*Find previous greater value
-----------------------

Problem:
Find previous greater value for each element in the input array
  
Solution:

Use (monotonically) decreasing stack (this is same as next greater value but the difference is iteration is happening from begining) for storing values from the input array. if the stack is empty then the current value is the maximum value. 
if the stack's top element is lesser than current element then remove/pop from the stack until stack's top element is greater than current element.
Next condition is to check whether stack is non empty and it's top value is greater than current value, if yes that is the next greater value for the current element.
*/

public static class PreviousGreaterValue
{
    public static int[] Find(int[] input)
    {
        var result = new int[input.Length];
        var monotonicalyDecreasingStack = new Stack<int>();

        for (int counter = 0; counter < input.Length; counter++)
        {
            while (monotonicalyDecreasingStack.Count > 0 && monotonicalyDecreasingStack.Peek() <= input[counter])
            {
                monotonicalyDecreasingStack.Pop();
            }
            if (monotonicalyDecreasingStack.Count > 0 && monotonicalyDecreasingStack.Peek() > input[counter])
                result[counter] = monotonicalyDecreasingStack.Peek();
            else
                result[counter] = -1;

            monotonicalyDecreasingStack.Push(input[counter]);
        }

        return result;
    }
}


/*int[] input = new[] { 2, 1, 5, 3, 4 };
var result = PreviousGreaterValue.Find(input);
foreach (var item in result)
    Console.WriteLine($"Previous greater values:{item}");*/
