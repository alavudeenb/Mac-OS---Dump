/*Find next greater value // Next greater value -> Monotonically decreasing stack
-----------------------

Problem:
Find next greater value for each element in the input array
  
Solution:
The main idea here is to start iterating from the end of the array.
Use (monotonically) decreasing stack for storing values from the input array. if the stack is empty then the current value is the maximum value. 
if the stack's top element is lesser than current element then remove/pop from the stack until stack's top element is greater than current element.
Next condition is to check whether stack is non empty and it's top value is greater than current value, if yes that is the next greater value for the current element.
*/

public static class NextGreaterValue
{
    public static int[] Find(int[] input)
    {
        var result = new int[input.Length];
        var monotonicDecreasingStack = new Stack<int>();

        for (int rightCounter = input.Length - 1; rightCounter >= 0; rightCounter--)
        {
            while (monotonicDecreasingStack.Count > 0 && monotonicDecreasingStack.Peek() <= input[rightCounter])
            {
                monotonicDecreasingStack.Pop();
            }
            if (monotonicDecreasingStack.Count > 0 && monotonicDecreasingStack.Peek() > input[rightCounter])
            {
                result[rightCounter] = monotonicDecreasingStack.Peek();
            }
            else
            {
                result[rightCounter] = -1;
            }

            monotonicDecreasingStack.Push(input[rightCounter]);
        }

        return result;
    }
}


/*int[] input = new[] { 2, 1, 5, 6, 2, 3 }; //{2,1,2,4,3 }; 
var result = NextGreaterValue.Find(input);
foreach (var item in result)
    Console.WriteLine($"Next greater values:{item}");*/
