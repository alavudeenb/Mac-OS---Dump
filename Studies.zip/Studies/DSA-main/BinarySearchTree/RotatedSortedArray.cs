/*Problem:
Find an element in the rotated sorted array

Solution:
After finding the midPointer. First thing is, since it is a rotated sorted array, midPointer might be pointing to higher number than rightPointer.
Hence check 

midPointer is less than rightPointer and then check given number is falling between midPointer and rightPointer (givenNumber > input[midPointer] && givenNumber <= input[rightPointer]).
if yes 
  move leftPointer = midPointer+1
else
  move rightPointer = midPointer-1

midPointer is greater than rightPointer and then check given number is falling between midPointer and leftPointer (givenNumber < input[midPointer] && givenNumber >= input[leftPointer])
if yes 
  move rightPointer = midPointer-1
else
  move leftPointer = midPointer+1

7, 8, 9, 1, 2, 3, 4, 5
leftPointer = 0
rightPointer = 7
midPointer = 3. */


public static class RotatedSortedArray
{
    public static bool IsNumberPresent(int[] input, int givenNumber)
    {
        bool isNumberPresent = false;

        int leftPointer = 0;
        int rightPointer = input.Length - 1;

        while (leftPointer <= rightPointer)
        {
            int midPointer = (rightPointer + leftPointer) / 2; // Find midPointer.

            if (input[midPointer] == givenNumber)
            {
                isNumberPresent = true;
                break;
            }

            if (input[midPointer] < input[rightPointer]) // Is midPointer less than rightPointer
            {
                if (givenNumber > input[midPointer] && givenNumber <= input[rightPointer])
                {
                    leftPointer = midPointer + 1;
                }
                else
                {
                    rightPointer = midPointer - 1;
                }
            }
            else
            {
                if (givenNumber < input[midPointer] && givenNumber >= input[leftPointer])
                {
                    rightPointer = midPointer - 1;
                }
                else
                {
                    leftPointer = midPointer + 1;
                }
            }

        }

        return isNumberPresent;
    }

}


/*var input = new[] { 7, 8, 9, 1, 2, 3, 4, 5 };
var givenNumber = 8;
var result = RotatedSortedArray.IsNumberPresent(input, givenNumber);
Console.WriteLine(result);*/
