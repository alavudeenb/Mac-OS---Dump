public static class LevelOrderTraversal
{
    public static T[] Get<T>(Node<T> rootNode)
    {
        var output = new List<T>();
        var queue = new Queue<Node<T>>();
        queue.Enqueue(rootNode);

        while (queue.Count > 0)
        {
            var currentNode = queue.Dequeue();
            output.Add(currentNode.Value);

            if (currentNode.Left != null)
                queue.Enqueue(currentNode.Left);

            if (currentNode.Right != null)
                queue.Enqueue(currentNode.Right);
        }

        return output.ToArray();
    }
}




/*var rootNode = new Node<int>() { Value = 5 };
rootNode.Left = new Node<int>() { Value = 4 };
rootNode.Right = new Node<int>() { Value = 7 };
rootNode.Left.Left = new Node<int>() { Value = 3 };
rootNode.Right.Left = new Node<int>() { Value = 6 };
rootNode.Right.Right = new Node<int>() { Value = 8 };

var levelOrderTraversalResult = LevelOrderTraversal.Get<int>(rootNode);
Console.WriteLine("Levelorder TraversalOutput");
foreach (var item in levelOrderTraversalResult)
    Console.WriteLine(item);*/
