   public static class PostOrderTraversal
   {
       public static T[] Get<T>(Node<T> rootNode)
       {
           var output = new List<T>();
           NextNode(rootNode, output);
           return output.ToArray();
       }

       private static void NextNode<T>(Node<T> node, List<T> output)
       {
           if (node != null)
           {
               NextNode<T>(node.Left, output);
               NextNode<T>(node.Right, output);
               output.Add(node.Value);
           }
       }
   }



/*var rootNode = new Node<int>() { Value = 5 };
rootNode.Left = new Node<int>() { Value = 4 };
rootNode.Right = new Node<int>() { Value = 7 };
rootNode.Left.Left = new Node<int>() { Value = 3 };
rootNode.Right.Left = new Node<int>() { Value = 6 };
rootNode.Right.Right = new Node<int>() { Value = 8 };

var postOrderTraversalResult = PostOrderTraversal.Get<int>(rootNode);
Console.WriteLine("Postorder TraversalOutput");
foreach (var item in postOrderTraversalResult)
    Console.WriteLine(item);*/
