/*Problem:
Given a binarytree, find the number.

Solution:
Keep leftPointer to the begining of the array and rightPointer to the end of the array and then midPointer = (rightPointer+leftPointer)/2.
Check midPointer is pointing to the given number. Run the loop until leftPointer is less than or equal to rightPointer.
*/

 public static class BinarySearch
 {
     public static bool IsNumberPresent(int[] input, int givenNumber)
     {
         bool isNumberPresent = false;

         int leftPointer = 0;
         int rightPointer = input.Length - 1;
         int midPointer = (rightPointer + leftPointer) / 2;

         while (leftPointer <= rightPointer)
         {
             if (input[midPointer] == givenNumber)
             {
                 isNumberPresent = true;
                 break;
             }

             if (givenNumber > input[midPointer])
             {
                 leftPointer = midPointer + 1;
             }
             else
             {
                 rightPointer = midPointer - 1;
             }

             midPointer = (rightPointer + leftPointer) / 2;
         }

         return isNumberPresent;
     }

 }


/*var input = new[] { 1, 2, 3, 4, 5, 6, 7, 8, 9 };
var givenNumber = 7;
var result = BinarySearch.IsNumberPresent(input, givenNumber);
Console.WriteLine(result);*/
