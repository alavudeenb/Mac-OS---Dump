public static class InOrderTraversal
{
    public static T[] Get<T>(Node<T> rootNode)
    {
        var output = new List<T>();
        NextNode(rootNode, output);
        return output.ToArray();
    }

    private static void NextNode<T>(Node<T> node, List<T> output)
    {
        if (node != null)
        {
            NextNode<T>(node.Left, output);
            output.Add(node.Value);
            NextNode<T>(node.Right, output);
        }
    }
}

public class Node<T>
{
    public Node<T> Left { get; set; }

    public Node<T> Right { get; set; }

    public T Value { get; set; }
}




/*var rootNode = new Node<int>() { Value = 5 };
rootNode.Left = new Node<int>() { Value = 4 };
rootNode.Right = new Node<int>() { Value = 7 };
rootNode.Left.Left = new Node<int>() { Value = 3 };
rootNode.Right.Left = new Node<int>() { Value = 6 };
rootNode.Right.Right = new Node<int>() { Value = 8 };

var result = InOrderTraversal.Get<int>(rootNode);
Console.WriteLine("Inorder TraversalOutput");
foreach (var item in result)
    Console.WriteLine(item);*/
