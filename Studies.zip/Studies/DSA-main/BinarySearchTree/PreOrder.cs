public static class PreOrderTraversal
{
    public static T[] Get<T>(Node<T> rootNode)
    {
        var output = new List<T>();
        NextNode(rootNode, output);
        return output.ToArray();
    }

    private static void NextNode<T>(Node<T> node, List<T> output)
    {
        if (node != null)
        {
            output.Add(node.Value);
            NextNode<T>(node.Left, output);
            NextNode<T>(node.Right, output);
        }
    }
}


/*var rootNode = new Node<int>() { Value = 5 };
rootNode.Left = new Node<int>() { Value = 4 };
rootNode.Right = new Node<int>() { Value = 7 };
rootNode.Left.Left = new Node<int>() { Value = 3 };
rootNode.Right.Left = new Node<int>() { Value = 6 };
rootNode.Right.Right = new Node<int>() { Value = 8 };
var preOrderTraversalResult = PreOrderTraversal.Get<int>(rootNode);
Console.WriteLine("Preorder TraversalOutput");
foreach (var item in preOrderTraversalResult)
    Console.WriteLine(item);*/
