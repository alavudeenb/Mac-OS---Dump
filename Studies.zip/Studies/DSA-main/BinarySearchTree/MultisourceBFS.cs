//var multisourcebfs = new Multisourcebfs();
//var result = multisourcebfs.GetShortestDistance(input);

//for (int row = 0; row < result.GetLength(0); row++)
//{
//    for (int col = 0; col < result.GetLength(1); col++)
//    {
//        Console.WriteLine($"({row},{col}) Value:{result[row, col]}");
//    }
//}


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BinaryTreeTraversal
{
    /*
     * Multi source BFS
     * 
     * Place initial sources in the queue (whenever node is placed in the queue, mark it as visisted in the tracker 2d matrix)
     * Dequeue them one by one
     * place adjacent (4 dimensions left, right, top, bottom) in the queue (whenever node is placed in the queue, mark it as visisted in the tracker 2d matrix)
     * loop queue until empty 
     * 
     */
    public class Multisourcebfs
    {
        public Multisourcebfs()
        {

        }

        public int[,] GetShortestDistance(int[,] input)
        {
            int rows = input.GetLength(0);
            int cols = input.GetLength(1);
            int[,] visistedNodeTracker = new int[rows, cols];
            var queue = new Queue<(int row, int col)>();

            for (int row = 0; row < rows; row++)
            {
                for (int col = 0; col < cols; col++)
                {
                    visistedNodeTracker[row, col] = -1;
                }
            }

            for (int _row = 0; _row < rows; _row++)
            {
                for (int _col = 0; _col < cols; _col++)
                {
                    if (input[_row, _col] == 0)
                    {
                        queue.Enqueue((_row, _col));
                        visistedNodeTracker[_row, _col] = 1;
                    }
                }
            }

            var count = queue.Count;
            while (count > 0)
            {
                var currentElement = queue.Dequeue();
                var currentRow = currentElement.row;
                var currentCol = currentElement.col;
                var currentValue = input[currentRow, currentCol];

                //top cell
                if (currentRow - 1 >= 0)
                {
                    var topRow = currentRow - 1;
                    var topCol = currentCol;

                    if (visistedNodeTracker[topRow, topCol] == -1 && input[topRow, topCol] != -1)
                    {
                        visistedNodeTracker[topRow, topCol] = 1;
                        input[topRow, topCol] = currentValue + 1;
                        queue.Enqueue((topRow, topCol));
                    }
                }

                //bottom cell
                if (currentRow + 1 < rows)
                {
                    var bottomRow = currentRow + 1;
                    var bottomCol = currentCol;

                    if (visistedNodeTracker[bottomRow, bottomCol] == -1 && input[bottomRow, bottomCol] != -1)
                    {
                        visistedNodeTracker[bottomRow, bottomCol] = 1;
                        input[bottomRow, bottomCol] = currentValue + 1;
                        queue.Enqueue((bottomRow, bottomCol));
                    }
                }

                //left cell
                if (currentCol - 1 >= 0)
                {
                    var leftRow = currentRow;
                    var leftCol = currentCol - 1;

                    if (visistedNodeTracker[leftRow, leftCol] == -1 && input[leftRow, leftCol] != -1)
                    {
                        visistedNodeTracker[leftRow, leftCol] = 1;
                        input[leftRow, leftCol] = currentValue + 1;
                        queue.Enqueue((leftRow, leftCol));
                    }
                }

                //right cell
                if (currentCol + 1 < cols)
                {
                    var rightRow = currentRow;
                    var rightCol = currentCol + 1;

                    if (visistedNodeTracker[rightRow, rightCol] == -1 && input[rightRow, rightCol] != -1)
                    {
                        visistedNodeTracker[rightRow, rightCol] = 1;
                        input[rightRow, rightCol] = currentValue + 1;
                        queue.Enqueue((rightRow, rightCol));
                    }
                }

                count = queue.Count;
            }

            return input;
        }
    }
}
