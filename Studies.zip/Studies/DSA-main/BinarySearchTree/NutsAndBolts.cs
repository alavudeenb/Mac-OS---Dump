//var nuts = new List<Nut>();
//nuts.Add(new Nut() { Value = 4 });
//nuts.Add(new Nut() { Value = 2 });
//nuts.Add(new Nut() { Value = 5 });
//nuts.Add(new Nut() { Value = 1 });
//nuts.Add(new Nut() { Value = 3 });


//var bolts = new List<Bolt>();
//bolts.Add(new Bolt() { Value = 3 });
//bolts.Add(new Bolt() { Value = 2 });
//bolts.Add(new Bolt() { Value = 5 });
//bolts.Add(new Bolt() { Value = 4 });
//bolts.Add(new Bolt() { Value = 1 });


//var result = new NutsAndBolts(nuts.ToArray(), bolts.ToArray()).FindMatch();

//for (int init = 0; init < result.nuts.Length; init++)
//{
//    Console.WriteLine($"Nut:{result.nuts[init].Value} Bolt:{result.bolts[init].Value}");
//}


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BinaryTreeTraversal
{
    public class NutsAndBolts
    {
        private readonly Nut[] nuts;

        private readonly Bolt[] bolts;

        private Node root;

        public NutsAndBolts(Nut[] nuts, Bolt[] bolts)
        {
            this.nuts = nuts;
            this.bolts = bolts;
        }

        public (Nut[] nuts, Bolt[] bolts) FindMatch()
        {
            var resultNuts = new List<Nut>();
            var resultBolts = new List<Bolt>();

            if (this.root == null)
            {
                this.root = BuildNode(nuts[0], bolts);
                resultNuts.Add(this.root.Nut);
                resultBolts.Add(this.root.Bolt);
            }

            for (int init = 1; init < this.nuts.Length; init++)
            {
                var currentNode = this.root;
                var currentNut = this.nuts[init];
                var currentBolts = this.root.SmallerBolt;
                while (currentNode != null)
                {
                    var result = currentNut.CompareTo(currentNode.Bolt);

                    if (result < 0)
                    {
                        currentBolts = currentNode.SmallerBolt;
                        if (currentNode.Left == null)
                        {
                            var newNode = this.BuildNode(currentNut, currentBolts.ToArray());
                            resultNuts.Add(newNode.Nut);
                            resultBolts.Add(newNode.Bolt);
                            currentNode.Left = newNode;
                            break;
                        }
                        else
                        {
                            currentNode = currentNode.Left;
                        }
                    }
                    else
                    {
                        currentBolts = currentNode.LargerBolt;
                        if (currentNode.Right == null)
                        {
                            var newNode = this.BuildNode(currentNut, currentBolts.ToArray());
                            resultNuts.Add(newNode.Nut);
                            resultBolts.Add(newNode.Bolt);
                            currentNode.Right = newNode;
                            break;
                        }
                        else
                        {
                            currentNode = currentNode.Right;
                        }
                    }
                }
            }

            return (resultNuts.ToArray(), resultBolts.ToArray());
        }


        private Node BuildNode(Nut nut, Bolt[] bolts)
        {
            var currentNode = new Node();
            foreach (var boltItem in this.bolts)
            {
                var result = nut.CompareTo(boltItem);

                if (result < 0)
                {
                    currentNode.LargerBolt.Add(boltItem);
                }
                else if (result > 0)
                {
                    currentNode.SmallerBolt.Add(boltItem);
                }
                else
                {
                    currentNode.Bolt = boltItem;
                    currentNode.Nut = nut;
                }
            }

            return currentNode;
        }

    }

    public class Nut
    {
        public int Value { get; set; }

        public int CompareTo(Bolt bolt)
        {
            return Value.CompareTo(bolt.Value);
        }
    }

    public class Bolt
    {
        public int Value { get; set; }
    }

    public class Node
    {
        public Nut Nut { get; set; }

        public Bolt Bolt { get; set; }

        public List<Bolt> SmallerBolt { get; set; }

        public List<Bolt> LargerBolt { get; set; }

        public Node Left { get; set; }

        public Node Right { get; set; }


        public Node()
        {
            this.SmallerBolt = new List<Bolt>();
            this.LargerBolt = new List<Bolt>();
        }
    }
}
