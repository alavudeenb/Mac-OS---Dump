// See https://aka.ms/new-console-template for more information
Console.WriteLine("Hello, World!");

Queue<(int row, int column)> bfs = new Queue<(int row, int column)>();
int numberOfIslands = 0;
int rows = 5;
int columns = 5;
int[,] inputTwoDMatrix = new int[rows, columns];
inputTwoDMatrix[0, 0] = 0;
inputTwoDMatrix[0, 1] = 1;
inputTwoDMatrix[0, 2] = 1;
inputTwoDMatrix[0, 3] = 0;
inputTwoDMatrix[1, 0] = 0;
inputTwoDMatrix[1, 1] = 1;
inputTwoDMatrix[1, 2] = 1;
inputTwoDMatrix[1, 3] = 0;
inputTwoDMatrix[2, 0] = 0;
inputTwoDMatrix[2, 1] = 0;
inputTwoDMatrix[2, 2] = 1;
inputTwoDMatrix[2, 3] = 0;
inputTwoDMatrix[3, 0] = 0;
inputTwoDMatrix[3, 1] = 0;
inputTwoDMatrix[3, 2] = 0;
inputTwoDMatrix[3, 3] = 0;
inputTwoDMatrix[4, 0] = 1;
inputTwoDMatrix[4, 1] = 1;
inputTwoDMatrix[4, 2] = 0;
inputTwoDMatrix[4, 3] = 1;


int[,] visitedTrackerMatrix = new int[rows, columns];
visitedTrackerMatrix[0, 0] = -1;
visitedTrackerMatrix[0, 1] = -1;
visitedTrackerMatrix[0, 2] = -1;
visitedTrackerMatrix[0, 3] = -1;
visitedTrackerMatrix[1, 0] = -1;
visitedTrackerMatrix[1, 1] = -1;
visitedTrackerMatrix[1, 2] = -1;
visitedTrackerMatrix[1, 3] = -1;
visitedTrackerMatrix[2, 0] = -1;
visitedTrackerMatrix[2, 1] = -1;
visitedTrackerMatrix[2, 2] = -1;
visitedTrackerMatrix[2, 3] = -1;
visitedTrackerMatrix[3, 0] = -1;
visitedTrackerMatrix[3, 1] = -1;
visitedTrackerMatrix[3, 2] = -1;
visitedTrackerMatrix[4, 3] = -1;
visitedTrackerMatrix[4, 0] = -1;
visitedTrackerMatrix[4, 1] = -1;
visitedTrackerMatrix[4, 2] = -1;
visitedTrackerMatrix[4, 3] = -1;


for (int row = 0; row < rows; row++)
{
    for (int column = 0; column < columns; column++)
    {
        if (inputTwoDMatrix[row, column] != 0 && visitedTrackerMatrix[row, column] == -1)
        {
            FindNeighboursByBFS(row, column);

            numberOfIslands = numberOfIslands + 1;
        }
    }
}

void FindNeighboursByBFS(int row, int column)
{
    if (inputTwoDMatrix[row, column] == 1 && visitedTrackerMatrix[row, column] == -1)
    {
        visitedTrackerMatrix[row, column] = 1;
    }

    //LandFinder(row - 1, column - 1);
    //LandFinder(row - 1, column);
    //LandFinder(row - 1, column + 1);
    //LandFinder(row + 1, column - 1);
    //LandFinder(row + 1, column);
    //LandFinder(row + 1, column + 1);
    //LandFinder(row, column - 1);

    //Below for loop can replace above 8 lines
    for (int deltaRow = -1; deltaRow <= 1; deltaRow++)
    {
        for (int deltaColumn = -1; deltaColumn <= 1; deltaColumn++)
        {
            LandFinder(row + deltaRow, column + deltaColumn);
        }
    }

    if (bfs.Count > 0)
    {
        var currentValue = bfs.Dequeue();
        FindNeighboursByBFS(currentValue.row, currentValue.column);
    }
}

void LandFinder(int row, int column)
{
    if (row >= 0 && column >= 0 && row < rows && column < columns)
    {
        int value = inputTwoDMatrix[row, column];
        if (value == 1 && visitedTrackerMatrix[row, column] == -1)
        {
            bfs.Enqueue((row, column));
        }
    }
}

Console.WriteLine($"Number of islands: {numberOfIslands}");
