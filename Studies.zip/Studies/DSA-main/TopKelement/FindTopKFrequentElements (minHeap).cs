/*Find Top K frequent elements
-----------------------------

Problem:
Find Top K frequent elements

Solution:*/


 public static class TopKFrequentElements
 {
     public static int[] Get(int[] input, int k)
     {
         var result = new int[k];
         var dictionary = new Dictionary<int, int>(); // Track the element and its frequency
         var minHeap = new PriorityQueue<int, int>(); // MinHeap for storing all elements by frequency, minHeap will hold minimum elements at the top. But yes MaxHeap also could have been used, it would have max frequent elements at the top.

         foreach (var item in input)
         {
             if (dictionary.ContainsKey(item))
                 dictionary[item] = dictionary[item] + 1; //Increment the frequency by 1 if the element is present in the dictionary
             else
                 dictionary[item] = 1; // Add if the element is not added in the dictionary
         }


         foreach(var item in dictionary)
         {
             minHeap.Enqueue(item.Key, item.Value);

             if (minHeap.Count > k) // Since we are using minheap, its top elements are minimum frequency values. 
                                    // if all the elements are dequeued untill only K elemetns are left over. 
                                    // meaning the min heap will have K frequent elements
             {
                 minHeap.Dequeue();
             }
         }

         for (int counter = 0; counter < k; counter++)
         {
             result[counter] = minHeap.Dequeue(); // Now minheap will have only K elements. Dequeue all elements from the minheap that are maximum values.
         }

         return result;
     }
 }



/*var input = new[] { 1, 1, 1, 2, 2, 3 };
var k = 2;
var result = TopKFrequentElements.Get(input, k);
foreach (var item in result)
    Console.WriteLine(item);*/
