/*Find K Closest Points to Origin
--------------------------------

Problem:
Given a 2d array of x and y coordinates, find x and y coordinates closest to origin

Solution:
Store x and y coordinates along with it's distance (calculated from formula  => x * x + y * y) in the maxHeap.
Dequeue maxHeap when the count goes beyond K values.
At the end, iterate the maxHeap to get lower values stored in the maxHeap.

FYI: maxHeap will have higher values in the top and lower values in the bottom.*/

 public static class TopKClosestPointsToOrigin
 {
     public static int[,] Get(int[,] input, int k)
     {
         var result = new int[k, 2];

         var maxHeap = new PriorityQueue<XYCoordinates, int>(Comparer<int>.Create((x, y) => y.CompareTo(x)));

         for (int xCounter = 0; xCounter < input.GetLength(0); xCounter++)
         {
             var distance = GetDistance(input[xCounter, 0], input[xCounter, 1]);
             maxHeap.Enqueue(new XYCoordinates() { X = input[xCounter, 0], Y = input[xCounter, 1] }, distance);

             if (maxHeap.Count > k)
             {
                 maxHeap.Dequeue();
             }
         }

         for (var counter = 0; counter < k; counter++)
         {
             var tempElement = maxHeap.Dequeue();
             result[counter, 0] = tempElement.X;
             result[counter, 1] = tempElement.Y;
         }

         return result;
     }

     private static int GetDistance(int x, int y)
     {
         return x * x + y * y;
     }
 }

 public class XYCoordinates
{
    public int X {get;set;}

    public int Y {get;set;}
}


/*var input = new int[3, 2];
input[0, 0] = 3;
input[0, 1] = 3;

input[1, 0] = 5;
input[1, 1] = -1;

input[2, 0] = -2;
input[2, 1] = 4;

var k = 2;
var result = TopKClosestPointsToOrigin.Get(input, k);
for (int counter = 0; counter < k; counter++)
    Console.WriteLine($"The X:{result[counter, 0]} Y:{result[counter, 1]}");*/
