//var input = new[] { 3, 5, 6, 2, 7, 9, 1 };
//var k = 2;
//var result = FindKthElement.Get(input, k);
//Console.WriteLine(result);


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MonotonicStack
{
    public static class FindKthElement
    {
        public static int Get(int[] input, int k)
        {
            var result = -1;

            var _k = input.Length - k;
            var left = 0;
            var right = input.Length - 1;
            result = QuickSelect(input, left, right, _k);

            return result;
        }

        private static int QuickSelect(int[] input, int left, int right, int k)
        {
            var pivot = input[right];
            var pointer = left;

            for (int counter = left; counter < right; counter++)
            {
                if (input[counter] < pivot)
                {
                    int temp = input[counter];
                    input[counter] = input[pointer];
                    input[pointer] = temp;
                    pointer++;
                }
            }

            var _temp = input[pointer];
            input[pointer] = pivot;
            input[right] = _temp;

            if (pointer > k)
               return QuickSelect(input, left, pointer - 1, k);
            else if (pointer < k)
                return QuickSelect(input, pointer + 1, right, k);
            else
                return input[pointer];
        }
    }
}
