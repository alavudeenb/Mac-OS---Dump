﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OverlappingInterval
{
    public static class MergeOverlappingIntervals
    {
        public static LinkedList<Data> Get(int[][] input)
        {
            System.Array.Sort(input, (a, b) =>
            {
                var result = a[0].CompareTo(b[0]);
                if (result != 0)
                    return result;
                return a[1].CompareTo(b[1]);

            });

            LinkedList<Data> mergedArray = new LinkedList<Data>();

            mergedArray.AddFirst(new Data(input[0][0], input[0][1]));

            int pointer = 1;
            LinkedListNode<Data> currentMergedArrayPointer = mergedArray.First;

            while (pointer < input.Length)
            {
                var latestMergedArrayValues = currentMergedArrayPointer.Value;

                var endOfMergedArraySegment = latestMergedArrayValues.EndValue;
                var startOfInputArraySegment = input[pointer][0];

                if (endOfMergedArraySegment > startOfInputArraySegment)
                {
                    var endOfSecondSegment = input[pointer][1];

                    if (endOfMergedArraySegment < endOfSecondSegment)
                        latestMergedArrayValues.EndValue = endOfSecondSegment;
                }
                else
                {
                    currentMergedArrayPointer = new LinkedListNode<Data>(new Data(input[pointer][0], input[pointer][1]));
                    mergedArray.AddLast(currentMergedArrayPointer);
                }

                pointer++;
            }

            return mergedArray;

        }

        public class Data
        {
            public Data(int startValue, int endValue)
            {
                this.StartValue = startValue;
                this.EndValue = endValue;
            }
            public int StartValue { get; set; }

            public int EndValue { get; set; }
        }
    }
}
