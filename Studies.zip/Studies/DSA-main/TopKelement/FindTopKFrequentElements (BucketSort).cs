/*Find Top K Frequent Element
------------------------------

Problem:
Given an input array, Find Top K frequent element from the input

Solution:
Initialize dictionary to keep track of the element and its frequency. Once the dictionary is populated with element and its frequency,
Loop through the dictionary, now the dictionary value (frequency) will be considered as index of an array of array (List<List<int>>) and key will be considered as value of an array of array (List<List<int>>).

After building the list of lists, iterate through it in reverse order to retrieve the top K frequent elements.*/

public static class TopKFrequentElementsWithBucketSort
{
    public static int[] Get(int[] input, int k)
    {
        var result = new List<List<int>>();
        var dictionary = new Dictionary<int, int>();
        var output = new List<int>();
        var tempK = k;

        for (int counter = 0; counter <= input.Length; counter++)
        {
            result.Add(new List<int>());
        }

        foreach (var item in input)
        {
            if (dictionary.ContainsKey(item))
                dictionary[item] = dictionary[item] + 1;
            else
                dictionary.Add(item, 1);
        }

        foreach (var item in dictionary)
        {
            var parent = result[item.Value];
            parent.Add(item.Key);
        }

        for (int counter = result.Count - 1; counter > 0; counter--)
        {
            var tempResult = result[counter];

            foreach (var item in tempResult)
            {
                output.Add(item);
                k = k - 1;
            }
            if (k == 0)
                break;
        }


        return output.ToArray();
    }
}



/*var input = new[] { 1, 1, 1, 2, 2, 3 };
var k = 2;
var result = TopKFrequentElementsWithBucketSort.Get(input, k);

foreach (var item in result)
{
    Console.WriteLine(item);
}*/
