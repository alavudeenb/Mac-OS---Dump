/*Find Top K elements
--------------------

Problem:
Find K maximum elements

Solution:
Enqueue all input elements to the minHeap. 
Since it is a minheap, lower value elements will be in the top, higher value elements will be in the bottom.*/

 public static class MinHeapTopKElements
 {
     public static int[] Get(int[] input, int k)
     {
         var result = new int[k];

         var minHeap = new PriorityQueue<int, int>();

         for (int counter = 0; counter < input.Length; counter++)
         {
             minHeap.Enqueue(input[counter], input[counter]);

             if (minHeap.Count > k)
             {
                 minHeap.Dequeue();
             }
         }

         for (int counter = 0; counter < k; counter++)
         {
             result[counter] = minHeap.Dequeue();
         }

         return result;
     }
 }



/*var input = new[] { 5, 9, 3, 4, 8, 2 };
var k = 3;
var result = TopKElements.Get(input, k);
foreach (var item in result)
    Console.WriteLine(item);*/
