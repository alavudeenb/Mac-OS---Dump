/*In the greedy method, choices (choosing maximum value or minimum value) are made at the beginning and applied throughout the problem.

Problem:
Given an arrays (things array, profits array, weight array) and the bag size. find out how many objects can be carried in the bag size that can yield more profit.

Solution:
Find profit for per kg. That is the right way to measure profit rather than simply taking highest profit without considering per kg. 
Then sort the profit by per kg, for this use maxHeap to store (objects, profits, weights) by per kg profit.
So that once all values are stored, we can simply iterate over maxHeap until bag is full. suppose the bag requires partial weight then let's use per kg profit that we calculated.

*/

public static class KnapSack
{
    public static float GetMaxProfit(int[] objects, int[] profits, int[] weights, int bagCapacity)
    {
        float maxProfit = 0;
        int currentCapacity = 0;

        var maxHeap = new PriorityQueue<ObjectData, float>(Comparer<float>.Create((x, y) => y.CompareTo(x)));

        for (int counter = 0; counter < objects.Length; counter++)
        {
            var currentObjectData = new ObjectData() { ID = objects[counter], Profit = profits[counter], Weight = weights[counter] };
            maxHeap.Enqueue(currentObjectData, currentObjectData.PerKgProfit);
        }

        while (currentCapacity < bagCapacity)
        {
            var currentMaxProfitObjectData = maxHeap.Dequeue();
            if ((currentCapacity + currentMaxProfitObjectData.Weight) <= bagCapacity)
            {
                currentCapacity = currentCapacity + currentMaxProfitObjectData.Weight;
                maxProfit = maxProfit + currentMaxProfitObjectData.Profit;
            }
            else
            {
                var remainingCapacity = bagCapacity - currentCapacity;
                float profitForRemainingCapacity = remainingCapacity * currentMaxProfitObjectData.PerKgProfit;
                
                currentCapacity = currentCapacity + remainingCapacity;
                maxProfit = maxProfit + profitForRemainingCapacity;
            }
        }

        return maxProfit;
    }
}

public class ObjectData
{
    public int ID { get; set; }

    public int Profit { get; set; }

    public int Weight { get; set; }

    public float PerKgProfit
    {
        get
        {
            return (float)this.Profit / this.Weight;
        }
    }

}


/*var objects = new[] { 1, 2, 3, 4, 5, 6, 7 };
var profits = new[] { 10, 5, 15, 7, 6, 18, 3 };
var weights = new[] { 2, 3, 5, 7, 1, 4, 1 };
var bagCapacity = 15;

var result = KnapSack.GetMaxProfit(objects, profits, weights, bagCapacity);

Console.WriteLine(result);*/
