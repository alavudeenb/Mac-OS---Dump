

//var graph = new Dictionary<int, List<(int neighbour, int weight)>>();
//graph.Add(1, new List<(int neighbour, int weight)>());
//graph.Add(2, new List<(int neighbour, int weight)>());
//graph.Add(3, new List<(int neighbour, int weight)>());
//graph.Add(4, new List<(int neighbour, int weight)>());
//graph.Add(5, new List<(int neighbour, int weight)>());
//graph.Add(6, new List<(int neighbour, int weight)>());
//graph.Add(7, new List<(int neighbour, int weight)>());

//var vertex1NeighboursAndWeight = graph[1];
//vertex1NeighboursAndWeight.Add((6, 10));
//vertex1NeighboursAndWeight.Add((2, 28));

//var vertex2NeighboursAndWeight = graph[2];
//vertex2NeighboursAndWeight.Add((7, 14));
//vertex2NeighboursAndWeight.Add((3, 16));

//var vertex3NeighboursAndWeight = graph[3];
//vertex3NeighboursAndWeight.Add((4, 12));

//var vertex4NeighboursAndWeight = graph[4];
//vertex4NeighboursAndWeight.Add((7, 18)); // Comment this line for checking non cyclic scenario
//vertex4NeighboursAndWeight.Add((5, 22));

//var vertex5NeighboursAndWeight = graph[5];
//vertex5NeighboursAndWeight.Add((6, 25));  // Comment this line for checking non cyclic scenario
//vertex5NeighboursAndWeight.Add((7, 24)); // Comment this line for checking non cyclic scenario

//var result = MinimumCostSpanningTree.ByKrushkalsMethod(graph);
//foreach (var item in result)
//{
//    foreach (var values in item.Value)
//    {
//        Console.WriteLine($"vertex: {item.Key} neighbour: {values.neighbour} weight: {values.weight}");
//    }
//}
//Console.ReadLine();


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GreedyProblems
{
    public static class MinimumCostSpanningTree
    {
        public static Dictionary<int, List<(int neighbour, int weight)>> ByKrushkalsMethod(Dictionary<int, List<(int neighbour, int weight)>> graph)
        {
            var mst = new Dictionary<int, List<(int neighbour, int weight)>>();
            var cycleTracker = new Dictionary<int, int>();
            var minHeap = new PriorityQueue<(int u, int v, int weight), int>();

            for (int counter = 1; counter <= graph.Count; counter++)
            {
                cycleTracker.Add(counter, -1);
            }

            foreach (var vertex in graph)
            {
                int u = vertex.Key;
                foreach (var edges in vertex.Value)
                {
                    int v = edges.neighbour;
                    int weight = edges.weight;

                    minHeap.Enqueue((u, v, weight), weight);
                }
                mst.Add(u, new List<(int neighbour, int weight)>());
            }

            while (minHeap.Count > 0)
            {
                var vertex = minHeap.Dequeue();

                int u = vertex.u;
                int v = vertex.v;
                int weight = vertex.weight;

                var parentOfu = FindParent(u, cycleTracker);
                var parentOfv = FindParent(v, cycleTracker);

                if (parentOfu != parentOfv && cycleTracker[parentOfu] < 0 && cycleTracker[parentOfv] < 0) // Negative number in the dictionary indicates itself parent
                {
                    var weightedunionOfu = cycleTracker[parentOfu] * -1; //Making it positive number to check u or v is having more child vertices
                    var weightedunionOfv = cycleTracker[parentOfv] * -1; //Making it positive number to check u or v is having more child vertices

                    if (weightedunionOfu >= weightedunionOfv)
                    {
                        cycleTracker[parentOfu] = (weightedunionOfu + weightedunionOfv) * - 1;
                        cycleTracker[parentOfv] = parentOfu;
                    }
                    else
                    {

                        cycleTracker[parentOfv] = (weightedunionOfu + weightedunionOfv) * - 1;
                        cycleTracker[parentOfu] = parentOfv;
                    }
                    var adjacents = mst[u];
                    adjacents.Add((v, weight));
                }
            }

            return mst;
        }

        private static int FindParent(int vertex, Dictionary<int, int> cycleTracker)
        {
            var vertexValue = cycleTracker[vertex];
            var _vertex = vertex;

            while (vertexValue > 0)
            {
                _vertex = vertexValue;
                vertexValue = cycleTracker[vertexValue];
            }

            return _vertex;
        }
    }
}
