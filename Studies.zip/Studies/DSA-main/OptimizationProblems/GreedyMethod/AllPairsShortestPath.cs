
//var result = AllPairsShortestPath.Get(input, noOfVertices);

//for (int i = 1; i < noOfVertices; i++)
//{
//    Console.WriteLine();
//    for (int j = 1; j < noOfVertices; j++)
//    {
//        Console.Write($"{result[i, j]}  ");
//    }
//}


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GreedyProblems
{
    public static class AllPairsShortestPath
    {
        public static int[,] Get(Dictionary<int, List<(int neighbour, int weight)>> input, int noOfVertices)
        {
            var previous = Get2DArrayFromGraph(input, noOfVertices);

            for (int counter = 1; counter < noOfVertices; counter++)
            {
                var current = (int[,])previous.Clone();
                for (int i = 1; i < noOfVertices; i++)
                {
                    for (int j = 1; j < noOfVertices; j++)
                    {
                        current[i, j] = Math.Min(previous[i, j], previous[i, counter] + previous[counter, j]);
                    }
                }
                previous = current;
            }

            return previous;
        }

        private static int[,] Get2DArrayFromGraph(Dictionary<int, List<(int neighbour, int weight)>> input, int noOfVertices)
        {
            int[,] output = new int[noOfVertices, noOfVertices];
            for (int counter = 1; counter < noOfVertices; counter++)
            {
                for (int innerCounter = 1; innerCounter < noOfVertices; innerCounter++)
                {
                    if (counter != innerCounter)
                    {
                        output[counter, innerCounter] = Int32.MaxValue / 2; //To avoid overflow
                    }
                }
            }

            foreach (var _vertex in input)
            {
                var vertex = _vertex.Key;
                foreach (var edges in _vertex.Value)
                {
                    var edge = edges.neighbour;
                    var weight = edges.weight;

                    output[vertex, edge] = weight;
                }
            }

            return output;
        }

        //private static int[,] UpdateByIndices(int[,] input, int index)
        //{
        //    int[
        //}

        //private static int[,] CopyFrom(int[,] input, int index)
        //{

        //}
    }
}
