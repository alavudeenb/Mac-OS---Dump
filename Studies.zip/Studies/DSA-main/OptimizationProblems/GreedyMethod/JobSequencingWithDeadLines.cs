/*In the greedy method, choices (choosing maximum value or minimum value) are made at the beginning and applied throughout the problem.

Problem:
Given an array of jobs, profits and deadlines. Find out the jobs that should be done inorder to make maximum profit.

Solution:
The main idea here is to find maximum deadlines. create an array with the size of deadlines. Sort the input values by maximum of profits. 
Even if the first two maximum profits are having same deadline, we can complete the second maximum profit eary by placing it in the previous slot.

*/

public static class JobSequencingWithDeadlines
{
    public static float GetMaxProfit(string[] jobs, int[] profits, int[] deadlines)
    {
        float maxProfit = 0;
        int maxDeadLine = 0;
        var maxHeap = new PriorityQueue<JobData, int>(Comparer<int>.Create((x, y) => y.CompareTo(x)));

        for (int counter = 0; counter < jobs.Length; counter++)
        {
            var jobData = new JobData() { JobId = jobs[counter], Profit = profits[counter], DeadLine = deadlines[counter] };

            maxHeap.Enqueue(jobData, jobData.Profit);
            maxDeadLine = Math.Max(maxDeadLine, jobData.DeadLine);
        }

        int[] maxJobsThatCanBeExecuted = new int[maxDeadLine];

        while (maxDeadLine > 0 && maxHeap.Count > 0)
        {
            var jobData = maxHeap.Dequeue();

            var arrayIndex = jobData.DeadLine - 1; //To match to the 0 based index array we are substracting with -1;

            if (maxJobsThatCanBeExecuted[arrayIndex] == 0) //Check current index is not holding any value
            {
                maxJobsThatCanBeExecuted[arrayIndex] = jobData.Profit;
                maxProfit = maxProfit + jobData.Profit;
                maxDeadLine = maxDeadLine - 1;
            }
            else
            {
                arrayIndex = arrayIndex - 1;

                while (arrayIndex >= 0)
                {
                    if (maxJobsThatCanBeExecuted[arrayIndex] == 0) //Check current index is not holding any value
                    {
                        maxJobsThatCanBeExecuted[arrayIndex] = jobData.Profit;
                        maxProfit = maxProfit + jobData.Profit;
                        maxDeadLine = maxDeadLine - 1;
                        break;
                    }
                    arrayIndex = arrayIndex - 1;
                }
            }
        }


        return maxProfit;
    }

}

public class JobData
{
    public string JobId { get; set; }

    public int Profit { get; set; }

    public int DeadLine { get; set; }
}




/*var jobs = new[] { "J1", "J2", "J3", "J4", "J5", "J6", "J7" };  //new[] { "J1", "J2", "J3", "J4", "J5" };
var profits = new[] { 35, 30, 25, 20, 15, 12, 5 };  //new[] { 100, 19, 27, 25, 15 };
var deadLines = new[] { 3, 4, 4, 2, 3, 1, 2 }; // new[] { 2, 1, 2, 1, 3 };

var result = JobSequencingWithDeadlines.GetMaxProfit(jobs, profits, deadLines);
Console.WriteLine(result);*/
