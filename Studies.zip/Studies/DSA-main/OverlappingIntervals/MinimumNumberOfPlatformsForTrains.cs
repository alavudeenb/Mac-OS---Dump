/*Find minimum number of platforms in a day for trains to arrive and depature.

Problem:
Given an two integer arrays, one for arrival times and the other one is for depature times, find minimum number of platform required for trains.

Solution:
Sort two integer arrays in an ascending order. Keep two pointers, one for arrival times array and the another one for depature times array.
if arrival times array value is lower (train arrives earlier than depature) depature time then increase currentPlatform and arrivalPointer by 1.
else decrease currentPlatform by 1 and increase depaturePointer by 1.
In each iteration find Math.Max(maxValue, currentPlatform).*/

 public static class MinimunNumberOfPlatformsForTrain
 {
     public static int Find(int[] arrival, int[] depature)
     {
         int maxPlatform = 0;

         System.Array.Sort(arrival);
         System.Array.Sort(depature);

         int currentPlatforms = 0;
         int arrivalPlatformIndex = 0;
         int depaturePlatformIndex = 0;

         while (depaturePlatformIndex < depature.Length)
         {
             if (arrivalPlatformIndex < arrival.Length && arrival[arrivalPlatformIndex] < depature[depaturePlatformIndex])
             {
                 currentPlatforms = currentPlatforms + 1;
                 arrivalPlatformIndex = arrivalPlatformIndex + 1;
             }
             else
             {
                 currentPlatforms = currentPlatforms - 1;
                 depaturePlatformIndex = depaturePlatformIndex + 1;
             }

             maxPlatform = Math.Max(maxPlatform, currentPlatforms);
         }

         return maxPlatform;

     }

 }


/*var arrivalTrains = new[] { 900, 945, 955, 1100, 1500, 1800 };
var depatureTrains = new[] { 920, 1200, 1130, 1150, 1900, 2000 };

var result = MinimunNumberOfPlatformsForTrain.Find(arrivalTrains, depatureTrains);
Console.WriteLine(result);*/
