/*Merge intervals that are overlapping
------------------------------------

Problem:
Given an array of start and end value, merge intervals that are overlapping.

Solution:
Sort the array based on start value in the array. Compare current end value with next start value.
if next start is less than the current end value which means it should be merged with current.

*/

 public static class MergeOverlappingIntervals
 {
     public static LinkedList<Data> Get(int[][] input)
     {
         System.Array.Sort(input, (a, b) =>
         {
             var result = a[0].CompareTo(b[0]);
             if (result != 0)
                 return result;
             return a[1].CompareTo(b[1]);

         }); //Sort the array based on start value in the array.

         LinkedList<Data> mergedArray = new LinkedList<Data>();

         mergedArray.AddFirst(new Data(input[0][0], input[0][1]));

         int pointer = 1;
         LinkedListNode<Data> currentMergedArrayPointer = mergedArray.First;

         while (pointer < input.Length)
         {
             var latestMergedArrayValues = currentMergedArrayPointer.Value;

             var endOfMergedArraySegment = latestMergedArrayValues.EndValue;
             var startOfInputArraySegment = input[pointer][0];

             if (endOfMergedArraySegment > startOfInputArraySegment) //Compare current end value with next start value.
             {
                 var endOfSecondSegment = input[pointer][1];

                 if (endOfMergedArraySegment < endOfSecondSegment) // Incase next end value is bigger than current end value. 
                                                                  // Merted item end value should be next end value
                     latestMergedArrayValues.EndValue = endOfSecondSegment;
             }
             else
             {
                 currentMergedArrayPointer = new LinkedListNode<Data>(new Data(input[pointer][0], input[pointer][1]));
                 mergedArray.AddLast(currentMergedArrayPointer);
             }

             pointer++;
         }

         return mergedArray;

     }

     public class Data
     {
         public Data(int startValue, int endValue)
         {
             this.StartValue = startValue;
             this.EndValue = endValue;
         }
         public int StartValue { get; set; }

         public int EndValue { get; set; }
     }
 }




/*var input = new int[][] {
                        new int[] {1,3 },
                        new int[] { 2,6},
                        new int[] { 8,10},
                        new int[] { 15,18}
                        };
var result = MergeOverlappingIntervals.Get(input);

foreach (var item in result)
{
    Console.WriteLine($"X: {item.StartValue} Y: {item.EndValue}");
}*/
