/*FixedSlidingWindow
-------------------

Problem:
Find average of maxsubarray. The max subarray lenght is K.

Input: [1, 12, -5, -6, 50, 3]
K: 4

Output: 12.75

Solution:
Loop through from 0th index to K-1th index and add them all. Name it as previousSum and also sumOfMaxSubArray.

Place left pointer at 0th index and right pointer at Kth index. 
Then keep iterating/moving one step (+1) forward both left and right pointer until right pointer reaches the end of the array. 
In each iteration substract substract previousSum with left index element and add previousSum with righ index element, the value is stored in the tempVariable.
Always check tempVariable is greater then previousSum, if yes, then assign tempVariable to previousSum and also take Math.Max(sumOfMaxSubArray, tempVariable); 
In this way we are sliding both left and right pointers and both are always covering K elements.*/

 public static class FixedSlidingWindow
 {
     public static double GetAverageOfMaxSubArray(int[] input, int slidingWindow)
     {
         int sumOfMaxSubArray = 0;
         int previousSlidingWindowSum = 0;
         int leftIndex = 0;
         int rightIndex = slidingWindow;

         for (int counter = 0; counter < slidingWindow; counter++)
         {
             sumOfMaxSubArray = sumOfMaxSubArray + input[counter];
         }

         previousSlidingWindowSum = sumOfMaxSubArray;

         while (rightIndex < input.Length)
         {
             int tempSumOfMaxSubArray = (previousSlidingWindowSum - input[leftIndex]) + input[rightIndex];

             sumOfMaxSubArray = Math.Max(sumOfMaxSubArray, tempSumOfMaxSubArray);
             previousSlidingWindowSum = tempSumOfMaxSubArray;
             leftIndex = leftIndex + 1;
             rightIndex = rightIndex + 1;
         }

         return (double)sumOfMaxSubArray / slidingWindow;
     }
 }

/*var input = new[] { 1, 12, -5, -6, 50, 3 };
var slidingWindow = 4;
var result = FixedSlidingWindow.GetAverageOfMaxSubArray(input, slidingWindow);
Console.WriteLine(result);*/
