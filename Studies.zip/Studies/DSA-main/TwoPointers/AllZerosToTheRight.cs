/*Move all zero's to right
---------------------------

Problem:
Given an integer array, move all zero's to the right

Solution:
Initialize leftPointer and rightPointer to 0th index. Check rightPointer is not equal to zero, 
if true, then update leftPointer value with rightPointer and then move rightPointer and leftPointer one step forward.
else simply move rightPointer only one step forward.*/

public class AllZerosToTheRight
{

    public static int[] Get(int[] input)
    {
        int left = 0;
        for (int right = 0; right < input.Length; right++)
        {
            if (input[right] != 0)
            {
                int temp = input[left];
                input[left] = input[right];
                input[right] = temp;
                left++;
            }
        }

        return input;
    }
}


/*int[] input = new[] { 1, 0, 7, 12, 0, 0 };
var result = AllZerosToTheRight.Get(input);
foreach (var item in result)
    Console.WriteLine(item);*/
