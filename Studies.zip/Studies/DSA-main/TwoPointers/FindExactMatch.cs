﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TwoPointers_Problems
{
    /*var input = new[] { 1, 3, 7, 5, 2, 9 };
    var target = 9;

    var result = FindExactMatch.Get(input, target);

    foreach (var item in result)
    {
        Console.WriteLine($"Pairs: ({item.firstValue},{item.secondValue})");
    }*/

    internal class FindExactMatch
    {
        public static (int firstValue, int secondValue)[] Get(int[] input, int target)
        {
            var hashSet = new HashSet<int>();
            var matchValues = new List<(int firstValue, int secondValue)>();

            for (int init = 0; init < input.Length; init++)
            {
                if (hashSet.Contains(target - input[init]))
                {
                    matchValues.Add((input[init], target - input[init]));
                }
                hashSet.Add(input[init]);
            }

            return matchValues.ToArray();
        }
    }
}
