/*MaximumSumOfSubarray
----------------------

Problem:
Given an array find subarray that has maximum sum.
Input: [1, -3, 4, -1, 2, 1, -5, 4]

Output: 6 i.e [4, -1, 2, 1]

Solution:
The idea here is take 0th element in the currentSum variable and then start the for loop from 1st index, continue the until end of the array.
By adding for loop's current element(in this case 1st index element) to the current sum if the total is greater then for loop's current element
(in this case 1st index element) then add both currentSum and for loop's current element and assign it to currentSum.

i.e 
if ((currentSum + input[counter]) > input[counter])
{
    currentSum = currentSum + input[counter];
}
else
{
    currentSum = input[counter];
}

make sure we are finding maxSum before moving to next iteration.

if (maxSum < currentSum)
{
    maxSum = currentSum;
}

The reason is, by adding for loop's current element with currentSum is not greater then for loop's current element then it is not worth adding.*/

public static class MaximumSumOfSubarray
{
    public static int[] Find(int[] input)
    {
        var result = new List<int>();
        int maxSum = 0;
        int currentSum = input[0];

        int startIndex = 0;
        int endIndex = 0;
        int tempStartIndex = 0;
        int tempEndIndex = 0;

        for (int counter = 1; counter < input.Length; counter++)
        {
            if ((currentSum + input[counter]) > input[counter])
            {
                currentSum = currentSum + input[counter];
                tempEndIndex = counter;
            }
            else
            {
                currentSum = input[counter];
                tempStartIndex = counter;
                tempEndIndex = counter;
            }

            if (maxSum < currentSum)
            {
                maxSum = currentSum;
                startIndex = tempStartIndex;
                endIndex = tempEndIndex;
            }
        }

        for (int counter = startIndex; counter <= endIndex; counter++)
        {
            result.Add(input[counter]);
        }

        return result.ToArray();
    }
}

/*var input = new[] { 1, -3, 4, -1, 2, 1, -5, 4 };
var result = MaximumSumOfSubarray.Find(input);
int sum = 0;
foreach (var item in result)
{
    sum = sum + item;
    Console.Write(item);
}
Console.WriteLine();
Console.WriteLine($"Sum of largerst sub array is: {sum}");*/
