/*Find Length Of longest unique Substring
----------------------------------------

Problem:
Given a string find length of substring that has unique character.

Solution:
Keep leftPointer and rightPointer at 0 (index). Move only right pointer one step forward. Add current character to the HashSet. 
if Add operation of HashSet succeeds, 
  find maxlength by substracting rightPointer-leftPointer
  then righpointer=rightpointer+1  
else Add operation of HashSet fails 
  it means that the hashset is already having the character. 
  remove all characters until the duplicate character is being removed from hashset and also move leftPointer forward same as number of characters that was removed.
  For example: var input = new[] { 'a', 'b', 'c', 'b', 'd', 'a', 'e', 'f', 'g', 'b', 'c', 'b', 'b' }; in the input array 
  when rightPointer is at 3rd index, leftPointer would be at 0th index when the duplicate character is found in the 
  hashset. After removing duplicate character a,b the leftPointer will be at 2nd index and rightPointer will be at 3rd index.*/

public static class DynamicSlidingWindow
{
    public static char[] GetLengthOfLongestUniqueSubstring(char[] input)
    {
        int longestSubstringsLength = 0;
        var substrings = new List<char>();

        int leftPointer = 0;
        int rightPointer = 0;

        var tempHashSet = new HashSet<char>();

        while (rightPointer < input.Length)
        {
            if (tempHashSet.Add(input[rightPointer]))
            {
                var lengthOfCharacters = rightPointer - leftPointer;
                longestSubstringsLength = Math.Max(longestSubstringsLength, lengthOfCharacters);
                rightPointer = rightPointer + 1;
            }
            else
            {
                if (substrings.Count < tempHashSet.Count)
                {
                    var tempSubStringArray = new char[tempHashSet.Count];
                    var lengthOfCharacters = rightPointer - leftPointer;
                    System.Array.Copy(input, leftPointer, tempSubStringArray, 0, lengthOfCharacters);
                    substrings = new List<char>(tempSubStringArray);
                }
                while (tempHashSet.Contains(input[rightPointer]))
                {
                    tempHashSet.Remove(input[leftPointer]);
                    leftPointer = leftPointer + 1;
                }
            }
        }

        return substrings.ToArray();
    }
}


/*var input = new[] { 'a', 'b', 'c', 'b', 'd', 'a', 'e', 'f', 'g', 'b', 'c', 'b', 'b' };
var result = DynamicSlidingWindow.GetLengthOfLongestUniqueSubstring(input);
Console.WriteLine(result.Length);
foreach (var item in result)
    Console.Write(item);*/
