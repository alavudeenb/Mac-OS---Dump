﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TwoPointers_Problems
{
    /*
     *  var input = new[] { -6, 2, 5, -2, -7, -1, 3 };
        var target = -2;

        var result = TwoPointers.FindNumberOfPairsLessThanTarget(input, target);

        Console.WriteLine($"Number of valid pairs{result}");
     * 
     */
    internal class FindNumberOfPairsLessThanTarget
    {
        public static int Get(int[] input, int target)
        {
            System.Array.Sort(input);

            var leftPointer = 0;
            var rightPointer = input.Length - 1;

            var numberOfValidPairs = 0;

            while (leftPointer < rightPointer)
            {
                if (input[leftPointer] + input[rightPointer] >= target)
                {
                    rightPointer = rightPointer - 1;
                }
                else
                {
                    numberOfValidPairs = numberOfValidPairs + (rightPointer - leftPointer);
                    leftPointer = leftPointer + 1;
                }
            }
            return numberOfValidPairs;
        }
    }
}
