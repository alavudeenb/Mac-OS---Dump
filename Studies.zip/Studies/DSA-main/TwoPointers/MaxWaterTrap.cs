/*Find Max Water Can be Stored
-----------------------------

For image reference, leet code link https://leetcode.com/problems/trapping-rain-water/description/

Problem:
Given an integer array which represents height, find out max water that can be stored between two heights.
Input = [1, 8, 6, 2, 5, 4, 8, 3, 7];

Output: 49

Solution:
At first glance it looks unclear. The idea here is, having array begining as starting index (left) and end as ending index (right),
consider left index and right index as width. From the array value of two indices left and right, pick whichever is lower 
(the reason is that's the max water that can be stored). consider it as height.
Now we have width and height. so to find the area, the formula is area = widht*height. store the result in some global variable.

Now we have to decided which one we should move, left or right pointer. 
if the left pointer index is less then we should move left pointer by +1 else right pointer by -1. 
when the left pointer is greater than right pointer, terminate the loop.*/

public static class MaxWaterTrap
{
    public static int GetMaxArea(int[] input)
    {
        int maxarea = 0;
        int leftPointer = 0;
        int rightPointer = input.Length - 1;

        while (leftPointer <= rightPointer)
        {
            var length = Math.Min(input[leftPointer], input[rightPointer]);
            var width = (rightPointer) - leftPointer;
            var area = length * width;
            maxarea = Math.Max(maxarea, area);

            if (input[leftPointer] < input[rightPointer])
                leftPointer = leftPointer + 1;
            else
                rightPointer = rightPointer - 1;
        }

        return maxarea;
    }
}



//int[] input = new[] { 1, 8, 6, 2, 5, 4, 8, 3, 7 };
//var result = MaxWaterTrap.GetMaxArea(input);
//Console.WriteLine($"Max water that can be stored is:{result}");
