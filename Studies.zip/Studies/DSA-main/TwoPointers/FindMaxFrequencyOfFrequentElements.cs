﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TwoPointers_Problems
{
    /*
     * var input = new[] { 1, 4, 8, 13 };
       var numberOfFrequencyIncreaseOperation = 5;

        var result = TwoPointers.FindMaxFrequencyOfFrequentElements(input, numberOfFrequencyIncreaseOperation);

        Console.WriteLine($"Max frequency of frequent elements {result}");
     * 
     * 
     * 
     * 
     */
    internal class FindMaxFrequencyOfFrequentElements
    {
        public static int Get(int[] input, int numberOfFrequencyIncreaseOperation)
        {
            System.Array.Sort(input);

            var leftPointer = 0;
            var rightPointer = 0;

            var total = 0;
            var maxFrequencyOfFrequentElement = 0;

            while (rightPointer < input.Length)
            {
                total = total + input[rightPointer];

                while (leftPointer + 1 <= rightPointer && (input[rightPointer] * (rightPointer - leftPointer + 1)) > total + numberOfFrequencyIncreaseOperation)
                {
                    total = total - input[leftPointer];
                    leftPointer = leftPointer + 1;
                }
                maxFrequencyOfFrequentElement = Math.Max(maxFrequencyOfFrequentElement, (rightPointer - leftPointer) + 1);

                rightPointer++;
            }

            return maxFrequencyOfFrequentElement;
        }
    }
}
