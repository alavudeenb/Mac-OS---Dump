﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TwoPointers_Problems
{
    /*
     * 
        //To find pairs with in the range
        var input = new[] { 0, 1, 7, 4, 4, 5 };
        var lowerBound = 3;
        var upperBound = 6;

        var result = FindPairsInRange.Get(input, lowerBound, upperBound);
        Console.WriteLine($"Number of pairs with in the range {result}");
     * 
     * 
     * 
     * 
     */
    internal class FindPairsInRange
    {
        public static int FindAllPairsLessThanTarget(int[] input, int target)
        {
            System.Array.Sort(input);

            var leftPointer = 0;
            var rightPointer = input.Length - 1;

            var numberOfValidPairs = 0;

            while (leftPointer < rightPointer)
            {
                if (input[leftPointer] + input[rightPointer] >= target)
                {
                    rightPointer = rightPointer - 1;
                }
                else
                {
                    numberOfValidPairs = numberOfValidPairs + (rightPointer - leftPointer);
                    leftPointer = leftPointer + 1;
                }
            }
            return numberOfValidPairs;
        }

        public static int Get(int[] input, int lowerBound, int upperBound)
        {
            System.Array.Sort(input);

            var upperBoundPairs = FindAllPairsLessThanTarget(input, upperBound + 1);
            var lowerBoundPairs = FindAllPairsLessThanTarget(input, lowerBound);

            return upperBoundPairs - lowerBoundPairs;
        }
    }


}
